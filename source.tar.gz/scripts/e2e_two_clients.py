"""
Uçtan uca test: iki gerçek Chrome istemcisi (renderer'ın web derlemesi) yerel
Worker'a (wrangler dev) bağlanır ve ilk dikey dilimi uçtan uca doğrular:

  1. Kayıt / giriş
  2. Sunucu oluşturma + davetle katılma
  3. Gerçek zamanlı mesajlaşma ve "yazıyor" göstergesi
  4. Sesli kanal: iki istemci arasında gerçek WebRTC P2P bağlantısı ve ses akışı
     (Chrome'un sahte mikrofonu bip sesi üretir)
  5. Soundboard: ses yükleme, tıklama, odadaki her iki istemcide zamanlanmış oynatma

Ön koşullar:
  pnpm --filter @yanki/server dev            (http://127.0.0.1:8787)
  pnpm --filter @yanki/desktop build:web
  python -m http.server 5173 -d apps/desktop/out/web
  pip install playwright && Chrome kurulu olmalı

Çalıştırma: python scripts/e2e_two_clients.py
"""
import math
import os
import struct
import sys
import tempfile
import time
import uuid

from playwright.sync_api import expect, sync_playwright

WEB = os.environ.get("YANKI_WEB", "http://127.0.0.1:5173")
API = os.environ.get("YANKI_API", "http://127.0.0.1:8787")
SHOTS = os.environ.get("YANKI_SHOTS", tempfile.gettempdir())
URL = f"{WEB}/?debug=1&api={API}"
SUFFIX = uuid.uuid4().hex[:6]


def make_beep(path: str) -> None:
    rate, secs = 22050, 0.4
    n = int(rate * secs)
    data = b"".join(struct.pack("<h", int(12000 * math.sin(2 * math.pi * 660 * i / rate))) for i in range(n))
    with open(path, "wb") as f:
        f.write(b"RIFF" + struct.pack("<I", 36 + len(data)) + b"WAVEfmt ")
        f.write(struct.pack("<IHHIIHH", 16, 1, 1, rate, rate * 2, 2, 16))
        f.write(b"data" + struct.pack("<I", len(data)) + data)


def step(msg: str) -> None:
    print(f"  ✓ {msg}", flush=True)


def register(page, username: str) -> None:
    page.goto(URL)
    page.get_by_role("button", name="Hesabın yok mu? Kayıt ol").click()
    page.locator('input[name="username"]').fill(username)
    page.locator('input[name="displayName"]').fill(username.capitalize())
    page.locator('input[name="password"]').fill("guclu-bir-sifre-123")
    page.get_by_role("button", name="Kayıt ol", exact=True).click()
    expect(page.get_by_text(f"@{username}")).to_be_visible(timeout=10_000)


def voice_state(page):
    return page.evaluate("() => { const v = window.__yanki.voice(); return { state: v.state, peers: v.peerStats, speaking: v.speaking }; }")


def main() -> int:
    beep = os.path.join(tempfile.gettempdir(), "yanki-bip.wav")
    make_beep(beep)
    with sync_playwright() as p:
        browser = p.chromium.launch(
            channel="chrome",
            args=[
                "--use-fake-ui-for-media-stream",
                "--use-fake-device-for-media-stream",
                "--autoplay-policy=no-user-gesture-required",
                # getDisplayMedia: seçiciyi atla, sahte ekran akışı ver
                "--auto-select-desktop-capture-source=Entire screen",
                "--enable-usermedia-screen-capturing",
            ],
        )
        a_ctx = browser.new_context(viewport={"width": 1366, "height": 800}, permissions=["microphone"])
        # B bilerek dar: üye paneli eskiden 1280 px altında hiç görünmüyordu
        b_ctx = browser.new_context(viewport={"width": 1200, "height": 800}, permissions=["microphone"])
        a, b = a_ctx.new_page(), b_ctx.new_page()
        errors: list[str] = []
        for name, pg in (("A", a), ("B", b)):
            pg.on("pageerror", lambda e, n=name: errors.append(f"{n}: {e}"))

        print("1) Kayıt")
        register(a, f"alice{SUFFIX}")
        register(b, f"bob{SUFFIX}")
        step("iki kullanıcı kaydoldu ve giriş yaptı")

        print("2) Sunucu + davet")
        a.get_by_title("Sunucu oluştur veya katıl").click()
        a.get_by_placeholder("Kanka Sunucusu").fill("Test Ekibi")
        a.get_by_role("button", name="Oluştur", exact=True).click()
        expect(a.get_by_role("heading", name="Test Ekibi")).to_be_visible()
        a.get_by_role("button", name="Davet oluştur").click()
        code_input = a.locator("input[readonly]")
        expect(code_input).not_to_have_value("…")
        code = code_input.input_value()
        a.keyboard.press("Escape")
        b.get_by_title("Sunucu oluştur veya katıl").click()
        b.get_by_placeholder("ör. k7m2pq9xra").fill(code)
        b.get_by_role("button", name="Katıl", exact=True).click()
        expect(b.get_by_role("heading", name="Test Ekibi")).to_be_visible()
        step(f"sunucu oluşturuldu, B davet kodu ({code}) ile katıldı")

        print("3) Gerçek zamanlı mesaj")
        # Gateway bağlantılarının oturmasını bekle (B üye listesinde çevrimiçi görünmeli)
        expect(a.get_by_text("Çevrimiçi — 2")).to_be_visible(timeout=10_000)
        b.get_by_role("textbox", name="Mesaj").press_sequentially("yazıyorum")
        expect(a.get_by_text("yazıyor…")).to_be_visible(timeout=5_000)
        step("A, B'nin yazdığını gördü")
        b.get_by_role("textbox", name="Mesaj").fill("")
        a.get_by_role("textbox", name="Mesaj").fill("Selam Bob! <b>kalın değil</b>")
        a.get_by_role("textbox", name="Mesaj").press("Enter")
        expect(b.get_by_text("Selam Bob! <b>kalın değil</b>")).to_be_visible(timeout=5_000)
        step("B mesajı anında aldı (HTML düz metin olarak gösterildi)")
        b.get_by_role("textbox", name="Mesaj").fill("Aleyküm selam")
        b.get_by_role("textbox", name="Mesaj").press("Enter")
        expect(a.get_by_text("Aleyküm selam")).to_be_visible(timeout=5_000)
        step("A yanıtı anında aldı")

        print("4) Sesli görüşme (WebRTC P2P)")
        a.get_by_role("button", name="Sohbet").first.click()
        b.get_by_role("button", name="Sohbet").first.click()
        deadline = time.time() + 20
        ok = False
        while time.time() < deadline:
            sa, sb = voice_state(a), voice_state(b)
            pa, pb = list(sa["peers"].values()), list(sb["peers"].values())
            if sa["state"] == "connected" and sb["state"] == "connected" and pa and pb and pa[0]["state"] == "connected" and pb[0]["state"] == "connected" and pa[0]["bytesReceived"] > 2000 and pb[0]["bytesReceived"] > 2000:
                ok = True
                break
            time.sleep(0.5)
        if not ok:
            print("   ses durumu A:", voice_state(a))
            print("   ses durumu B:", voice_state(b))
            raise SystemExit("WebRTC bağlantısı kurulamadı")
        sa, sb = voice_state(a), voice_state(b)
        pa, pb = list(sa["peers"].values())[0], list(sb["peers"].values())[0]
        step(f"P2P bağlı — A aldı {pa['bytesReceived']} B, B aldı {pb['bytesReceived']} B, RTT≈{pa['rttMs']} ms, relay={pa['relayed']}")
        # Sahte mikrofonun bip sesi VAD'i tetikler → karşı tarafta konuşma halkası
        expect(b.locator(".speaking-ring").first).to_be_visible(timeout=8_000)
        step("konuşan kullanıcı göstergesi karşı tarafta görünüyor")
        a.screenshot(path=os.path.join(SHOTS, "yanki-a-voice.png"))

        # Susturma: A susturunca B'nin listesinde mikrofon kapalı ikonu görünür
        a.get_by_role("button", name="Mikrofonu kapat").click()
        expect(a.get_by_role("button", name="Mikrofonu aç")).to_be_visible()
        step("susturma çalışıyor")
        a.get_by_role("button", name="Mikrofonu aç").click()

        print("5) Soundboard")
        a.get_by_role("button", name="Ses paneli").click()
        a.get_by_text("+ Ses yükle").click()
        a.get_by_role("dialog", name="Ses yükle").locator('input[type="file"]').set_input_files(beep)
        a.locator('input[maxlength="32"]').first.fill("Bip")
        a.get_by_role("button", name="Yükle", exact=True).click()
        expect(a.get_by_text("Ses yüklendi")).to_be_visible(timeout=10_000)
        sound_btn = a.get_by_title("Bip — sağ tık: önizle")
        expect(sound_btn).to_be_visible(timeout=5_000)
        time.sleep(1.0)  # önbellek ısınsın
        sound_btn.click()
        deadline = time.time() + 8
        while time.time() < deadline:
            ha = a.evaluate("() => window.__yanki.sounds()")
            hb = b.evaluate("() => window.__yanki.sounds()")
            if ha and hb:
                break
            time.sleep(0.2)
        if not (ha and hb):
            raise SystemExit(f"soundboard sesi iki tarafta da çalınmadı: A={ha} B={hb}")
        step(f"ses iki istemcide de planlandı — A sapma {ha[-1]['scheduledDelayMs']:.0f} ms, B sapma {hb[-1]['scheduledDelayMs']:.0f} ms (pozitif = zamanında)")
        # Cooldown: hemen tekrar basılırsa düğme devre dışı
        expect(sound_btn).to_be_disabled()
        step("istemci tarafı cooldown aktif")
        b.screenshot(path=os.path.join(SHOTS, "yanki-b-soundboard.png"))
        a.screenshot(path=os.path.join(SHOTS, "yanki-a-soundboard.png"))


        print("6) Ekran paylaşımı (P2P, izleyici isteğe bağlı)")
        a.keyboard.press("Escape")
        a.get_by_role("button", name="Ekran paylaş").click()
        a.get_by_role("button", name="720p").click()
        a.get_by_role("button", name="30 FPS").click()
        a.get_by_role("button", name="Yayını başlat").click()
        expect(a.get_by_role("button", name="Paylaşımı durdur")).to_be_visible(timeout=10_000)
        live = b.get_by_title("Yayını izle")
        expect(live).to_be_visible(timeout=5_000)
        step("A yayına başladı, B kanalda CANLI rozetini görüyor")
        live.click()
        deadline = time.time() + 15
        w = 0
        while time.time() < deadline:
            w = b.evaluate("() => document.querySelector('[data-testid=stream-tile] video')?.videoWidth ?? 0")
            if w > 0:
                break
            time.sleep(0.3)
        if not w:
            raise SystemExit("yayın görüntüsü B'ye ulaşmadı")
        try:
            expect(a.get_by_text("Senin yayının · 1 izleyici")).to_be_visible(timeout=10_000)
        except AssertionError:
            print("   A sahnesi:", a.locator("[data-testid=stream-tile]").all_inner_texts(), a.evaluate("() => document.querySelectorAll('section[aria-label=Yayınlar]').length"))
            raise
        step(f"B yayını izliyor (gelen görüntü genişliği {w}px), A'da 1 izleyici görünüyor; ses bağlantısı sürüyor: {voice_state(a)['state']}")
        b.screenshot(path=os.path.join(SHOTS, "yanki-b-stream.png"))
        a.get_by_role("button", name="Paylaşımı durdur").click()
        expect(b.locator("[data-testid=stream-tile]")).to_have_count(0, timeout=5_000)
        step("A yayını durdurdu, B'nin görüntüsü kapandı")

        print("7) Sunucu moderasyonu")
        a.locator("aside:not([aria-label]) ul li").filter(has_text=f"Bob{SUFFIX}").get_by_role("button").first.click()
        a.get_by_role("menu").get_by_role("button", name="Sunucuda sustur").click()
        expect(b.get_by_text("Bir yetkili seni sunucuda susturdu.")).to_be_visible(timeout=5_000)
        step("A (sahip) B'yi sunucuda susturdu, B'ye bildirildi")
        a.keyboard.press("Escape")
        a.locator("aside:not([aria-label]) ul li").filter(has_text=f"Bob{SUFFIX}").get_by_role("button").first.click()
        a.get_by_role("menu").get_by_role("button", name="Sunucu susturmasını kaldır").click()
        expect(b.get_by_text("Bir yetkili seni sunucuda susturdu.")).to_have_count(0, timeout=5_000)
        a.keyboard.press("Escape")
        step("susturma kaldırıldı")


        print("7b) Üye paneli, giriş sesleri ve odadan odaya taşıma")
        expect(b.get_by_role("complementary", name="Üyeler")).to_be_visible()
        expect(b.get_by_role("complementary", name="Üyeler").get_by_text("· 2 seste")).to_be_visible(timeout=5_000)
        step("dar pencerede (1200 px) üye paneli görünüyor, '2 seste' gösteriyor")
        cues_a = [c["cue"] for c in a.evaluate("() => window.__yanki.cues()")]
        cues_b = [c["cue"] for c in b.evaluate("() => window.__yanki.cues()")]
        assert "self-join" in cues_a, cues_a
        assert "self-join" in cues_b, cues_b
        step("ikisinde de 'bağlandın' sesi çaldı")
        a.get_by_role("button", name="Kanal ekle", exact=True).last.click()
        dlg = a.get_by_role("dialog", name="Kanal oluştur")
        dlg.get_by_role("button", name="Ses", exact=True).click()
        dlg.get_by_label("Ad").fill("Oyun")
        dlg.get_by_role("button", name="Oluştur").click()
        oyun = a.locator('[data-voice-channel="Oyun"]')
        expect(oyun).to_be_visible(timeout=5_000)
        bob_row = a.locator(f'[data-voice-user="Bob{SUFFIX}"]')
        bob_row.drag_to(oyun)
        deadline = time.time() + 15
        while time.time() < deadline:
            st = b.evaluate("() => { const v = window.__yanki.voice(); return { state: v.state, ch: v.channelId } }")
            names = a.evaluate("() => [...document.querySelectorAll('[data-voice-user]')].map(e => [e.dataset.voiceUser, e.closest('div')?.previousElementSibling?.dataset?.voiceChannel ?? e.parentElement?.previousElementSibling?.dataset?.voiceChannel])")
            if st["state"] == "connected" and any(n == f"Bob{SUFFIX}" and c == "Oyun" for n, c in names):
                break
            time.sleep(0.3)
        else:
            raise SystemExit(f"sürükle-bırak taşıma başarısız: B={st} liste={names}")
        expect(b.get_by_text("Bir yetkili seni başka kanala taşıdı")).to_be_visible(timeout=5_000)
        step("A, B'yi sürükleyip 'Oyun' kanalına bıraktı → B yeni kanala bağlandı ve haber aldı")
        time.sleep(0.5)
        assert "leave" in [c["cue"] for c in a.evaluate("() => window.__yanki.cues()")]
        step("B odadan çıkınca A'da çıkış sesi çaldı")
        # Sağ tık menüsüyle geri taşı
        a.locator(f'[data-voice-user="Bob{SUFFIX}"] > div').click(button="right")
        menu = a.get_by_role("menu")
        menu.get_by_role("button", name="Başka kanala taşı").click()
        menu.get_by_role("button", name="Sohbet", exact=True).click()
        deadline = time.time() + 15
        while time.time() < deadline:
            if b.evaluate("() => window.__yanki.voice().state") == "connected" and voice_state(a)["peers"] and list(voice_state(a)["peers"].values())[0]["state"] == "connected":
                break
            time.sleep(0.3)
        else:
            raise SystemExit("sağ tık menüsüyle geri taşıma başarısız")
        step("sağ tık → 'Başka kanala taşı' → 'Sohbet' ile B geri geldi ve ses bağlantısı yeniden kuruldu")
        time.sleep(0.5)
        cues_a = [c["cue"] for c in a.evaluate("() => window.__yanki.cues()")]
        assert cues_a[-1] == "join", cues_a
        cues_b = [c["cue"] for c in b.evaluate("() => window.__yanki.cues()")]
        step(f"B geri girince A'da giriş sesi çaldı (A: {cues_a}, B: {cues_b})")
        a.keyboard.press("Escape")

        print("7c) AFK odası")
        a.get_by_role("button", name="Sunucu ayarları").click()
        sdlg = a.get_by_role("dialog")
        sdlg.get_by_label("AFK kanalı").select_option(label="🔊 Oyun")
        expect(a.get_by_text("AFK ayarı kaydedildi").first).to_be_visible(timeout=5_000)
        a.keyboard.press("Escape")
        expect(a.locator('[data-voice-channel="Oyun"]').get_by_text("AFK", exact=True)).to_be_visible(timeout=5_000)
        step("A, 'Oyun' kanalını AFK odası yaptı; kanal listesinde AFK rozeti çıktı")
        a.locator(f'[data-voice-user="Bob{SUFFIX}"]').drag_to(a.locator('[data-voice-channel="Oyun"]'))
        expect(b.get_by_role("alert").get_by_text("AFK odasına taşındın")).to_be_visible(timeout=15_000)
        deadline = time.time() + 5
        while time.time() < deadline and b.evaluate("() => window.__yanki.afk()") != "builtin":
            time.sleep(0.2)
        assert b.evaluate("() => window.__yanki.afk()") == "builtin"
        assert a.evaluate("() => window.__yanki.afk()") is None
        step("B AFK odasına taşınınca B'de yerleşik alarm döngüde çalmaya başladı (A'da çalmıyor)")
        a.get_by_role("button", name="Sunucu ayarları").click()
        sdlg = a.get_by_role("dialog")
        alarm = sdlg.get_by_label("Alarm sesi")
        sound_label = alarm.locator("option").nth(1).inner_text()
        alarm.select_option(index=1)
        expect(a.get_by_text("AFK ayarı kaydedildi").first).to_be_visible(timeout=5_000)
        a.keyboard.press("Escape")
        deadline = time.time() + 10
        while time.time() < deadline:
            playing = b.evaluate("() => window.__yanki.afk()")
            if playing not in (None, "builtin"):
                break
            time.sleep(0.2)
        else:
            raise SystemExit(f"alarm sesi değişmedi: {playing}")
        step(f"A alarm sesini soundboard'dan '{sound_label.strip()}' yaptı → B'de alarm anında o sese geçti")
        b.get_by_role("button", name="Uyandım, geri dön").click()
        deadline = time.time() + 15
        while time.time() < deadline:
            st = b.evaluate("() => ({ s: window.__yanki.voice().state, afk: window.__yanki.afk() })")
            if st["s"] == "connected" and st["afk"] is None:
                break
            time.sleep(0.3)
        else:
            raise SystemExit(f"Uyandım çalışmadı: {st}")
        expect(b.get_by_role("alert").get_by_text("AFK odasına taşındın")).to_have_count(0)
        step("B 'Uyandım, geri dön' dedi → alarm sustu, B önceki odaya ('Sohbet') döndü")

        print("8) Makro (tarayıcıda pencere içi)")
        b.get_by_role("button", name="Ayarlar").first.click()
        b.get_by_role("button", name="Mikrofonu aç/kapat ata").click()
        b.keyboard.press("F8")
        expect(b.get_by_text("F8", exact=True)).to_be_visible()
        b.get_by_role("button", name="Kapat").last.click()
        b.keyboard.press("F8")
        expect(b.get_by_role("button", name="Mikrofonu aç")).to_be_visible(timeout=3_000)
        b.keyboard.press("F8")
        expect(b.get_by_role("button", name="Mikrofonu kapat")).to_be_visible(timeout=3_000)
        step("F8 makrosu mikrofonu kapatıp açtı")

        print("9) Tepki, ek ve arama")
        msg = b.locator("[data-testid=message]").filter(has_text="Selam Bob!")
        msg.hover()
        msg.get_by_title("Tepki ekle").click()
        b.get_by_role("button", name="🔥 tepkisi").click()
        expect(a.locator("[data-testid=message]").filter(has_text="Selam Bob!").get_by_role("button", name="🔥 1")).to_be_visible(timeout=5_000)
        step("B'nin 🔥 tepkisi A'da anında göründü")
        png = os.path.join(tempfile.gettempdir(), "yanki-kare.png")
        with open(png, "wb") as f:
            import base64
            f.write(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="))
        a.locator('main input[type="file"]').set_input_files(png)
        a.get_by_role("textbox", name="Mesaj").fill("ekran görüntüsü")
        a.get_by_role("textbox", name="Mesaj").press("Enter")
        expect(b.get_by_role("button", name="Resim: yanki-kare.png")).to_be_visible(timeout=8_000)
        step("A'nın gönderdiği resim B'de satır içi göründü")
        b.get_by_role("button", name="Mesajlarda ara").click()
        b.get_by_label("Arama").fill("aleykum")
        b.get_by_label("Arama").press("Enter")
        expect(b.locator("[data-testid=search-result]").filter(has_text="Aleyküm selam")).to_be_visible(timeout=5_000)
        b.keyboard.press("Escape")
        step("aksansız arama ('aleykum') 'Aleyküm selam' mesajını buldu")

        print("10) Arkadaşlık ve özel mesaj")
        a.get_by_role("button", name="Ana sayfa").click()
        a.get_by_role("button", name="Arkadaş ekle").click()
        a.get_by_label("Kullanıcı adı").fill(f"bob{SUFFIX}")
        a.get_by_role("button", name="İstek gönder").click()
        b.get_by_role("button", name="Ana sayfa").click()
        b.get_by_role("button", name="Bekleyen (1)").click()
        b.get_by_role("button", name="Kabul et").click()
        expect(a.get_by_role("button", name="Tümü")).to_be_visible()
        a.get_by_role("button", name="Tümü").click()
        expect(a.locator("[data-testid=friend-row]").filter(has_text=f"Bob{SUFFIX}")).to_be_visible(timeout=5_000)
        step("arkadaşlık isteği gönderildi ve gerçek zamanlı kabul edildi")
        a.locator("[data-testid=friend-row]").filter(has_text=f"Bob{SUFFIX}").get_by_role("button", name="Mesaj gönder").click()
        a.get_by_role("textbox", name="Mesaj").fill("Bu özel bir mesaj")
        a.get_by_role("textbox", name="Mesaj").press("Enter")
        b.locator("aside").get_by_role("button", name=f"Alice{SUFFIX}").click()
        expect(b.get_by_text("Bu özel bir mesaj")).to_be_visible(timeout=5_000)
        b.get_by_role("textbox", name="Mesaj").fill("dm cevap")
        b.get_by_role("textbox", name="Mesaj").press("Enter")
        expect(a.get_by_text("dm cevap")).to_be_visible(timeout=5_000)
        step("özel mesajlar iki yönde anında iletildi")
        a.screenshot(path=os.path.join(SHOTS, "yanki-a-dm.png"))
        a.get_by_role("button", name="Test Ekibi").click()
        b.get_by_role("button", name="Test Ekibi").click()
        a.get_by_role("button", name="Bağlantıyı kes").click()
        # B'nin kenar çubuğundaki ses kanalı katılımcı listesinde A artık olmamalı
        expect(b.locator("aside:not([aria-label]) ul li").filter(has_text=f"Alice{SUFFIX}")).to_have_count(0, timeout=5_000)
        expect(b.locator("aside:not([aria-label]) ul li").filter(has_text=f"Bob{SUFFIX}")).to_have_count(1)
        step("A sesli kanaldan ayrıldı, B'de görünmüyor")

        if errors:
            print("Sayfa hataları:", *errors, sep="\n  ")
            return 1
        browser.close()
    print("\nTÜM ADIMLAR GEÇTİ")
    return 0


if __name__ == "__main__":
    sys.exit(main())
