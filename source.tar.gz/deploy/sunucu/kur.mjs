// Yankı sunucusunu Cloudflare'e kurar / günceller. Tekrar çalıştırmak güvenlidir.
// Gereken tek şey Node.js 20+ (wrangler'ı npx otomatik indirir).
import { spawn } from "node:child_process";
import { randomBytes } from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const DIR = dirname(fileURLToPath(import.meta.url));
const CONFIG = join(DIR, "wrangler.jsonc");
const SECRETS = join(DIR, ".yanki-gizli.json");
const DB_NAME = "yanki-db";
const PLACEHOLDER = "00000000-0000-0000-0000-000000000000";
// Test için geçersiz kılınabilir: YANKI_WRANGLER="node sahte-wrangler.mjs"
const WRANGLER = process.env.YANKI_WRANGLER ?? "npx --yes wrangler@4.158.0";

const c = { g: "\x1b[32m", y: "\x1b[33m", r: "\x1b[31m", b: "\x1b[1m", x: "\x1b[0m" };
const step = (n, msg) => console.log(`\n${c.b}[${n}/6] ${msg}${c.x}`);
const ok = (msg) => console.log(`${c.g}✓ ${msg}${c.x}`);
/** Yeni hesaplarda sık görülen yetki hatası (e-posta doğrulanmamış / Workers etkinleştirilmemiş). */
const AUTH_HELP =
  "Cloudflare 'Authentication error [code: 10000]' döndürdü. Yeni hesaplarda bunun sebebi neredeyse her zaman:\n" +
  "  1) E-posta adresin doğrulanmamış: Cloudflare'in gönderdiği e-postadaki bağlantıya tıkla (gereksiz/spam klasörüne de bak).\n" +
  "     Panelde üstte 'verify your email' uyarısı varsa oradan tekrar gönderebilirsin.\n" +
  "  2) Workers hiç açılmamış: https://dash.cloudflare.com → soldan 'Workers & Pages' sayfasına bir kez gir,\n" +
  "     isterse bir workers.dev alt alan adı seç.\n" +
  "İkisini yaptıktan sonra KUR.bat'ı tekrar çalıştır (giriş tekrar istenmez, kaldığı yerden devam eder).";
const isAuthError = (out) => /code:\s*10000|Authentication error/i.test(out);
const fail = (msg) => {
  console.error(`\n${c.r}✗ ${msg}${c.x}\n`);
  process.exit(1);
};

/** wrangler'ı çalıştırır. capture: çıktıyı hem gösterir hem döndürür (etkileşimsiz). */
function wrangler(args, { capture = false, quiet = false } = {}) {
  return new Promise((resolve) => {
    const child = spawn(`${WRANGLER} ${args}`, {
      cwd: DIR,
      shell: true,
      stdio: capture ? ["inherit", "pipe", "pipe"] : "inherit",
      env: { ...process.env, CI: capture ? "true" : process.env.CI ?? "", WRANGLER_SEND_METRICS: "false" },
    });
    let out = "";
    if (capture) {
      const tee = (stream, sink) =>
        child[stream].on("data", (d) => {
          out += d.toString();
          if (!quiet) sink.write(d);
        });
      tee("stdout", process.stdout);
      tee("stderr", process.stderr);
    }
    child.on("close", (code) => resolve({ code: code ?? 1, out }));
    child.on("error", () => resolve({ code: 1, out }));
  });
}

async function main() {
  console.log(`${c.b}Yankı sunucu kurulumu${c.x} — ücretsiz Cloudflare hesabına kurulur, kart gerekmez.`);
  const major = Number(process.versions.node.split(".")[0]);
  if (major < 20) fail(`Node.js 20 veya üstü gerekli (sende ${process.versions.node}). https://nodejs.org adresinden LTS sürümünü kur.`);

  // 1) Giriş
  step(1, "Cloudflare hesabına giriş");
  const who = await wrangler("whoami --json", { capture: true, quiet: true });
  if (who.code !== 0) {
    console.log("Tarayıcı açılacak: Cloudflare'e giriş yap (hesabın yoksa ücretsiz oluştur) ve 'Allow' de.");
    const login = await wrangler("login");
    if (login.code !== 0) fail("Giriş tamamlanamadı. Tekrar dene.");
  }
  ok("giriş yapıldı");

  // 2) Veritabanı (varsa yeniden kullanılır)
  step(2, "Veritabanı (D1)");
  let config = readFileSync(CONFIG, "utf8");
  let dbId = /"database_id":\s*"([0-9a-f-]{36})"/.exec(config)?.[1];
  if (!dbId || dbId === PLACEHOLDER) {
    const list = await wrangler("d1 list --json", { capture: true, quiet: true });
    try {
      const dbs = JSON.parse(list.out.slice(list.out.indexOf("[")));
      dbId = dbs.find((d) => d.name === DB_NAME)?.uuid;
    } catch {
      dbId = undefined;
    }
    if (!dbId) {
      let created = await wrangler(`d1 create ${DB_NAME}`, { capture: true });
      // Girişten hemen sonra token birkaç saniye geç etkinleşebiliyor: bir kez daha dene
      if (created.code !== 0 && isAuthError(created.out)) {
        console.log("Birkaç saniye bekleyip tekrar deneniyor…");
        await new Promise((r) => setTimeout(r, 8000));
        created = await wrangler(`d1 create ${DB_NAME}`, { capture: true });
      }
      dbId = /"?database_id"?\s*[:=]\s*"([0-9a-f-]{36})"/.exec(created.out)?.[1];
      if (!dbId) fail(isAuthError(created.out) ? AUTH_HELP : "Veritabanı oluşturulamadı (yukarıdaki hataya bak).");
    }
    config = config.replace(PLACEHOLDER, dbId);
    writeFileSync(CONFIG, config);
  }
  ok(`veritabanı hazır (${dbId})`);

  // 3) Gizli anahtar (bir kez üretilir, bu klasörde saklanır)
  step(3, "Gizli anahtar");
  if (!existsSync(SECRETS)) {
    writeFileSync(SECRETS, JSON.stringify({ APP_SECRET: randomBytes(32).toString("hex") }, null, 2));
    ok("yeni anahtar üretildi (.yanki-gizli.json — bu dosyayı kimseyle paylaşma)");
  } else ok("mevcut anahtar kullanılıyor");

  // 4) Tablolar
  step(4, "Veritabanı tabloları");
  const mig = await wrangler(`d1 migrations apply ${DB_NAME} --remote`, { capture: true });
  if (mig.code !== 0) fail(isAuthError(mig.out) ? AUTH_HELP : "Tablolar oluşturulamadı (yukarıdaki hataya bak).");
  ok("tablolar güncel");

  // 5) Yükleme
  step(5, "Sunucuyu yükleme");
  const dep = await wrangler("deploy --secrets-file .yanki-gizli.json", { capture: true });
  if (dep.code !== 0) {
    if (/workers\.dev subdomain|register a workers\.dev/i.test(dep.out)) {
      fail(
        "Hesabında henüz workers.dev alt alanı yok. https://dash.cloudflare.com adresinde soldan 'Workers & Pages'e bir kez gir, " +
          "istediği alt alan adını seç, sonra KUR.bat'ı tekrar çalıştır.",
      );
    }
    fail(isAuthError(dep.out) ? AUTH_HELP : "Yükleme başarısız (yukarıdaki hataya bak).");
  }
  const url = /https:\/\/[a-z0-9.-]+\.workers\.dev/i.exec(dep.out)?.[0];
  if (!url) fail("Yükleme bitti ama adres okunamadı. Cloudflare panelinde Workers & Pages → yanki-server altında adresi görebilirsin.");
  ok("yüklendi");

  // 6) Sağlık kontrolü (yeni alt alanların yayılması bir dakikayı bulabilir)
  step(6, "Sunucu çalışıyor mu?");
  let healthy = false;
  const tries = Number(process.env.YANKI_HEALTH_TRIES ?? 12);
  for (let i = 0; i < tries && !healthy; i++) {
    try {
      const r = await fetch(`${url}/api/health`);
      healthy = r.ok;
    } catch {
      /* DNS henüz yayılmadı */
    }
    if (!healthy) await new Promise((r) => setTimeout(r, 5000));
  }
  writeFileSync(join(DIR, "sunucu-adresi.txt"), `${url}\n`);
  if (healthy) ok("sunucu yanıt veriyor");
  else console.log(`${c.y}! Sunucu henüz yanıt vermedi; birkaç dakika içinde açılır.${c.x}`);

  console.log(`\n${c.g}${c.b}KURULUM TAMAM${c.x}\n`);
  console.log(`Sunucu adresin:  ${c.b}${url}${c.x}`);
  console.log("(sunucu-adresi.txt dosyasına da yazıldı)\n");
  console.log("Yankı uygulamasını aç → giriş ekranında sağ alttaki 'Sunucu' → bu adresi yapıştır → Kayıt ol.");
  console.log("Arkadaşlarına da uygulamayı ve bu adresi gönder.\n");
}

main().catch((err) => fail(String(err?.stack ?? err)));
