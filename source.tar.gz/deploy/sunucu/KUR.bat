@echo off
chcp 65001 >nul
title Yanki sunucu kurulumu
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js bulunamadi. Acilan sayfadan LTS surumunu kur, sonra bu dosyayi tekrar calistir.
  start https://nodejs.org/tr/download
  pause
  exit /b 1
)
node kur.mjs
echo.
pause
