#!/usr/bin/env bash
# Yankı sunucu kurulum paketini üretir: deploy/sunucu → Yanki-Sunucu-Kurulum.zip
# Worker önceden tek dosyaya derlenir; kullanıcının bilgisayarında yalnızca Node.js gerekir.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/deploy/sunucu"
TMP="$(mktemp -d)"
(cd "$ROOT/apps/server" && npx wrangler deploy --dry-run --outdir "$TMP" >/dev/null)
cp "$TMP/index.js" "$OUT/worker.js"
rm -rf "$OUT/migrations" && cp -r "$ROOT/apps/server/migrations" "$OUT/migrations"
rm -rf "$TMP"
echo "derlendi: $OUT/worker.js ($(du -h "$OUT/worker.js" | cut -f1))"
