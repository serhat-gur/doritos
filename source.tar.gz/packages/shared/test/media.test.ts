import { describe, expect, it } from "vitest";
import { EmojiSchema } from "../src/schemas";
import { sniffImageMime } from "../src/sound-sniff";

const pad = (b: number[]) => new Uint8Array([...b, ...new Array(16).fill(0)]);

describe("sniffImageMime", () => {
  it("PNG/JPEG/GIF/WebP tanır", () => {
    expect(sniffImageMime(pad([0x89, 0x50, 0x4e, 0x47]))).toBe("image/png");
    expect(sniffImageMime(pad([0xff, 0xd8, 0xff]))).toBe("image/jpeg");
    expect(sniffImageMime(pad([...Buffer.from("GIF89a")]))).toBe("image/gif");
    expect(sniffImageMime(pad([...Buffer.from("RIFF"), 0, 0, 0, 0, ...Buffer.from("WEBP")]))).toBe("image/webp");
  });
  it("SVG ve HTML'i reddeder (betik içerebilir)", () => {
    expect(sniffImageMime(pad([...Buffer.from("<svg onload=")]))).toBeNull();
    expect(sniffImageMime(pad([...Buffer.from("<!doctype html>")]))).toBeNull();
  });
});

describe("EmojiSchema", () => {
  it("tekli ve birleşik emojileri kabul eder", () => {
    for (const e of ["👍", "❤️", "👍🏽", "👨‍👩‍👧", "🇹🇷"]) expect(EmojiSchema.safeParse(e).success, e).toBe(true);
  });
  it("harf, rakam ve metni reddeder", () => {
    for (const e of ["a", "lol", "1", "#", " ", "<b>"]) expect(EmojiSchema.safeParse(e).success, e).toBe(false);
  });
});
