import { describe, expect, it } from "vitest";
import {
  ALL_PERMISSIONS,
  computeBasePermissions,
  computeChannelPermissions,
  DEFAULT_EVERYONE_PERMISSIONS,
  hasFlag,
  Permission,
  type PermissionContext,
} from "../src/permissions";

const G = "guild1";
const roles = [
  { id: G, permissions: DEFAULT_EVERYONE_PERMISSIONS, position: 0 },
  { id: "mod", permissions: Permission.MANAGE_MESSAGES | Permission.MUTE_MEMBERS, position: 2 },
  { id: "admin", permissions: Permission.ADMINISTRATOR, position: 3 },
  { id: "muted", permissions: 0, position: 1 },
];

function ctx(over: Partial<PermissionContext> = {}): PermissionContext {
  return { isOwner: false, userId: "u1", everyoneRoleId: G, roles, memberRoleIds: [], ...over };
}

describe("computeBasePermissions", () => {
  it("sahip tüm izinlere sahiptir", () => {
    expect(computeBasePermissions(ctx({ isOwner: true }))).toBe(ALL_PERMISSIONS);
  });
  it("@everyone + atanmış roller birleştirilir", () => {
    const p = computeBasePermissions(ctx({ memberRoleIds: ["mod"] }));
    expect(hasFlag(p, Permission.SEND_MESSAGES)).toBe(true);
    expect(hasFlag(p, Permission.MANAGE_MESSAGES)).toBe(true);
    expect(hasFlag(p, Permission.MANAGE_ROLES)).toBe(false);
  });
  it("ADMINISTRATOR tüm izinleri verir", () => {
    expect(computeBasePermissions(ctx({ memberRoleIds: ["admin"] }))).toBe(ALL_PERMISSIONS);
  });
  it("atanmamış rollerin izinleri sayılmaz", () => {
    const p = computeBasePermissions(ctx());
    expect(hasFlag(p, Permission.MANAGE_MESSAGES)).toBe(false);
  });
});

describe("computeChannelPermissions", () => {
  it("@everyone deny ile özel kanal gizlenir", () => {
    const p = computeChannelPermissions(ctx(), [
      { targetType: "role", targetId: G, allow: 0, deny: Permission.VIEW_CHANNEL },
    ]);
    expect(p).toBe(0);
  });
  it("rol allow, @everyone deny'ı geçersiz kılar", () => {
    const p = computeChannelPermissions(ctx({ memberRoleIds: ["mod"] }), [
      { targetType: "role", targetId: G, allow: 0, deny: Permission.VIEW_CHANNEL },
      { targetType: "role", targetId: "mod", allow: Permission.VIEW_CHANNEL, deny: 0 },
    ]);
    expect(hasFlag(p, Permission.VIEW_CHANNEL)).toBe(true);
    expect(hasFlag(p, Permission.SEND_MESSAGES)).toBe(true);
  });
  it("üye overwrite en son uygulanır", () => {
    const p = computeChannelPermissions(ctx({ memberRoleIds: ["mod"] }), [
      { targetType: "role", targetId: "mod", allow: Permission.PLAY_SOUNDS, deny: 0 },
      { targetType: "member", targetId: "u1", allow: 0, deny: Permission.PLAY_SOUNDS },
    ]);
    expect(hasFlag(p, Permission.PLAY_SOUNDS)).toBe(false);
  });
  it("rol deny, @everyone allow'u ezer", () => {
    const p = computeChannelPermissions(ctx({ memberRoleIds: ["muted"] }), [
      { targetType: "role", targetId: "muted", allow: 0, deny: Permission.SPEAK | Permission.SEND_MESSAGES },
    ]);
    expect(hasFlag(p, Permission.SPEAK)).toBe(false);
    expect(hasFlag(p, Permission.SEND_MESSAGES)).toBe(false);
    expect(hasFlag(p, Permission.VIEW_CHANNEL)).toBe(true);
  });
  it("admin overwrite'lardan etkilenmez", () => {
    const p = computeChannelPermissions(ctx({ memberRoleIds: ["admin"] }), [
      { targetType: "role", targetId: G, allow: 0, deny: Permission.VIEW_CHANNEL },
    ]);
    expect(p).toBe(ALL_PERMISSIONS);
  });
});
