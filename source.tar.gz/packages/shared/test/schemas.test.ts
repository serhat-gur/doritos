import { describe, expect, it } from "vitest";
import { ClientEvent } from "../src/events";
import { RegisterInput, SendMessageInput } from "../src/schemas";
import { sniffSoundMime } from "../src/sound-sniff";

describe("şemalar", () => {
  it("geçersiz kullanıcı adını reddeder", () => {
    expect(RegisterInput.safeParse({ username: "Ali Veli", displayName: "Ali", password: "12345678" }).success).toBe(false);
    expect(RegisterInput.safeParse({ username: "ali.veli", displayName: "Ali", password: "12345678" }).success).toBe(true);
  });
  it("mesaj metnini kırpar; boşluk-only metin boş dizeye iner (yalnızca ekli mesaj için)", () => {
    // Boş mesajın (metin de ek de yoksa) reddi rotada yapılır: apps/server/test/social.test.ts
    expect(SendMessageInput.parse({ content: "   " }).content).toBe("");
    expect(SendMessageInput.parse({ content: "  selam " }).content).toBe("selam");
    expect(SendMessageInput.safeParse({ content: "x".repeat(4001) }).success).toBe(false);
  });
  it("istemci olaylarını ayrıştırır", () => {
    expect(ClientEvent.safeParse({ t: "sound.play", soundId: "s1" }).success).toBe(true);
    expect(ClientEvent.safeParse({ t: "sound.play" }).success).toBe(false);
    expect(ClientEvent.safeParse({ t: "unknown" }).success).toBe(false);
    expect(
      ClientEvent.safeParse({ t: "rtc.signal", to: "u2", data: { kind: "description", type: "offer", sdp: "v=0" } }).success,
    ).toBe(true);
  });
});

describe("sniffSoundMime", () => {
  const pad = (b: number[]) => new Uint8Array([...b, ...new Array(16).fill(0)]);
  it("WAV/OGG/MP3 tanır", () => {
    expect(sniffSoundMime(pad([...Buffer.from("RIFF"), 0, 0, 0, 0, ...Buffer.from("WAVE")]))).toBe("audio/wav");
    expect(sniffSoundMime(pad([...Buffer.from("OggS")]))).toBe("audio/ogg");
    expect(sniffSoundMime(pad([...Buffer.from("ID3")]))).toBe("audio/mpeg");
    expect(sniffSoundMime(pad([0xff, 0xfb, 0x90]))).toBe("audio/mpeg");
  });
  it("ses olmayan içeriği reddeder", () => {
    expect(sniffSoundMime(pad([...Buffer.from("<html>")]))).toBeNull();
    expect(sniffSoundMime(pad([0x4d, 0x5a]))).toBeNull(); // EXE
  });
});
