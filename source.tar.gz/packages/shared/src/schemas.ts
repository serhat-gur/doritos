import { z } from "zod";
import { LIMITS } from "./limits";

// ---------- Ortak ----------
export const IdSchema = z.string().min(1).max(64);

export const UsernameSchema = z
  .string()
  .min(LIMITS.USERNAME_MIN)
  .max(LIMITS.USERNAME_MAX)
  .regex(/^[a-z0-9_.]+$/, "Kullanıcı adı yalnızca küçük harf, rakam, '_' ve '.' içerebilir");

export const PasswordSchema = z.string().min(LIMITS.PASSWORD_MIN).max(LIMITS.PASSWORD_MAX);

// ---------- Auth ----------
export const RegisterInput = z.object({
  username: UsernameSchema,
  displayName: z.string().trim().min(1).max(LIMITS.DISPLAY_NAME_MAX),
  password: PasswordSchema,
});
export type RegisterInput = z.infer<typeof RegisterInput>;

export const LoginInput = z.object({
  username: z.string().min(1).max(LIMITS.USERNAME_MAX),
  password: z.string().min(1).max(LIMITS.PASSWORD_MAX),
});
export type LoginInput = z.infer<typeof LoginInput>;

export const PresenceStatus = z.enum(["online", "busy", "idle", "invisible"]);
export type PresenceStatus = z.infer<typeof PresenceStatus>;

// ---------- Guild / Channel ----------
export const CreateGuildInput = z.object({
  name: z.string().trim().min(1).max(LIMITS.GUILD_NAME_MAX),
});
export type CreateGuildInput = z.infer<typeof CreateGuildInput>;

/** Sunucu ayarları güncellemesi. AFK kanalı / AFK alarm sesi `null` ile kaldırılır. */
export const UpdateGuildInput = z.object({
  name: z.string().trim().min(1).max(LIMITS.GUILD_NAME_MAX).optional(),
  afkChannelId: IdSchema.nullable().optional(),
  afkSoundId: IdSchema.nullable().optional(),
});
export type UpdateGuildInput = z.infer<typeof UpdateGuildInput>;

export const ChannelType = z.enum(["text", "voice", "category"]);
export type ChannelType = z.infer<typeof ChannelType>;

export const CreateChannelInput = z.object({
  name: z
    .string()
    .trim()
    .min(1)
    .max(LIMITS.CHANNEL_NAME_MAX),
  type: ChannelType,
  parentId: IdSchema.nullable().optional(),
  isPrivate: z.boolean().optional(),
});
export type CreateChannelInput = z.infer<typeof CreateChannelInput>;

export const UpdateChannelInput = z.object({
  name: z.string().trim().min(1).max(LIMITS.CHANNEL_NAME_MAX).optional(),
  parentId: IdSchema.nullable().optional(),
  position: z.number().int().min(0).max(100_000).optional(),
});
export type UpdateChannelInput = z.infer<typeof UpdateChannelInput>;

export const CreateInviteInput = z.object({
  maxUses: z.number().int().min(0).max(1000).optional(),
  expiresInHours: z.number().int().min(1).max(24 * 30).optional(),
});
export type CreateInviteInput = z.infer<typeof CreateInviteInput>;

// ---------- Messages ----------
export const SendMessageInput = z.object({
  /** Ek varsa boş olabilir; yoksa en az 1 karakter (route'ta kontrol edilir). */
  content: z.string().trim().max(LIMITS.MESSAGE_MAX).default(""),
  replyToId: IdSchema.nullable().optional(),
  nonce: z.string().max(64).optional(),
});
export type SendMessageInput = z.infer<typeof SendMessageInput>;

/** Tek bir emoji (birleşik emojiler dahil); harf/rakam/boşluk kabul edilmez. */
export const EmojiSchema = z
  .string()
  .min(1)
  .max(32)
  .regex(/^[\p{Extended_Pictographic}\p{Emoji_Component}\u200d\ufe0f\u20e3]+$/u, "Geçersiz emoji")
  .refine((s) => !/^[0-9#*]+$/.test(s), "Geçersiz emoji");

export const CreateRoleInput = z.object({
  name: z.string().trim().min(1).max(32),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullable().optional(),
  permissions: z.number().int().min(0),
});
export const UpdateRoleInput = CreateRoleInput.partial().extend({ position: z.number().int().min(1).max(1000).optional() });

export const FriendRequestInput = z.object({ username: z.string().trim().min(1).max(LIMITS.USERNAME_MAX) });
export const CreateDmInput = z.object({
  userIds: z.array(IdSchema).min(1).max(LIMITS.GROUP_DM_MAX_MEMBERS - 1),
  name: z.string().trim().max(64).optional(),
});
export const SearchQuery = z.object({
  q: z.string().trim().min(2).max(100),
  channelId: IdSchema.optional(),
});
export const BanInput = z.object({ reason: z.string().max(200).optional() });

export const EditMessageInput = z.object({
  content: z.string().trim().min(1).max(LIMITS.MESSAGE_MAX),
});

export const ListMessagesQuery = z.object({
  before: IdSchema.optional(),
  limit: z.coerce.number().int().min(1).max(100).default(LIMITS.MESSAGE_PAGE_SIZE),
});

// ---------- Sounds ----------
export const SoundMetaInput = z.object({
  name: z.string().trim().min(1).max(LIMITS.SOUND_NAME_MAX),
  emoji: z.string().max(16).optional().default("🔊"),
  category: z.string().trim().max(LIMITS.SOUND_CATEGORY_MAX).optional().default("Genel"),
  volume: z.coerce.number().min(0).max(1).optional().default(1),
  /** null → kişisel ses; aksi halde sunucu sesi. */
  guildId: IdSchema.nullable().optional(),
});
export type SoundMetaInput = z.infer<typeof SoundMetaInput>;

export const UpdateSoundInput = SoundMetaInput.omit({ guildId: true }).partial();

// ---------- DTO'lar (API yanıtları) ----------
export interface UserDTO {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  bio: string;
  status: PresenceStatus;
}

export interface GuildDTO {
  id: string;
  name: string;
  iconUrl: string | null;
  ownerId: string;
  /** AFK sesli kanalı: buraya geçen kişide alarm durmadan çalar. */
  afkChannelId: string | null;
  /** AFK alarmı olarak çalınacak sunucu sesi; null = yerleşik alarm. */
  afkSoundId: string | null;
  /** İstek sahibinin sunucu düzeyindeki etkin izinleri. */
  myPermissions: number;
}

export interface ChannelDTO {
  /** Kanal izin overwrite'ları (yalnızca MANAGE_ROLES yetkisi olanlara dolu gelir). */
  overwrites?: ChannelOverwriteDTO[];
  id: string;
  guildId: string;
  type: ChannelType;
  name: string;
  parentId: string | null;
  position: number;
  isPrivate: boolean;
  /** İstek sahibinin bu kanaldaki etkin izinleri. */
  myPermissions: number;
}

export interface RoleDTO {
  id: string;
  guildId: string;
  name: string;
  color: string | null;
  position: number;
  permissions: number;
}

export interface MemberDTO {
  user: UserDTO;
  roleIds: string[];
  nickname: string | null;
}

export interface MessageAuthorDTO {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
}

export interface AttachmentDTO {
  id: string;
  filename: string;
  mime: string;
  size: number;
  /** Resim mi? (istemci satır içi gösterir) */
  isImage: boolean;
  url: string;
}

export interface ReactionDTO {
  emoji: string;
  userIds: string[];
}

export interface MessageDTO {
  id: string;
  channelId: string;
  author: MessageAuthorDTO;
  content: string;
  replyToId: string | null;
  createdAt: number;
  editedAt: number | null;
  attachments: AttachmentDTO[];
  reactions: ReactionDTO[];
  nonce?: string;
}

export type FriendState = "friend" | "incoming" | "outgoing" | "blocked";

export interface FriendDTO {
  user: UserDTO;
  state: FriendState;
}

export interface DmChannelDTO {
  id: string;
  type: "dm" | "group";
  name: string | null;
  ownerId: string | null;
  members: UserDTO[];
  lastMessageAt: number | null;
}

export interface BanDTO {
  user: UserDTO;
  reason: string | null;
  createdAt: number;
}

export interface ChannelOverwriteDTO {
  targetType: "role" | "member";
  targetId: string;
  allow: number;
  deny: number;
}

export interface SoundDTO {
  id: string;
  guildId: string | null;
  ownerId: string;
  name: string;
  emoji: string;
  category: string;
  volume: number;
  mime: string;
  size: number;
  /** Değişmez içerik hash'i; istemci önbellek anahtarı olarak kullanır. */
  sha256: string;
  /** Kısa ömürlü imzalı indirme URL'si. */
  url: string;
  createdAt: number;
}

export interface AuthResponse {
  token: string;
  user: UserDTO;
}

export interface IceServersResponse {
  iceServers: { urls: string | string[]; username?: string; credential?: string }[];
  /** true ise TURN (relay) sunucuları dahil edildi. */
  turn: boolean;
}

export interface ApiError {
  error: { code: string; message: string; details?: unknown };
}
