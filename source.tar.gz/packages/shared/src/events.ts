import { z } from "zod";
import type { ChannelDTO, DmChannelDTO, FriendDTO, MessageDTO, PresenceStatus, ReactionDTO, SoundDTO } from "./schemas";
import { IdSchema } from "./schemas";

/**
 * WebSocket olay sözleşmesi.
 *
 * Bağlantı: istemci önce REST ile kısa ömürlü bir bilet alır
 * (POST /api/guilds/:id/gateway-ticket) ve
 * wss://<host>/api/guilds/:id/gateway?ticket=... adresine bağlanır.
 * Her sunucu (guild) için bir Durable Object ("GuildHub") vardır.
 *
 * Yönlendirme kuralı: kalıcı veri değiştiren işlemler REST ile yapılır
 * (yetki + D1 yazma Worker'da), DO yalnızca yayın yapar. Geçici/gerçek zamanlı
 * işlemler (yazıyor, ses durumu, WebRTC sinyali, soundboard tetikleme) WS ile
 * gönderilir ve DO tarafında yetkilendirilir.
 */

// ---------------- İstemci → Sunucu ----------------
export const ClientEvent = z.discriminatedUnion("t", [
  z.object({ t: z.literal("ping"), clientTime: z.number() }),
  z.object({ t: z.literal("typing"), channelId: IdSchema }),
  z.object({ t: z.literal("presence.set"), status: z.enum(["online", "busy", "idle", "invisible"]) }),
  z.object({ t: z.literal("voice.join"), channelId: IdSchema }),
  z.object({ t: z.literal("voice.leave") }),
  z.object({
    t: z.literal("voice.state"),
    selfMute: z.boolean(),
    selfDeaf: z.boolean(),
  }),
  z.object({ t: z.literal("voice.speaking"), speaking: z.boolean() }),
  z.object({
    t: z.literal("rtc.signal"),
    to: IdSchema,
    /**
     * Hangi bağlantıya ait: "voice" ses mesh'i; ekran paylaşımında
     * "screen-up" yayıncının izleyiciye, "screen-down" izleyicinin yayıncıya
     * gönderdiği sinyaldir (bir kullanıcı aynı anda hem yayıncı hem izleyici olabilir).
     */
    stream: z.enum(["voice", "screen-up", "screen-down"]).default("voice"),
    /** SDP, ICE adayı veya izleme isteği; DO içeriğe dokunmadan iletir (boyut sınırlı). */
    data: z.union([
      z.object({ kind: z.literal("description"), sdp: z.string().max(40_000), type: z.enum(["offer", "answer", "pranswer", "rollback"]) }),
      z.object({ kind: z.literal("candidate"), candidate: z.string().max(2_000), sdpMid: z.string().max(64).nullable(), sdpMLineIndex: z.number().int().nullable() }),
      z.object({ kind: z.literal("watch") }),
      z.object({ kind: z.literal("unwatch") }),
    ]),
  }),
  z.object({ t: z.literal("sound.play"), soundId: IdSchema }),
  z.object({ t: z.literal("screen.start"), preset: z.string().max(16), audio: z.boolean() }),
  z.object({ t: z.literal("screen.stop") }),
  /** Yetkili: sunucu tarafı susturma / sağırlaştırma (MUTE_MEMBERS / DEAFEN_MEMBERS). */
  z.object({ t: z.literal("voice.moderate"), userId: IdSchema, mute: z.boolean().optional(), deafen: z.boolean().optional() }),
  /** Yetkili: başka sesli kanala taşı veya (channelId null) bağlantısını kes (MOVE_MEMBERS). */
  z.object({ t: z.literal("voice.move"), userId: IdSchema, channelId: IdSchema.nullable() }),
  /** Kullanıcı gateway'i: DM'de yazıyor. */
  z.object({ t: z.literal("dm.typing"), channelId: IdSchema }),
]);
export type ClientEvent = z.infer<typeof ClientEvent>;

// ---------------- Sunucu → İstemci ----------------
export interface VoiceParticipant {
  userId: string;
  channelId: string;
  selfMute: boolean;
  selfDeaf: boolean;
  serverMute: boolean;
  serverDeaf: boolean;
  speaking: boolean;
  /** Ekran paylaşıyor mu? */
  streaming: boolean;
  /** Paylaşım bilgisi (kalite, sistem sesi) */
  stream: { preset: string; audio: boolean } | null;
}

export type ServerEvent =
  | { t: "ready"; userId: string; serverTime: number; online: { userId: string; status: PresenceStatus }[]; voice: VoiceParticipant[] }
  | { t: "pong"; clientTime: number; serverTime: number }
  | { t: "error"; code: string; message: string; ref?: string }
  | { t: "presence"; userId: string; status: PresenceStatus | "offline" }
  | { t: "typing"; channelId: string; userId: string }
  | { t: "message.create"; message: MessageDTO }
  | { t: "message.update"; message: MessageDTO }
  | { t: "message.delete"; channelId: string; messageId: string }
  | { t: "channel.create"; channel: Omit<ChannelDTO, "myPermissions"> }
  | { t: "channel.update"; channel: Omit<ChannelDTO, "myPermissions"> }
  | { t: "channel.delete"; channelId: string }
  | { t: "member.join"; userId: string }
  | { t: "voice.update"; participant: VoiceParticipant }
  | { t: "voice.leave"; userId: string; channelId: string }
  | { t: "rtc.signal"; from: string; stream: ClientRtcSignal["stream"]; data: ClientRtcSignal["data"] }
  /** Bir yetkili seni başka kanala taşıdı (channelId null: bağlantın kesildi). */
  | { t: "voice.moved"; channelId: string | null; byUserId: string }
  | { t: "message.reactions"; channelId: string; messageId: string; reactions: ReactionDTO[] }
  | { t: "guild.update" }
  | { t: "guild.remove"; guildId: string }
  // ---- kullanıcı gateway'i (arkadaşlar, DM)
  | { t: "friend.update"; friend: FriendDTO }
  | { t: "friend.remove"; userId: string }
  | { t: "dm.channel"; channel: DmChannelDTO }
  | {
      t: "sound.play";
      soundId: string;
      sha256: string;
      url: string;
      volume: number;
      byUserId: string;
      channelId: string;
      /** Sunucu saatine göre oynatma anı (ms). İstemci saat farkını düşer. */
      playAt: number;
    }
  | { t: "sound.created"; sound: SoundDTO }
  | { t: "sound.deleted"; soundId: string };

export type ClientRtcSignal = Extract<ClientEvent, { t: "rtc.signal" }>;

/** WebSocket kapanma kodları (4000-4999 uygulamaya özel). */
export const CloseCode = {
  UNAUTHORIZED: 4001,
  FORBIDDEN: 4003,
  REPLACED: 4004,
  RATE_LIMITED: 4029,
} as const;
