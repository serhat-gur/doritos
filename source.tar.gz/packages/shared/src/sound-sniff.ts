import type { ImageMime, SoundMime } from "./limits";

/**
 * Dosya içeriğinin ilk baytlarına bakarak gerçek ses biçimini tespit eder.
 * İstemcinin bildirdiği Content-Type'a güvenilmez.
 */
export function sniffSoundMime(bytes: Uint8Array): SoundMime | null {
  if (bytes.length < 12) return null;
  const ascii = (start: number, len: number) =>
    String.fromCharCode(...bytes.subarray(start, start + len));

  // WAV: "RIFF" .... "WAVE"
  if (ascii(0, 4) === "RIFF" && ascii(8, 4) === "WAVE") return "audio/wav";
  // OGG: "OggS"
  if (ascii(0, 4) === "OggS") return "audio/ogg";
  // MP3: ID3 etiketi veya MPEG frame sync (11 bit 1)
  if (ascii(0, 3) === "ID3") return "audio/mpeg";
  if (bytes[0] === 0xff && ((bytes[1] ?? 0) & 0xe0) === 0xe0) {
    // Layer bitleri 00 (reserved) olmamalı
    const layer = ((bytes[1] ?? 0) >> 1) & 0x03;
    if (layer !== 0) return "audio/mpeg";
  }
  return null;
}

/** Resim biçimini içerikten tespit eder. SVG bilerek desteklenmez (betik içerebilir). */
export function sniffImageMime(bytes: Uint8Array): ImageMime | null {
  if (bytes.length < 12) return null;
  const b = (i: number) => bytes[i] ?? 0;
  if (b(0) === 0x89 && b(1) === 0x50 && b(2) === 0x4e && b(3) === 0x47) return "image/png";
  if (b(0) === 0xff && b(1) === 0xd8 && b(2) === 0xff) return "image/jpeg";
  if (b(0) === 0x47 && b(1) === 0x49 && b(2) === 0x46 && b(3) === 0x38) return "image/gif";
  if (String.fromCharCode(b(0), b(1), b(2), b(3)) === "RIFF" && String.fromCharCode(b(8), b(9), b(10), b(11)) === "WEBP") return "image/webp";
  return null;
}
