/**
 * Teknik limitler. Bunlar "ürün limiti" değil; altyapı maliyetini ve kötüye
 * kullanımı kontrol etmek için konmuş, yapılandırılabilir koruma değerleridir.
 */
export const LIMITS = {
  USERNAME_MIN: 3,
  USERNAME_MAX: 32,
  DISPLAY_NAME_MAX: 48,
  PASSWORD_MIN: 8,
  PASSWORD_MAX: 128,
  GUILD_NAME_MAX: 64,
  CHANNEL_NAME_MAX: 64,
  MESSAGE_MAX: 4000,
  MESSAGE_PAGE_SIZE: 50,

  /** Tek bir soundboard dosyasının en büyük boyutu (bayt). */
  SOUND_MAX_BYTES: 2 * 1024 * 1024,
  /** Kullanıcı başına toplam soundboard depolaması (bayt). */
  SOUND_USER_QUOTA_BYTES: 100 * 1024 * 1024,
  /** Sunucu başına toplam soundboard depolaması (bayt). */
  SOUND_GUILD_QUOTA_BYTES: 500 * 1024 * 1024,
  SOUND_NAME_MAX: 32,
  SOUND_CATEGORY_MAX: 32,

  /** Aynı kullanıcı iki ses arasında en az bu kadar bekler (ms). */
  SOUND_USER_COOLDOWN_MS: 1500,
  /** Bir sesli odada kayan pencerede (SOUND_ROOM_WINDOW_MS) en fazla bu kadar ses çalınabilir. */
  SOUND_ROOM_MAX_PER_WINDOW: 6,
  SOUND_ROOM_WINDOW_MS: 5000,
  /** Sesin tüm istemcilerde çalınacağı zaman için eklenen gecikme payı (ms). */
  SOUND_SCHEDULE_LEAD_MS: 250,

  /** Mesaj eki: dosya başına en büyük boyut ve mesaj başına en fazla dosya. */
  ATTACHMENT_MAX_BYTES: 10 * 1024 * 1024,
  ATTACHMENTS_PER_MESSAGE: 5,
  /** Kullanıcı başına toplam ek depolaması. */
  ATTACHMENT_USER_QUOTA_BYTES: 300 * 1024 * 1024,
  /** Profil / sunucu resmi (istemci 256 px'e küçültüp WebP olarak gönderir). */
  AVATAR_MAX_BYTES: 1024 * 1024,
  /**
   * Tüm uygulamanın toplam dosya depolama tavanı. Durable Object SQLite
   * depolaması ücretsiz planda toplam 5 GB'tır; tavan bunun altında tutulur ki
   * hiçbir zaman ücretli kullanıma geçilmesin (aşılırsa yalnızca yükleme reddedilir).
   */
  STORAGE_GLOBAL_CAP_BYTES: 3.5 * 1024 * 1024 * 1024,
  /** Bir mesajdaki farklı tepki sayısı. */
  REACTIONS_PER_MESSAGE: 20,
  GROUP_DM_MAX_MEMBERS: 10,
  SEARCH_RESULTS_MAX: 50,

  /** Oturum token'ı ömrü. */
  SESSION_TTL_MS: 30 * 24 * 60 * 60 * 1000,
  /** WebSocket bilet ömrü. */
  GATEWAY_TICKET_TTL_MS: 60 * 1000,
  /** İmzalı dosya URL ömrü. */
  FILE_URL_TTL_MS: 60 * 60 * 1000,
} as const;

export const ALLOWED_SOUND_MIME = ["audio/mpeg", "audio/wav", "audio/ogg"] as const;
export type SoundMime = (typeof ALLOWED_SOUND_MIME)[number];

export const ALLOWED_IMAGE_MIME = ["image/png", "image/jpeg", "image/gif", "image/webp"] as const;
export type ImageMime = (typeof ALLOWED_IMAGE_MIME)[number];

/** Ekran paylaşımı kalite seçenekleri ve bitrate üst sınırları (bps). */
export const SCREEN_PRESETS = {
  "720p15": { width: 1280, height: 720, fps: 15, maxBitrate: 1_500_000 },
  "720p30": { width: 1280, height: 720, fps: 30, maxBitrate: 2_500_000 },
  "720p60": { width: 1280, height: 720, fps: 60, maxBitrate: 4_000_000 },
  "1080p15": { width: 1920, height: 1080, fps: 15, maxBitrate: 2_500_000 },
  "1080p30": { width: 1920, height: 1080, fps: 30, maxBitrate: 4_500_000 },
  "1080p60": { width: 1920, height: 1080, fps: 60, maxBitrate: 7_000_000 },
} as const;
export type ScreenPreset = keyof typeof SCREEN_PRESETS;
