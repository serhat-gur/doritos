/**
 * Rol tabanlı yetki modeli (RBAC).
 *
 * İzinler 32-bit güvenli bir bit alanında tutulur (JS bitwise işlemleri 32-bit
 * işaretli tamsayı üzerinde çalışır; 30 bite kadar güvenle kullanılabilir).
 * D1'de INTEGER kolon olarak saklanır.
 */
export const Permission = {
  ADMINISTRATOR: 1 << 0,
  MANAGE_SERVER: 1 << 1,
  MANAGE_CHANNELS: 1 << 2,
  MANAGE_ROLES: 1 << 3,
  VIEW_CHANNEL: 1 << 4,
  SEND_MESSAGES: 1 << 5,
  MANAGE_MESSAGES: 1 << 6,
  CONNECT_VOICE: 1 << 7,
  SPEAK: 1 << 8,
  MUTE_MEMBERS: 1 << 9,
  DEAFEN_MEMBERS: 1 << 10,
  MOVE_MEMBERS: 1 << 11,
  KICK_MEMBERS: 1 << 12,
  BAN_MEMBERS: 1 << 13,
  MANAGE_SOUNDBOARD: 1 << 14,
  UPLOAD_SOUNDS: 1 << 15,
  PLAY_SOUNDS: 1 << 16,
  SCREEN_SHARE: 1 << 17,
  CREATE_INVITE: 1 << 18,
} as const;

export type PermissionName = keyof typeof Permission;
export const PERMISSION_NAMES = Object.keys(Permission) as PermissionName[];

export const ALL_PERMISSIONS = PERMISSION_NAMES.reduce((acc, k) => acc | Permission[k], 0);

/** @everyone rolünün varsayılan izinleri (sunucu oluşturulurken atanır). */
export const DEFAULT_EVERYONE_PERMISSIONS =
  Permission.VIEW_CHANNEL |
  Permission.SEND_MESSAGES |
  Permission.CONNECT_VOICE |
  Permission.SPEAK |
  Permission.PLAY_SOUNDS |
  Permission.UPLOAD_SOUNDS |
  Permission.SCREEN_SHARE |
  Permission.CREATE_INVITE;

export const ROLE_PRESETS = {
  Admin: Permission.ADMINISTRATOR,
  Moderator:
    DEFAULT_EVERYONE_PERMISSIONS |
    Permission.MANAGE_MESSAGES |
    Permission.MUTE_MEMBERS |
    Permission.DEAFEN_MEMBERS |
    Permission.MOVE_MEMBERS |
    Permission.KICK_MEMBERS |
    Permission.MANAGE_SOUNDBOARD,
  Member: DEFAULT_EVERYONE_PERMISSIONS,
} as const;

/** Sadece kanal düzeyinde anlamlı olan izinler (overwrite'larda izin verilir). */
export const CHANNEL_SCOPED_PERMISSIONS =
  Permission.VIEW_CHANNEL |
  Permission.SEND_MESSAGES |
  Permission.MANAGE_MESSAGES |
  Permission.CONNECT_VOICE |
  Permission.SPEAK |
  Permission.MUTE_MEMBERS |
  Permission.DEAFEN_MEMBERS |
  Permission.MOVE_MEMBERS |
  Permission.PLAY_SOUNDS |
  Permission.SCREEN_SHARE |
  Permission.MANAGE_CHANNELS;

export interface RoleLike {
  id: string;
  permissions: number;
  position: number;
}

export type OverwriteTarget = "role" | "member";

export interface ChannelOverwrite {
  targetType: OverwriteTarget;
  targetId: string;
  allow: number;
  deny: number;
}

export interface PermissionContext {
  /** Sunucu sahibi mi? Sahip her zaman tüm izinlere sahiptir. */
  isOwner: boolean;
  userId: string;
  /** Sunucunun @everyone rol id'si (sunucu id'si ile aynıdır). */
  everyoneRoleId: string;
  /** Sunucudaki tüm roller (en az @everyone). */
  roles: RoleLike[];
  /** Üyeye atanmış rol id'leri (@everyone hariç). */
  memberRoleIds: string[];
}

export function hasFlag(perms: number, flag: number): boolean {
  return (perms & flag) === flag;
}

/** Sunucu düzeyindeki (kanaldan bağımsız) izinleri hesaplar. */
export function computeBasePermissions(ctx: PermissionContext): number {
  if (ctx.isOwner) return ALL_PERMISSIONS;
  const everyone = ctx.roles.find((r) => r.id === ctx.everyoneRoleId);
  let perms = everyone?.permissions ?? 0;
  const assigned = new Set(ctx.memberRoleIds);
  for (const role of ctx.roles) {
    if (assigned.has(role.id)) perms |= role.permissions;
  }
  if (hasFlag(perms, Permission.ADMINISTRATOR)) return ALL_PERMISSIONS;
  return perms;
}

/**
 * Kanal izinlerini Discord'a benzer sırayla hesaplar:
 * 1) taban izinler, 2) @everyone overwrite, 3) rol overwrite'ları (birleşik),
 * 4) üyeye özel overwrite. VIEW_CHANNEL yoksa kanal için hiçbir izin yoktur.
 */
export function computeChannelPermissions(
  ctx: PermissionContext,
  overwrites: ChannelOverwrite[],
): number {
  const base = computeBasePermissions(ctx);
  if (hasFlag(base, Permission.ADMINISTRATOR) || ctx.isOwner) return ALL_PERMISSIONS;

  let perms = base;
  const everyoneOw = overwrites.find(
    (o) => o.targetType === "role" && o.targetId === ctx.everyoneRoleId,
  );
  if (everyoneOw) {
    perms &= ~everyoneOw.deny;
    perms |= everyoneOw.allow;
  }

  const assigned = new Set(ctx.memberRoleIds);
  let roleAllow = 0;
  let roleDeny = 0;
  for (const o of overwrites) {
    if (o.targetType === "role" && o.targetId !== ctx.everyoneRoleId && assigned.has(o.targetId)) {
      roleAllow |= o.allow;
      roleDeny |= o.deny;
    }
  }
  perms &= ~roleDeny;
  perms |= roleAllow;

  const memberOw = overwrites.find((o) => o.targetType === "member" && o.targetId === ctx.userId);
  if (memberOw) {
    perms &= ~memberOw.deny;
    perms |= memberOw.allow;
  }

  if (!hasFlag(perms, Permission.VIEW_CHANNEL)) return 0;
  return perms;
}

/** Bir üyenin en yüksek rol pozisyonu (rol hiyerarşisi kontrolleri için). */
export function highestRolePosition(ctx: PermissionContext): number {
  if (ctx.isOwner) return Number.MAX_SAFE_INTEGER;
  const assigned = new Set(ctx.memberRoleIds);
  let max = 0;
  for (const r of ctx.roles) if (assigned.has(r.id) && r.position > max) max = r.position;
  return max;
}

export function permissionNames(perms: number): PermissionName[] {
  return PERMISSION_NAMES.filter((n) => hasFlag(perms, Permission[n]));
}
