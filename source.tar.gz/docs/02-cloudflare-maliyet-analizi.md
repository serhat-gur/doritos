# 02 — Cloudflare Ücretsiz Plan Uygunluk ve Maliyet Analizi

Rakamlar 6 Kasım 2026'da Cloudflare'in resmi dokümantasyonundan doğrulanmıştır. Limitler değişebilir; deploy öncesi tekrar kontrol edin.

## Sıfır ücret ilkesi

Hesaba **ödeme yöntemi eklenmez**. Yalnızca, ücretsiz planda limit aşılınca ücret değil hata üreten servisler kullanılır:

| Servis | Kullanılıyor mu | Aşımda |
|---|---|---|
| Workers | Evet | İstek hata verir |
| Durable Objects (SQLite) | Evet — gateway'ler, rate limit, **dosya deposu** | İşlem hata verir |
| D1 | Evet | Sorgu hata verir |
| R2 | **Hayır** (ödeme yöntemi ister, aşımda ücret keser) | — |
| Realtime SFU | **Hayır** (1.000 GB sonrası ücretli) | — |
| Realtime TURN | İsteğe bağlı, varsayılan kapalı | 1.000 GB sonrası ücretli |

Ses ve ekran paylaşımı P2P aktığı için Cloudflare üzerinden medya trafiği geçmez.

## Ücretsiz plan limitleri

| Servis | Ücretsiz limit | Aşınca ne olur | Ücretli |
|---|---|---|---|
| **Workers** | 100.000 istek/gün, istek başına **10 ms CPU**, 128 MB bellek | İstekler hata verir (Error 1027), ücret çıkmaz | Paid plan en az $5/ay: 10 M istek + 30 M CPU-ms dahil |
| **Durable Objects** | Yalnızca **SQLite backend**; 100.000 istek/gün, 13.000 GB-s/gün, 5 M satır okuma, 100.000 satır yazma, 5 GB toplam | O tür işlemler gün sonuna kadar başarısız olur | Paid plan |
| **D1** | 5 M satır okuma/gün, 100.000 satır yazma/gün, 5 GB toplam, **veritabanı başına 500 MB**, çağrı başına 50 sorgu | Sorgular hata verir | Paid: 25 milyar okuma + 50 M yazma/ay dahil, DB başına 10 GB |
| **R2** | 10 GB-ay depolama, 1 M Class A, 10 M Class B işlem/ay, **çıkış (egress) ücretsiz** | Aşım ücretlendirilir | $0.015/GB-ay, Class A $4.50/M, Class B $0.36/M |
| **Realtime SFU + TURN** | Ayda **ortak 1.000 GB** çıkış | **$0.05/GB** ücretlendirilir | — |

WebSocket notları (DO): bağlantı kurmak 1 istek sayılır; gelen mesajlar **20:1** oranında sayılır (100 mesaj = 5 istek); giden mesajlar ücretsizdir. Hibernation API ile boşta bekleyen nesne süre ücreti işletmez.

## 10 kişilik grup için tahmini günlük kullanım

Varsayımlar: 10 aktif kullanıcı, kişi başı 2 sunucu, günde 2.000 mesaj, günde 3 saat ses, 300 soundboard tetiklemesi.

| Kalem | Tahmin | Ücretsiz limite oranı |
|---|---|---|
| Worker istekleri (REST + dosya + bilet) | ~8.000 | %8 |
| DO istekleri: mesaj yayını + rate limit (2.000 × 2) | ~4.000 | |
| DO istekleri: WS ping (25 sn'de bir, 20:1) | 10 × 2 × 3.456 / 20 ≈ 3.500 | |
| DO istekleri: ses, sinyal, yazıyor (20:1) | ~1.500 | toplam ~%9 |
| D1 satır yazma (mesaj + indeks + oturum) | ~6.000 | %6 |
| D1 satır okuma (geçmiş, yetki anlık görüntüleri) | ~300.000 | %6 |
| DO depolama (ses, ek, profil resmi) | ilk yıl ~0,5–1,5 GB (tavan 3,5 GB) | toplam 5 GB'ın altında |
| DO istekleri: dosya indirme (önbellek sayesinde düşük) | ~1.000/gün | |
| TURN (yalnızca P2P başarısız olursa) | Opus ≈ 30–60 MB/saat/akış | 1.000 GB'ın çok altında |

**Sonuç:** Metin, ses, soundboard, dosyalar ve ekran paylaşımı ücretsiz planda kalır. Ekran paylaşımı P2P olduğu için Cloudflare'de hiç trafik oluşturmaz; bedeli yayıncının yükleme bant genişliğidir.

## Ücretsiz olmayan veya dikkat gerektirenler

- **Realtime SFU/TURN 1.000 GB'ı aşarsa ücretlidir.** SFU kullanılmıyor; TURN varsayılan kapalı.
- **Workers Paid ($5/ay)** gerekirse: CPU sınırı (aşağıda) veya D1'in 500 MB/DB sınırı (çok yoğun mesaj geçmişinde yıllar içinde).
- R2 hiç kullanılmıyor.

## CPU riski

Ücretsiz planda istek başına CPU sınırı 10 ms'dir. Ölçüm: PBKDF2-SHA256 100.000 tur ≈ 18 ms (sınırı aşar, giriş Error 1102 verir), 30.000 tur ≈ 5 ms. **Varsayılan 30.000'dir.** Giriş denemeleri IP başına dakikada 10 ile sınırlı ve oturum token'ları hash'li tutulduğu için arkadaş grubu ölçeğinde kabul edilebilir bir ödünleşimdir. Tur sayısı hash içinde saklandığından, Workers Paid'e geçilirse `PBKDF2_ITERATIONS` artırılabilir; eski hesaplar bozulmaz.

## Kota, bütçe ve kullanım izleme tasarımı

**Uygulandı:**
- Teknik limitler: ses 2 MB, ek 10 MB (mesaj başına 5), profil resmi 1 MB; kullanıcı başı 100 MB ses + 300 MB ek; **genel depolama tavanı 3,5 GB** (`packages/shared/src/limits.ts`).
- Rate limit (RateLimiter DO): auth IP başına 10/dk, mesaj 20/10 sn, yükleme 30/saat, yazma 60/dk.
- Soundboard: kullanıcı cooldown 1,5 sn, oda başına 5 sn'de 6 ses.
- Yapılandırılmış JSON loglar (`observability.enabled`).

**Tasarlandı, henüz uygulanmadı (Aşama 4):**
- Günlük bir Cron Worker, Cloudflare GraphQL Analytics API'den Workers/DO/D1/R2/Realtime kullanımını çeker, `usage_daily` tablosuna yazar.
- Eşikler (%70 uyarı, %90 "koruma modu"): koruma modunda yeni ses yükleme ve ekran paylaşımı geçici kapatılır, mesajlaşma sürer.
- Realtime için ayrıca Cloudflare hesabında faturalama bildirimi kurulmalı (dashboard).

## Kaynaklar
- [Workers limitleri](https://developers.cloudflare.com/workers/platform/limits/)
- [Workers fiyatlandırma](https://developers.cloudflare.com/workers/platform/pricing/)
- [Durable Objects fiyatlandırma](https://developers.cloudflare.com/durable-objects/platform/pricing/)
- [Durable Objects limitleri](https://developers.cloudflare.com/durable-objects/platform/limits/)
- [D1 fiyatlandırma](https://developers.cloudflare.com/d1/platform/pricing/) · [D1 limitleri](https://developers.cloudflare.com/d1/platform/limits/)
- [R2 fiyatlandırma](https://developers.cloudflare.com/r2/pricing/)
- [Realtime SFU/TURN fiyatlandırma](https://developers.cloudflare.com/realtime/sfu/platform/pricing/)
