# 09 — Windows / Electron Güvenlik Yapılandırması

Kaynak: `apps/desktop/src/main/index.ts`, `src/preload/index.ts`, `src/renderer/index.html`.

| Önlem | Durum |
|---|---|
| `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true`, `webSecurity: true` | ✅ (çalışan uygulamada doğrulandı: `window.require`/`window.process` yok) |
| Preload yalnızca dar, tipli bir API açar (`window.yanki`); `ipcRenderer` dışarı verilmez | ✅ |
| Her IPC çağrısında gönderen çerçevenin URL'si kontrol edilir (yalnızca uygulamanın kendi sayfası) | ✅ |
| IPC girdileri doğrulanır (tür, uzunluk, URL biçimi) | ✅ |
| Oturum token'ı **Windows DPAPI** (`safeStorage`) ile şifrelenip diske yazılır; şifreleme yoksa diske yazılmaz | ✅ |
| Uygulama içinde başka sayfaya gezinme engellenir; yeni pencere açılmaz, yalnızca `https://` bağlantılar sistem tarayıcısında açılır | ✅ (doğrulandı) |
| İzin isteği işleyicisi: yalnızca kendi sayfamız ve yalnızca `media`, `notifications`, `speaker-selection` | ✅ |
| CSP: satır içi/uzak script yok; bağlantılar https/wss (+ geliştirmede localhost) | ✅ |
| Mesaj içeriği React ile metin olarak işlenir (HTML yorumlanmaz) — XSS testi uçtan uca testte | ✅ |
| Tek örnek kilidi, `AppUserModelId` (Windows bildirimleri) | ✅ |
| Kod imzalama (SmartScreen uyarısı olmasın) | ❌ sertifika gerekir |
| Otomatik güncelleme (electron-updater, GitHub Releases) | ✅ altyapı; imzasız |

## Ekran paylaşımı ve sistem sesi

Electron'da `session.setDisplayMediaRequestHandler` ile `desktopCapturer` kaynağı seçilir. Ses için `audio: "loopback"` veya `"loopbackWithMute"` verilebilir; Electron dokümanına göre **sistem sesi yakalama şu anda yalnızca Windows'ta desteklenir** — hedef platformumuz için uygun.

**Uygulandı.** Kaynak, uygulama içi seçicide seçilir; ana süreç yalnızca o kaynağı verir (`display-capture` izni yalnızca kendi sayfamıza). Sistem sesi seçeneği varsayılan kapalıdır ve seçicide uyarı vardır: loopback tüm sistem sesini yakalar (sohbetteki diğer kişilerin sesi ve soundboard dahil). Uygulama bazlı ses Electron'un hazır API'sinde yok; yerel modül (Windows Application Loopback API) gerektirir.

## Global makrolar (sustur / sağırlaştır / bas-konuş)

Electron `globalShortcut` mouse tuşlarını ve tuş bırakmayı vermez. Bu yüzden ana süreçte `uiohook-napi` (N-API, hazır Windows ikilisi, derleyici gerekmez) kullanılır.

- **Gizlilik:** Kanca tüm tuşları görür ama renderer'a **yalnızca kullanıcının atadığı tuşlar** iletilir. "Ata" ekranında yalnızca bir sonraki tek tuş/mouse olayı yakalanır (10 sn zaman aşımı). Sol/sağ tık atanamaz.
- Desteklenen: klavye tuşları, Mouse 3 (orta), Mouse 4/5 (yan tuşlar).
- Bas-konuş **isteğe bağlıdır**; varsayılan ses algılamadır. Bas-konuş kapalıyken PTT tuşu kancaya hiç kaydedilmez.
- Makroyla susturunca isteğe bağlı kısa onay sesi çalar (oyundayken ekrana bakmadan anlamak için).
- Paketlemede `asarUnpack` ile .node ikilisi asar dışına çıkarılır; `npmRebuild: false` (yeniden derleme gerekmez).
- Doğrulama: gerçek Electron'da X11 XTest ile üretilen donanım olaylarıyla — Mouse 4 yakalandı ve mikrofonu kapatıp açtı, F9 sağırlaştırdı. Windows'ta aynı kütüphanenin Windows kancası kullanılır; orada elle doğrulanmalı.
