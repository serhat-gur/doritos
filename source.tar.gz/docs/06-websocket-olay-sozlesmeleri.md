# 06 — WebSocket Olay Sözleşmeleri

Kaynak: [`packages/shared/src/events.ts`](../packages/shared/src/events.ts). İstemci olayları DO'da Zod ile doğrulanır; bilinmeyen/hatalı olay `error` döner.

## Bağlantı

1. `POST /api/guilds/:gid/gateway-ticket` (Bearer token) → `{ ticket }` (60 sn).
2. `GET wss://<host>/api/guilds/:gid/gateway?ticket=...` (Upgrade).
3. Sunucu ilk olarak `ready` gönderir.

Kapanma kodları: `4001` yetkisiz, `4003` yasak/atıldı (istemci yeniden bağlanmaz), `4029` rate limit. Diğer kopmalarda istemci üstel geri çekilme (0,5 sn → 30 sn, rastgele sapmalı) ile yeniden bağlanır; `ready` sonrası mesajları REST'ten tazeler ve sesliyse kanala yeniden katılır.

## İstemci → Sunucu

| `t` | Alanlar | Yetki / Not |
|---|---|---|
| `ping` | `clientTime` | `pong` döner; 25 sn'de bir + saat senkronu |
| `typing` | `channelId` | SEND_MESSAGES; yalnızca kanalı görenlere |
| `presence.set` | `status` | `invisible` diğerlerine `offline` görünür |
| `voice.join` | `channelId` | Ses kanalı + CONNECT_VOICE; aynı kullanıcının diğer ses oturumu kapanır |
| `voice.leave` | — | |
| `voice.state` | `selfMute`, `selfDeaf` | |
| `voice.speaking` | `speaking` | İstemci VAD'ı tetikler |
| `rtc.signal` | `to`, `stream` (`voice` / `screen-up` / `screen-down`), `data` (SDP, ICE adayı, `watch`/`unwatch`) | Yalnızca aynı ses kanalındaki iki kullanıcı arasında iletilir |
| `sound.play` | `soundId` | Seste olmalı + PLAY_SOUNDS + cooldown + oda limiti |
| `screen.start` / `screen.stop` | `preset`, `audio` | Seste olmalı + SCREEN_SHARE |
| `voice.moderate` | `userId`, `mute?`, `deafen?` | MUTE_MEMBERS / DEAFEN_MEMBERS |
| `voice.move` | `userId`, `channelId` (null = çıkar) | MOVE_MEMBERS |
| `dm.typing` | `channelId` | Kişisel gateway; DM üyesi olmalı |

## Sunucu → İstemci

| `t` | İçerik |
|---|---|
| `ready` | `userId`, `serverTime`, `online[]`, `voice[]` |
| `pong` | `clientTime`, `serverTime` |
| `error` | `code`, `message`, `ref?` (ör. `voice.join`, `sound.play`) |
| `presence` | `userId`, `status` / `offline` |
| `typing` | `channelId`, `userId` |
| `message.create` / `.update` | `message` (istemci `nonce`'u ile iyimser mesajı eşler) |
| `message.delete` | `channelId`, `messageId` |
| `channel.create` / `.update` / `.delete` | Kanal |
| `member.join` | `userId` |
| `voice.update` | `participant` (kanal, self/server mute-deaf, speaking, streaming + yayın kalitesi) |
| `voice.leave` | `userId`, `channelId` |
| `rtc.signal` | `from`, `stream`, `data` |
| `sound.play` | `soundId`, `sha256`, imzalı `url`, `volume`, `byUserId`, `channelId`, `playAt` (sunucu saati) |
| `sound.created` / `sound.deleted` | Sunucu paneli değişti |
| `voice.moved` | Bir yetkili seni taşıdı / çıkardı |
| `message.reactions` | Bir mesajın güncel tepkileri |
| `guild.update` / `guild.remove` | Rol, izin, ad, ikon değişti / sunucudan atıldın |
| `friend.update` / `friend.remove` | (kişisel gateway) arkadaşlık durumu |
| `dm.channel` | (kişisel gateway) yeni veya değişen DM |

**Kişisel gateway:** `POST /api/gateway-ticket` → `wss://<host>/api/gateway?ticket=...`. DM mesajları (`message.*`), DM yazıyor (`typing`) ve arkadaş durumu (`presence`) buradan gelir.

Kanala özgü olaylar (`message.*`, `channel.*`, `typing`, ses durumu) yalnızca o kanalda `VIEW_CHANNEL` izni olan bağlantılara gönderilir. `sound.play` yalnızca aynı ses odasındakilere gider.
