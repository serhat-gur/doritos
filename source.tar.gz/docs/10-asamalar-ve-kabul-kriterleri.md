# 10 — Geliştirme Aşamaları ve Kabul Kriterleri

## Aşama 1 — İlk dikey dilim ✅ TAMAMLANDI

| Kabul kriteri | Kanıt |
|---|---|
| Uygulama açılır (Electron, güvenli ayarlarla) | Electron sanal ekranda başlatıldı, köprü/izolasyon/gezinme kilidi doğrulandı |
| Kayıt / giriş / çıkış | `api.test.ts`, uçtan uca test, Electron içinde giriş |
| Sunucu ve kanal oluşturma, davetle katılma | `api.test.ts`, uçtan uca test |
| Sunucu tarafı RBAC (özel kanal, overwrite, hiyerarşi) | `api.test.ts`, `realtime.test.ts`, `permissions.test.ts` |
| İki kullanıcı arasında gerçek zamanlı mesaj + yazıyor göstergesi | `realtime.test.ts`, uçtan uca test |
| İki kullanıcı arasında çalışan sesli görüşme | Uçtan uca test: iki yönde WebRTC ses baytı, konuşma göstergesi, susturma |
| Ses panelinden odadaki herkesin aynı sesi duyması | `realtime.test.ts` + uçtan uca test: iki istemcide aynı `playAt`'e planlandı |

Testler: 14 (shared) + 14 (server, workerd üzerinde D1/DO/R2/WS) + 5 (desktop) + uçtan uca 14 adım.

## Aşama 2 — Eksiklerin tamamlanması ✅ TAMAMLANDI (sıfır ücret kısıtıyla)

| Kabul kriteri | Kanıt |
|---|---|
| Ekran paylaşımı (ekran/pencere, 720p/1080p, 15/30/60 FPS, dinamik bitrate, çoklu yayın, sistem sesi seçeneği, paylaşırken ses sürer) | Uçtan uca: görüntü izleyiciye ulaştı, ses bağlı kaldı; `moderation.test.ts` (izin, sinyal) |
| Global makrolar: klavye/mouse ile sustur, sağırlaştır; bas-konuş isteğe bağlı | Gerçek Electron + X11 donanım olayları; tarayıcıda uçtan uca F8 |
| Arkadaş ekleme/kaldırma, engelleme, DM, grup DM | `social.test.ts`, uçtan uca |
| Dosya/resim, emoji tepkileri, mesaj arama, profil resmi, sunucu resmi | `social.test.ts`, uçtan uca |
| Rol yönetimi ekranı, kanal izinleri, moderasyon (sustur/sağırlaştır/taşı/at/yasakla) | `moderation.test.ts`, uçtan uca |
| Otomatik güncelleme altyapısı | Paketli uygulamada güncelleyici yapılandırması doğrulandı; gerçek yayın akışı denenmedi |
| Hiçbir bileşen ücretli kullanıma geçemez | R2 kaldırıldı (DO deposu), SFU yok, TURN varsayılan kapalı, 3,5 GB depolama tavanı |

## Aşama 3 — Gerçek Windows ve gerçek ağlar
- Windows 10/11'de `pnpm dist:win` kurulumu; tepsi, bildirim, başlangıçta açılma, global makrolar (Mouse 4/5), sistem sesiyle yayın.
- İki farklı evden (farklı NAT) 30 dk kesintisiz ses + 1080p30 yayın; doğrudan bağlanamayan biri olursa yalnızca onun için TURN.
- **Kabul:** 5 kişilik odada 1 yayıncı + 3 izleyici, ses kesintisiz.

## Aşama 4 — İsteğe bağlı iyileştirmeler
- DM'de sesli arama; aramada mesaja atlama; sunucu tarafı okunmamış durumu.
- Kullanım izleme Cron'u (ücretsiz limitlere yaklaşınca uyarı).
- Kod imzalama; sağlayıcı soyutlaması ve kendi sunucuda çalıştırma kılavuzu.

Her aşamada: `pnpm typecheck`, `pnpm test`, uçtan uca test, README'deki "çalışan / henüz uygulanmayan" listesinin güncellenmesi.
