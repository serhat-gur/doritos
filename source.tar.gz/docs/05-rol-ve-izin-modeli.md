# 05 — Rol ve İzin Modeli (RBAC)

Kaynak: [`packages/shared/src/permissions.ts`](../packages/shared/src/permissions.ts)

## İzinler (bit alanı)

`ADMINISTRATOR, MANAGE_SERVER, MANAGE_CHANNELS, MANAGE_ROLES, VIEW_CHANNEL, SEND_MESSAGES, MANAGE_MESSAGES, CONNECT_VOICE, SPEAK, MUTE_MEMBERS, DEAFEN_MEMBERS, MOVE_MEMBERS, KICK_MEMBERS, BAN_MEMBERS, MANAGE_SOUNDBOARD, UPLOAD_SOUNDS, PLAY_SOUNDS, SCREEN_SHARE, CREATE_INVITE`

`ADMINISTRATOR` ve `CREATE_INVITE` istek listesine eklendi (ilki tüm izinleri verir, ikincisi davet oluşturmayı ayrı yönetmek için).

## Varsayılan roller (sunucu oluşturulunca)

| Rol | Konum | İzinler |
|---|---|---|
| Owner | — | Rol değil; `guilds.owner_id`. Her zaman tüm izinler |
| Admin | 3 | `ADMINISTRATOR` |
| Moderator | 2 | Member + MANAGE_MESSAGES, MUTE/DEAFEN/MOVE/KICK_MEMBERS, MANAGE_SOUNDBOARD |
| @everyone (Member) | 0 | VIEW_CHANNEL, SEND_MESSAGES, CONNECT_VOICE, SPEAK, PLAY_SOUNDS, UPLOAD_SOUNDS, SCREEN_SHARE, CREATE_INVITE |
| Özel roller | 1+ | `POST /api/guilds/:id/roles` |

## Hesaplama sırası

1. Sahip → tümü.
2. Taban = @everyone izinleri ∪ üyenin rollerinin izinleri. `ADMINISTRATOR` varsa → tümü.
3. Kanal: @everyone overwrite (deny sonra allow) → üyenin rollerinin overwrite'ları birleşik (deny sonra allow) → üyeye özel overwrite.
4. Sonuçta `VIEW_CHANNEL` yoksa kanal için hiçbir izin yoktur (ve API kanalı **404** döner — varlığı sızdırılmaz).

## Hiyerarşi kuralları (sunucuda uygulanır)

- Kimse sahip olmadığı bir izni role veya overwrite'a koyamaz.
- Kendi en yüksek rolüne eşit/üstündeki rolü atayamaz/kaldıramaz.
- Kendine eşit/üst roldeki birini atamaz; sahip atılamaz.

## Nerede kontrol edilir?

| İşlem | Yer | İzin |
|---|---|---|
| Kanal oluştur/düzenle/sil | Worker | MANAGE_CHANNELS |
| Overwrite yaz | Worker | MANAGE_ROLES (+ hiyerarşi) |
| Mesaj oku / gönder | Worker | VIEW_CHANNEL / SEND_MESSAGES |
| Başkasının mesajını sil | Worker | MANAGE_MESSAGES |
| Mesaj yayını alıcıları | DO | VIEW_CHANNEL (alıcı başına) |
| Sesli kanala katıl | DO | CONNECT_VOICE (SPEAK yoksa sunucu susturmalı katılır) |
| Ses çal | DO | PLAY_SOUNDS (kanal düzeyi) |
| Ses yükle (sunucu paneli) | Worker | UPLOAD_SOUNDS |
| Başkasının sunucu sesini düzenle/sil | Worker | MANAGE_SOUNDBOARD |
| Sunucuda sustur / sağırlaştır | DO | MUTE_MEMBERS / DEAFEN_MEMBERS (kalıcı; yeniden katılınca sürer) |
| Taşı / sesten çıkar | DO | MOVE_MEMBERS (kaynak ve hedef kanalda) |
| Ekran paylaş | DO | SCREEN_SHARE (kanal düzeyi) |
| Yasakla / yasak kaldır | Worker | BAN_MEMBERS (+ hiyerarşi) |
| Rol düzenle / sil | Worker | MANAGE_ROLES (+ hiyerarşi) |

İstemci aynı fonksiyonla hesaplanan `myPermissions` değerini yalnızca düğmeleri gizlemek için kullanır.

Arayüz: sunucu ayarları (roller, kanal izinleri, yasaklar) ve üye menüsü (rol ver/al, moderasyon). Sunucu sahibine moderasyon uygulanamaz.

Sunucu susturması P2P'de alıcı tarafta da uygulanır: susturulan kişinin sesi diğer istemcilerde kapatılır; sağırlaştırılan kişiye soundboard olayı hiç gönderilmez.
