# 07 — WebRTC / SFU Bağlantı Stratejisi

## Katmanlar

```
VoiceSession  ── mikrofon, VAD / bas-konuş kapısı, mute/deaf, yeniden katılma, istatistik
     │
MediaTransport (arayüz)
     ├─ MeshTransport   ✅ uygulandı — eş başına RTCPeerConnection
     └─ SfuTransport    — bilinçli olarak yok (1.000 GB sonrası ücretli)

ScreenShare (ayrı katman) ✅ — yayıncı → her izleyiciye ayrı RTCPeerConnection
```

Kaynak: `apps/desktop/src/renderer/src/media/`.

## P2P (mesh) — uygulanan

- **Sinyal:** `GuildHub` DO, `rtc.signal`'i yalnızca aynı ses odasındaki iki kullanıcı arasında iletir.
- **Müzakere:** İlk teklifi yalnızca kullanıcı id'si küçük olan taraf başlatır (ses transceiver'ını o ekler); diğer taraf gelen teklifin transceiver'ına kendi izini bağlar. Bu, iki tarafın aynı anda teklif gönderip birinin gönderici izini kaybetmesini (glare) önler — bu hata uçtan uca testte yakalanıp düzeltildi. Sonraki yeniden müzakereler için MDN "perfect negotiation" deseni korunur.
- **ICE:** `GET /api/voice/ice-servers`. Worker, Cloudflare Realtime TURN API'sinden kullanıcıya kısa ömürlü kimlik bilgisi üretir; **TURN anahtarı istemciye hiç gönderilmez**. TURN yapılandırılmamışsa yalnızca `stun:stun.cloudflare.com:3478` döner. Tarayıcıların engellediği 53 numaralı port URL'leri süzülür.
- **NAT / port açma:** Gerekmez. ICE önce doğrudan (host/srflx), olmazsa TURN relay adaylarını dener. Cloudflare TURN, UDP'nin engellendiği ağlar için TCP ve TLS (443) üzerinden de hizmet verir.
- **Kopma:** `connectionState === "failed"` → `restartIce()`. Gateway koparsa `ready` sonrası kanala yeniden katılınır; susturma/sağırlık durumu yeniden gönderilir.
- **Kalite:** 3 sn'de bir `getStats()`: RTT, jitter, paket kaybı, alınan bayt, TURN üzerinden mi. Arayüzde sinyal ikonu ve "TURN" etiketi.

**Doğrulama (uçtan uca test):** İki Chrome istemcisi sahte mikrofonla bağlanır; her iki yönde ses baytı aktığı, konuşma göstergesinin karşı tarafta göründüğü test edilir.

## Ekran paylaşımı — uygulanan

- Yayıncı `screen.start` gönderir; kanaldakiler katılımcı listesinde **CANLI** rozetini görür.
- İzlemek isteyen `screen-down` + `watch` gönderir; yayıncı yalnızca o kişi için bağlantı açar ve teklif yollar (`screen-up`). İzlemeyenlere hiç video gönderilmez.
- Kalite: 720p/1080p × 15/30/60 FPS. `contentHint` (30 FPS'e kadar "detail" → yazı okunaklı, 60 FPS'te "motion"), `degradationPreference` ve `maxFramerate` ayarlanır.
- **Dinamik bitrate:** WebRTC tıkanıklık kontrolü bitrate'i ağa göre düşürür; üst sınır seçilen kaliteye ve izleyici sayısına göre ayarlanır (12 Mbps toplam yükleme bütçesi izleyicilere bölünür, izleyici başı en az 0,8 Mbps).
- Ses görüşmesi ayrı bağlantıda olduğu için paylaşım sırasında kesilmez (uçtan uca testte doğrulandı).
- Electron: uygulama içi ekran/pencere seçici (`desktopCapturer` önizlemeleri) → `setDisplayMediaRequestHandler`; Windows'ta isteğe bağlı sistem sesi (`loopback`).
- Uçtan uca testte yakalanan hata: izleyici konuştukça gelen ses durumu güncellemeleri, yayıncının onu izleyici listesinden düşürmesine yol açıyordu; yayın bitişi yalnızca izlenen yayına uygulanacak şekilde düzeltildi.

## Ne zaman SFU?

Mesh'te her katılımcı N−1 akış gönderir. Opus ≈ 32–64 kbps ile 5 kişiye kadar ses sorun değildir; **ekran paylaşımı** (1080p ≈ 3 Mbps × izleyici sayısı) yükleme bant genişliğini hızla tüketir.

Planlanan kural: ses odasında **≤ 4 kişi ve ekran paylaşımı yok → mesh**, aksi halde SFU.

## SFU tasarımı (ücret nedeniyle uygulanmadı; ihtiyaç olursa)

- Worker, Cloudflare Realtime SFU HTTPS API'sinde oturum açar (app secret yalnızca Worker'da).
- Her istemci tek RTCPeerConnection ile yerel izini yayınlar (`tracks/new`, local), diğerlerinin izlerini çeker (remote). İz listesi `GuildHub` üzerinden duyurulur.
- **Geçiş:** `VoiceSession` yerel mikrofon izini ve mute/deaf durumunu tutar; taşıma değiştirilirken iz `setLocalTrack` ile yenisine verilir, eski taşıma kapatılır. Kısa (≈1 sn) kesinti beklenir.
- Boşta (oda boşalınca) SFU oturumları istemci ayrılınca kapanır; Cloudflare tarafında sunucu çalışmaz, maliyet yalnızca aktarılan GB'dir.

## UDP engelliyse

1. TURN over TCP/TLS 443 (Cloudflare TURN destekler) — mesh ve SFU için ilk yedek.
2. Gerekirse SFU'ya TURN üzerinden bağlanma (TURN↔SFU trafiği iki kez ücretlendirilmez).
