# 03 — Monorepo Klasör Yapısı

pnpm workspaces. Ortak tipler ve Zod şemaları `@yanki/shared` paketinde; Worker ve masaüstü uygulaması aynı kaynağı içe aktarır (derleme adımı yok, TypeScript kaynağı doğrudan paketlenir).

```
yanki/
├─ package.json                # kök betikler: typecheck, test, dev:server, dev:desktop, dist:win, e2e
├─ pnpm-workspace.yaml
├─ tsconfig.base.json          # strict, noUncheckedIndexedAccess
├─ docs/                       # bu dokümanlar
├─ scripts/
│  └─ e2e_two_clients.py       # iki Chrome istemcisiyle uçtan uca test
├─ packages/
│  └─ shared/                  # @yanki/shared
│     ├─ src/permissions.ts    # izin bitleri + hesaplama (RBAC)
│     ├─ src/schemas.ts        # Zod giriş şemaları + DTO tipleri
│     ├─ src/events.ts         # WebSocket olay sözleşmesi
│     ├─ src/limits.ts         # teknik limitler
│     ├─ src/sound-sniff.ts    # ses biçimi tespiti (magic bytes)
│     └─ test/
├─ apps/
│  ├─ server/                  # @yanki/server — Cloudflare Worker
│  │  ├─ wrangler.jsonc        # D1 ve Durable Object bağları (R2 yok)
│  │  ├─ migrations/           # D1 şeması
│  │  ├─ src/index.ts          # Hono uygulaması, gateway yükseltme, /files
│  │  ├─ src/routes/           # auth, guilds/channels/invites/roles/bans, messages (+tepki, arama), social (arkadaş, engel, DM), sounds, voice
│  │  ├─ src/do/GuildHub.ts    # WebSocket, presence, ses odası, sinyal, soundboard, ekran paylaşımı, moderasyon
│  │  ├─ src/do/UserHub.ts     # kişisel gateway: arkadaşlar, DM, arkadaş durumu
│  │  ├─ src/do/BlobStore.ts   # ücretsiz dosya deposu (R2 yerine)
│  │  ├─ src/do/RateLimiter.ts
│  │  ├─ src/lib/              # crypto, perms, dto, files, ratelimit, log, ids
│  │  └─ test/                 # workerd üzerinde entegrasyon testleri
│  └─ desktop/                 # @yanki/desktop — Electron + React
│     ├─ electron.vite.config.ts
│     ├─ electron-builder.yml  # Windows NSIS
│     ├─ src/main/index.ts     # pencere, tepsi, IPC, safeStorage, izinler, ekran kaynağı, güncelleyici
│     ├─ src/main/input-hook.ts # global klavye/mouse makroları
│     ├─ src/preload/          # contextBridge API (window.yanki)
│     ├─ src/renderer/
│     │  ├─ index.html         # CSP
│     │  └─ src/
│     │     ├─ lib/            # api, gateway, clock, realtime, bridge
│     │     ├─ media/          # transport, mesh-transport, voice-session, screen-share, macros, sound-player
│     │     ├─ stores/         # Zustand
│     │     └─ components/     # Login, Shell, Home (arkadaş/DM), Chat, Stage (yayınlar), MemberMenu, GuildSettings, VoiceBar, Soundboard, Settings
│     └─ test/
```

Kural: `apps/*` birbirini içe aktarmaz; yalnızca `packages/*` paylaşılır.
