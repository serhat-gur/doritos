# 01 — Mimari Karar Dokümanı (ADR)

Her kararın gerekçesi ve bedeli yazılıdır. "Durum" sütunu kodda gerçekten uygulanıp uygulanmadığını gösterir.

| # | Karar | Durum |
|---|-------|-------|
| 1 | Sunucu (guild) başına bir Durable Object (`GuildHub`) | Uygulandı |
| 2 | Kalıcı değişiklikler REST, gerçek zamanlı olaylar WebSocket | Uygulandı |
| 3 | WebSocket Hibernation API + soket ekinde (attachment) durum | Uygulandı |
| 4 | WebSocket kimliği için kısa ömürlü HMAC bileti | Uygulandı |
| 5 | İzinler bit alanı, hesaplama ortak pakette | Uygulandı |
| 6 | Worker imzalı dosya URL'leri; dosyalar R2 yerine ücretsiz DO depolamasında (`BlobStore`) | Uygulandı |
| 7 | Ses ve ekran paylaşımı P2P (soyut taşıma katmanı); SFU ücretli olduğu için yok | Mesh uygulandı |
| 11 | Kişisel gateway: kullanıcı başına DO (`UserHub`) — arkadaşlık, DM, arkadaş durumu | Uygulandı |
| 12 | Global makrolar için yerel kanca (uiohook-napi), yalnızca atanmış tuşlar renderer'a iletilir | Uygulandı |
| 8 | Soundboard sesleri mikrofona karıştırılmaz, istemcide planlı çalınır | Uygulandı |
| 9 | Şifre hash'i PBKDF2-SHA256 (WebCrypto) | Uygulandı |
| 10 | Sağlayıcı bağımlılığının sınırlanması | Kısmen |

## 1. Guild başına Durable Object
**Bağlam:** Mesaj yayını, presence, ses odası üyeliği ve soundboard olayları tek bir tutarlı noktadan sıralanmalı.
**Karar:** `idFromName(guildId)` ile her sunucu için bir `GuildHub`. İstemci, üyesi olduğu her sunucuya ayrı bir WebSocket açar.
**Neden:** 5–10 kişilik grup için tek DO fazlasıyla yeter; olaylar doğal olarak sıralanır; ses odası koordinasyonu ve sinyal aktarımı aynı yerde olduğundan "aynı odada mı?" kontrolü yerel ve ucuzdur.
**Bedel:** Çok sayıda sunucuya üye bir kullanıcı çok soket açar. Ölçek büyürse kullanıcı başına bir "Gateway DO" + guild DO'larına abonelik modeline geçilir (istemci sözleşmesi değişmez).

## 2. REST yazar, DO yayınlar
**Karar:** Mesaj gönderme, kanal oluşturma vb. Worker'daki REST uçlarıyla yapılır: yetki kontrolü → D1 yazma → `GuildHub.broadcast()` RPC. Yazıyor göstergesi, ses durumu, WebRTC sinyali ve `sound.play` WS üzerinden gelir ve DO'da yetkilendirilir.
**Neden:** Tüm kalıcı yazmalar tek yoldan geçer (doğrulama, rate limit, test edilebilirlik). Yayın başarısız olsa bile veri D1'dedir; istemci yeniden bağlanınca REST'ten tazeler.
**Bedel:** Mesaj başına bir DO RPC isteği (ücretsiz kotada önemsiz).

## 3. Hibernation
DO, `ctx.acceptWebSocket()` ile soketleri kabul eder; bağlantı açıkken boşta kalan nesne bellekten atılabilir ve süre (duration) ücreti işlemez. Bu yüzden bağlantı başına durum (`userId`, ses durumu, cooldown) `serializeAttachment` ile sokete yazılır; bellek yalnızca önbellektir (izin anlık görüntüsü, oda rate-limit penceresi). Uyanma sonrası oda penceresi sıfırlanır — kabul edilebilir.

## 4. WebSocket bileti
Tarayıcı `WebSocket` API'si özel başlık gönderemez; token'ı URL'ye koymak loglara sızdırır. İstemci `POST /api/guilds/:id/gateway-ticket` ile 60 sn ömürlü, guild'e bağlı HMAC imzalı bilet alır. Worker bileti doğrular, üyeliği D1'de kontrol eder ve isteği `X-Yanki-User` başlığıyla DO'ya iletir. DO dışarıdan doğrudan erişilemez.

## 5. İzin modeli
Bkz. [05-rol-ve-izin-modeli.md](05-rol-ve-izin-modeli.md). Hesaplama `packages/shared` içinde saf fonksiyondur; Worker, DO ve istemci aynı kodu kullanır. İstemcideki hesap yalnızca arayüz içindir; **her kritik kontrol sunucuda tekrar yapılır**.

## 6. Dosya deposu ve imzalı URL'ler

**Sıfır ücret kararı:** R2 hesaba ödeme yöntemi eklemeyi gerektirir ve ücretsiz katman aşılınca fatura keser. Bunun yerine dosyalar `BlobStore` Durable Object'lerinde (SQLite, 1 MB parçalar, 16 shard) tutulur; ücretsiz planda toplam 5 GB'tır ve aşımda yalnızca hata verir. D1'deki `blobs` tablosu her dosyanın boyutunu tutar; uygulama 3,5 GB'lık genel tavanı ve kullanıcı kotalarını yüklemeden önce uygular. Anahtar içerik hash'ini içerdiği için dosyalar değişmez ve süresiz önbelleğe alınabilir.

### İmzalı URL'ler
R2'nin S3 uyumlu presigned URL'leri ayrı R2 API anahtarı ister ve yerel geliştirmede (Miniflare) çalışmaz. Worker kendi HMAC imzalı, süreli URL'lerini üretir (`/files/<key>?exp&sig`). Süre saat başına yuvarlanır, böylece HTTP önbelleği etkili olur. Yükleme Worker üzerinden yapılır; içerik baytlarından biçim doğrulanır (uzantıya/Content-Type'a güvenilmez). Bedeli: her indirme bir Worker isteği; istemci önbelleği (sha256 anahtarlı) bunu en aza indirir. Büyük dosyalar (ekran kaydı vb.) gelirse doğrudan R2 presign'a geçilebilir.

## 7. Medya: P2P → SFU
Bkz. [07-webrtc-sfu-stratejisi.md](07-webrtc-sfu-stratejisi.md).

## 8. Soundboard
Bkz. [08-soundboard-mimarisi.md](08-soundboard-mimarisi.md). Sesler mikrofon izine karıştırılmaz; her istemci aynı sesi sunucunun belirlediği ana planlayarak kendisi çalar.

## 9. Şifreler
PBKDF2-SHA256, 16 bayt tuz, varsayılan 100.000 tur (workerd'nin üst sınırı). Biçim `pbkdf2$<tur>$<tuz>$<hash>` — tur sayısı hash içinde olduğundan ileride artırılabilir. Kullanıcı yokken de sahte doğrulama yapılır (zamanlama ile kullanıcı adı sızmasın). **Risk:** Ücretsiz planın 10 ms CPU sınırı; bkz. [02-cloudflare-maliyet-analizi.md](02-cloudflare-maliyet-analizi.md#cpu-riski).

## 10. Sağlayıcıdan bağımsızlık
- İş kuralları (izinler, şemalar, olay sözleşmeleri) Cloudflare'den bağımsız `packages/shared` içinde.
- Hono, Node/Bun/Deno üzerinde de çalışır. D1 SQLite'tır; şema taşınabilir.
- **Henüz yapılmadı:** `DB`, `FILES`, `Hub` için arayüz katmanı (repository/port). Kendi sunucuya taşımak için: D1 → SQLite/Postgres, R2 → S3/MinIO, DO → tek süreçli Node WebSocket sunucusu + Redis pub/sub. Bu iş Aşama 4'te planlandı.
