# 04 — D1 Veritabanı Şeması

Kaynak: [`0001_init.sql`](../apps/server/migrations/0001_init.sql), [`0002_social_media.sql`](../apps/server/migrations/0002_social_media.sql). Kimlikler 26 karakterlik zaman sıralı ULID; zamanlar Unix ms.

| Tablo | Amaç | Not |
|---|---|---|
| `users` | Hesap, görünen ad, durum, profil | `username` benzersiz, küçük harf |
| `sessions` | Oturumlar | Token'ın yalnızca **SHA-256 hash'i** saklanır |
| `friendships` | Arkadaşlık / istek / engel | Yönlü; `accepted` iki kayıt, `blocked` engelleyenin kaydı |
| `guilds` | Sunucular | `owner_id` |
| `guild_members` | Üyelik | |
| `roles` | Roller | `permissions` bit alanı; **@everyone rolünün id'si = guild id** |
| `member_roles` | Üye ↔ rol | İstekte "RolePermissions" ayrı tablo yerine bit alanı seçildi (tek satır okuma) |
| `bans` | Yasaklar | Davet kabulünde kontrol edilir |
| `channels` | Kanal ve kategoriler | `type` text/voice/category, `parent_id`, `position` |
| `channel_overwrites` | Kanal izinleri ("ChannelPermissions") | rol veya üye bazlı allow/deny |
| `messages` | Mesajlar | `(channel_id, id)` indeksi ile sayfalama; **silme kalıcıdır** (satır, ekler, tepkiler, arama kaydı; 0003 eski yumuşak silinmişleri temizler). Not: Cloudflare D1'in kapatılamayan 7 günlük Time Travel yedeği ve DO depolamasının 30 günlük geri yüklemesi yalnızca hesap sahibince kullanılabilir |
| `invites` | Davet kodları | `max_uses`, `expires_at`, koşullu sayaç artırımı |
| `sounds` | Soundboard sesleri | `guild_id NULL` = kişisel; `sha256` önbellek anahtarı |
| `sound_favorites` | Favoriler | |
| `voice_sessions` | Sesli oturum kayıtları | DO yazar; kullanım istatistiği |
| `blobs` | Tüm dosyaların kaydı (anahtar, sahip, tür, boyut) | Kotalar ve 3,5 GB genel tavan buradan; içerik BlobStore DO'da |
| `attachments` | Mesaj ekleri | `is_image` satır içi gösterim için |
| `reactions` | Emoji tepkileri | (mesaj, kullanıcı, emoji) birincil anahtar |
| `dm_channels` / `dm_members` / `dm_messages` | Birebir ve grup DM | `dm_key` birebir DM'yi tekil yapar |
| `messages_fts` | FTS5 tam metin dizini | Tetikleyicilerle güncel; `remove_diacritics 2` ile aksan duyarsız |

**"Soundboards" tablosu neden yok?** Panel, kapsam (kişisel / sunucu) + kategori ile mantıksal olarak oluşur. Paylaşılan özel paneller gerekirse `soundboards(id, owner_id, guild_id, name)` + `sounds.board_id` eklenir.

`sounds.r2_key` sütununun adı tarihsel; artık BlobStore anahtarını tutar.

**Sonraki migrasyonlar:** `read_states` (sunucu tarafı okunmamış), `usage_daily` (kullanım izleme).

Migrasyonlar:
```bash
pnpm --filter @yanki/server db:migrate:local   # yerel
pnpm --filter @yanki/server db:migrate:remote  # Cloudflare
```
