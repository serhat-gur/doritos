# 08 — Soundboard Mimarisi

## Akış (uygulandı ve uçtan uca test edildi)

1. **Yükleme** `POST /api/sounds` (multipart). Worker: boyut ≤ 2 MB, **içerik baytlarından** biçim tespiti (MP3/WAV/OGG — uzantı ve Content-Type'a güvenilmez), kullanıcı (100 MB) ve sunucu (500 MB) kotası, yükleme rate limit'i, sunucu paneli için `UPLOAD_SOUNDS`.
2. Dosya ücretsiz `BlobStore` Durable Object deposuna `sNN/sound/<id>/<sha256>` anahtarıyla yazılır (değişmez içerik, `immutable` önbellek başlığı); genel 3,5 GB tavan ve kullanıcı kotası önce kontrol edilir. Metadata D1'e yazılamazsa dosya geri silinir.
3. Kullanıcı panelde bir sese basar → WS `sound.play { soundId }`.
4. `GuildHub`: kullanıcı ses odasında mı, kanal düzeyinde `PLAY_SOUNDS` var mı, ses bu sunucuya mı ait (kişisel sesi yalnızca sahibi çalabilir), kullanıcı cooldown'u (1,5 sn), oda limiti (5 sn'de 6 ses).
5. DO, `playAt = sunucuSaati + 250 ms` ve imzalı URL ile `sound.play` olayını **yalnızca o ses odasındakilere** gönderir.
6. İstemci: bellek → Cache Storage (`sha256` anahtarlı, diskte kalıcı) → ağ sırasıyla sesi alır; indirilen içeriğin SHA-256'sını doğrular.
7. Saat farkı (ping/pong, en düşük RTT'li örnek) düşülerek ses `AudioContext` zaman çizelgesinde aynı ana planlanır. Geç kalınırsa (≤1 sn) baştan kırpılarak, daha fazlaysa hemen çalınır.

**Ölçülen sonuç (yerel uçtan uca test):** ses iki istemcide de oynatma anından ~210–244 ms önce planlandı, yani her iki taraf aynı `playAt` anında çaldı.

## Mikrofonu etkilememe

Sesler mikrofon izine **karıştırılmaz**. Her istemci sesi kendi `AudioContext`'inde çalar. Sonuçlar:
- Mikrofonun gürültü bastırma/yankı engelleme davranışı bozulmaz, ses kalitesi düşmez.
- Uzak taraftaki kullanıcı, sesi kendi ses ayarlarıyla duyar: genel soundboard seviyesi, kullanıcı başına soundboard seviyesi (0 = o kişinin seslerini sustur), sağırken hiç çalınmaz.
- Eşzamanlı çalan ses sayısı istemcide 4 ile sınırlı (en eskisi kesilir).

## Kullanıcı özellikleri

| Özellik | Durum |
|---|---|
| MP3/WAV/OGG yükleme, isim, emoji, kategori, ses seviyesi | ✅ |
| Kişisel ve sunucu paneli | ✅ |
| Sınırsız kategori (serbest metin) | ✅ |
| Düzenleme / silme (sahibi veya MANAGE_SOUNDBOARD) | ✅ |
| Favoriler | ✅ |
| Önizleme (yalnızca yerel, sağ tık) | ✅ |
| Klavye kısayolu atama — Electron'da **global** kısayol | ✅ (kod hazır; Windows'ta elle doğrulanmalı) |
| Ses başına ses seviyesi | ✅ |
| Ses süresi sınırı (ör. ≤ 10 sn) | ❌ sunucuda çözümleme gerekir; şimdilik yalnızca boyut |
| Ses kırpma / normalize | ❌ |

## Limitler

Ürün limiti (ses sayısı) yoktur. Teknik limitler `packages/shared/src/limits.ts` dosyasında tek yerden yapılandırılır.
