import { LIMITS } from "@yanki/shared";
import type { Env } from "../env";
import { hmacSign, hmacVerify } from "./crypto";
import { appSecret } from "./secrets";

/**
 * İmzalı dosya URL'leri.
 *
 * R2'nin S3 uyumlu presigned URL'leri ayrı bir R2 API anahtarı gerektirir ve
 * yerel geliştirmede (Miniflare) çalışmaz. Bu yüzden Worker kendi HMAC imzalı,
 * süreli URL'lerini üretir: /files/<key>?exp=<ms>&sig=<hmac>.
 * Bu URL'ler kimlik doğrulaması gerektirmez ama süre dolunca geçersizdir ve
 * anahtar tahmin edilemez. R2 egress ücretsizdir; her indirme bir Worker
 * isteği sayılır (istemci önbelleği bunu en aza indirir).
 *
 * Exp, saat başına yuvarlanır → aynı dosya için URL bir saat boyunca sabit
 * kalır, HTTP önbelleği de etkili olur.
 */
export async function signedFileUrl(env: Env, origin: string, key: string, ttlMs = LIMITS.FILE_URL_TTL_MS): Promise<string> {
  const hour = 60 * 60 * 1000;
  const exp = Math.ceil((Date.now() + ttlMs) / hour) * hour;
  const sig = await hmacSign(appSecret(env), `file:${key}:${exp}`);
  return `${origin}/files/${encodeURI(key)}?exp=${exp}&sig=${sig}`;
}

export async function verifyFileSignature(env: Env, key: string, exp: string | undefined, sig: string | undefined): Promise<boolean> {
  if (!exp || !sig) return false;
  const expMs = Number(exp);
  if (!Number.isFinite(expMs) || expMs < Date.now()) return false;
  return hmacVerify(appSecret(env), `file:${key}:${expMs}`, sig);
}
