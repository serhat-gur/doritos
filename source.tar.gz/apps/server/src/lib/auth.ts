import { createMiddleware } from "hono/factory";
import { LIMITS } from "@yanki/shared";
import type { AppBindings, Env } from "../env";
import { randomToken, sha256Hex } from "./crypto";
import { unauthorized } from "./errors";
import { newId } from "./ids";

/**
 * Oturumlar: istemciye rastgele 256-bit token verilir, D1'de yalnızca
 * SHA-256 hash'i saklanır (DB sızsa bile token'lar kullanılamaz).
 */
export async function createSession(env: Env, userId: string, userAgent: string | null): Promise<string> {
  const token = randomToken(32);
  const now = Date.now();
  await env.DB.prepare(
    "INSERT INTO sessions (id, user_id, token_hash, user_agent, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)",
  )
    .bind(newId(), userId, await sha256Hex(token), userAgent?.slice(0, 200) ?? null, now, now + LIMITS.SESSION_TTL_MS)
    .run();
  return token;
}

export const requireAuth = createMiddleware<AppBindings>(async (c, next) => {
  const header = c.req.header("Authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7).trim() : null;
  if (!token || token.length > 100) throw unauthorized();
  const row = await c.env.DB.prepare(
    `SELECT s.id AS session_id, s.expires_at, u.id, u.username, u.display_name
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ?`,
  )
    .bind(await sha256Hex(token))
    .first<{ session_id: string; expires_at: number; id: string; username: string; display_name: string }>();
  if (!row || row.expires_at < Date.now()) throw unauthorized("Oturum geçersiz veya süresi dolmuş");
  c.set("user", { id: row.id, username: row.username, displayName: row.display_name, sessionId: row.session_id });
  await next();
});
