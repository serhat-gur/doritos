import type { ServerEvent } from "@yanki/shared";
import type { Env } from "../env";
import { log } from "./log";

export function userHub(env: Env, userId: string) {
  return env.USER_HUB.get(env.USER_HUB.idFromName(userId));
}

/** Olayı kullanıcıların kişisel gateway'lerine (arkadaşlar, DM) iletir. */
export async function publishUsers(env: Env, userIds: string[], event: ServerEvent): Promise<void> {
  await Promise.all(
    [...new Set(userIds)].map(async (id) => {
      try {
        await userHub(env, id).send(event);
      } catch (err) {
        log("warn", "userhub.publish_failed", { userId: id, event: event.t, err: String(err) });
      }
    }),
  );
}
