import {
  computeBasePermissions,
  computeChannelPermissions,
  type ChannelOverwrite,
  type PermissionContext,
  type RoleLike,
} from "@yanki/shared";

/**
 * Bir sunucunun yetki hesaplaması için gereken tüm verisi. Durable Object
 * içinde kısa süre önbelleğe alınır; böylece bir mesaj yayınında her alıcı
 * için ayrı D1 sorgusu yapılmaz.
 */
export interface GuildSnapshot {
  guildId: string;
  ownerId: string;
  roles: RoleLike[];
  memberRoles: Map<string, string[]>;
  members: Set<string>;
  channels: Map<string, { type: "text" | "voice" | "category"; overwrites: ChannelOverwrite[] }>;
  loadedAt: number;
}

export async function loadGuildSnapshot(db: D1Database, guildId: string): Promise<GuildSnapshot | null> {
  const [g, roles, members, memberRoles, channels, overwrites] = await db.batch([
    db.prepare("SELECT owner_id FROM guilds WHERE id = ?").bind(guildId),
    db.prepare("SELECT id, permissions, position FROM roles WHERE guild_id = ?").bind(guildId),
    db.prepare("SELECT user_id FROM guild_members WHERE guild_id = ?").bind(guildId),
    db.prepare("SELECT user_id, role_id FROM member_roles WHERE guild_id = ?").bind(guildId),
    db.prepare("SELECT id, type FROM channels WHERE guild_id = ?").bind(guildId),
    db
      .prepare(
        "SELECT o.channel_id, o.target_type, o.target_id, o.allow, o.deny FROM channel_overwrites o JOIN channels c ON c.id = o.channel_id WHERE c.guild_id = ?",
      )
      .bind(guildId),
  ]);
  const owner = g!.results[0] as { owner_id: string } | undefined;
  if (!owner) return null;

  const mr = new Map<string, string[]>();
  for (const r of memberRoles!.results as { user_id: string; role_id: string }[]) {
    const list = mr.get(r.user_id) ?? [];
    list.push(r.role_id);
    mr.set(r.user_id, list);
  }
  const ch = new Map<string, { type: "text" | "voice" | "category"; overwrites: ChannelOverwrite[] }>();
  for (const c of channels!.results as { id: string; type: "text" | "voice" | "category" }[]) {
    ch.set(c.id, { type: c.type, overwrites: [] });
  }
  for (const o of overwrites!.results as {
    channel_id: string;
    target_type: "role" | "member";
    target_id: string;
    allow: number;
    deny: number;
  }[]) {
    ch.get(o.channel_id)?.overwrites.push({
      targetType: o.target_type,
      targetId: o.target_id,
      allow: o.allow,
      deny: o.deny,
    });
  }
  return {
    guildId,
    ownerId: owner.owner_id,
    roles: roles!.results as RoleLike[],
    memberRoles: mr,
    members: new Set((members!.results as { user_id: string }[]).map((m) => m.user_id)),
    channels: ch,
    loadedAt: Date.now(),
  };
}

export function snapshotContext(s: GuildSnapshot, userId: string): PermissionContext {
  return {
    isOwner: s.ownerId === userId,
    userId,
    everyoneRoleId: s.guildId,
    roles: s.roles,
    memberRoleIds: s.memberRoles.get(userId) ?? [],
  };
}

/** Kanal yoksa veya kullanıcı üye değilse 0 döner. */
export function snapshotChannelPerms(s: GuildSnapshot, userId: string, channelId: string): number {
  if (!s.members.has(userId)) return 0;
  const ch = s.channels.get(channelId);
  if (!ch) return 0;
  return computeChannelPermissions(snapshotContext(s, userId), ch.overwrites);
}

export function snapshotBase(s: GuildSnapshot, userId: string): number {
  if (!s.members.has(userId)) return 0;
  return computeBasePermissions(snapshotContext(s, userId));
}
