import type { ChannelDTO, MessageDTO, PresenceStatus, SoundDTO, UserDTO } from "@yanki/shared";
import type { Env } from "../env";
import { signedFileUrl } from "./files";
import type { ChannelRow } from "./perms";

export interface UserRow {
  id: string;
  username: string;
  display_name: string;
  avatar_key: string | null;
  bio: string;
  status: PresenceStatus;
}

export async function userDto(env: Env, origin: string, u: UserRow): Promise<UserDTO> {
  return {
    id: u.id,
    username: u.username,
    displayName: u.display_name,
    avatarUrl: u.avatar_key ? await signedFileUrl(env, origin, u.avatar_key) : null,
    bio: u.bio,
    status: u.status,
  };
}

export function channelDto(c: ChannelRow): Omit<ChannelDTO, "myPermissions"> {
  return {
    id: c.id,
    guildId: c.guild_id,
    type: c.type,
    name: c.name,
    parentId: c.parent_id,
    position: c.position,
    isPrivate: c.is_private === 1,
  };
}

export interface MessageRow {
  id: string;
  channel_id: string;
  author_id: string;
  content: string;
  reply_to_id: string | null;
  created_at: number;
  edited_at: number | null;
  username: string;
  display_name: string;
  avatar_key: string | null;
}

export async function messageDto(env: Env, origin: string, m: MessageRow): Promise<MessageDTO> {
  return {
    id: m.id,
    channelId: m.channel_id,
    author: {
      id: m.author_id,
      username: m.username,
      displayName: m.display_name,
      avatarUrl: m.avatar_key ? await signedFileUrl(env, origin, m.avatar_key) : null,
    },
    content: m.content,
    replyToId: m.reply_to_id,
    createdAt: m.created_at,
    editedAt: m.edited_at,
    attachments: [],
    reactions: [],
  };
}

export interface SoundRow {
  id: string;
  guild_id: string | null;
  owner_id: string;
  name: string;
  emoji: string;
  category: string;
  volume: number;
  r2_key: string;
  mime: string;
  size: number;
  sha256: string;
  created_at: number;
}

export async function soundDto(env: Env, origin: string, s: SoundRow): Promise<SoundDTO> {
  return {
    id: s.id,
    guildId: s.guild_id,
    ownerId: s.owner_id,
    name: s.name,
    emoji: s.emoji,
    category: s.category,
    volume: s.volume,
    mime: s.mime,
    size: s.size,
    sha256: s.sha256,
    url: await signedFileUrl(env, origin, s.r2_key),
    createdAt: s.created_at,
  };
}
