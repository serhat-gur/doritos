import {
  computeBasePermissions,
  computeChannelPermissions,
  hasFlag,
  type ChannelOverwrite,
  type PermissionContext,
} from "@yanki/shared";
import { forbidden, notFound } from "./errors";

export interface GuildRow {
  id: string;
  name: string;
  icon_key: string | null;
  owner_id: string;
  afk_channel_id: string | null;
  afk_sound_id: string | null;
}

export interface ChannelRow {
  id: string;
  guild_id: string;
  type: "text" | "voice" | "category";
  name: string;
  parent_id: string | null;
  position: number;
  is_private: number;
}

export interface MemberPermissionData {
  guild: GuildRow;
  ctx: PermissionContext;
}

/**
 * Bir kullanıcının bir sunucudaki yetki bağlamını tek bir D1 batch'i ile yükler
 * (sunucu + roller + üyenin rolleri + üyelik). Üye değilse null döner.
 */
export async function loadMemberContext(
  db: D1Database,
  guildId: string,
  userId: string,
): Promise<MemberPermissionData | null> {
  const [guildRes, rolesRes, memberRes, memberRolesRes] = await db.batch([
    db.prepare("SELECT id, name, icon_key, owner_id, afk_channel_id, afk_sound_id FROM guilds WHERE id = ?").bind(guildId),
    db.prepare("SELECT id, permissions, position FROM roles WHERE guild_id = ?").bind(guildId),
    db.prepare("SELECT 1 AS ok FROM guild_members WHERE guild_id = ? AND user_id = ?").bind(guildId, userId),
    db.prepare("SELECT role_id FROM member_roles WHERE guild_id = ? AND user_id = ?").bind(guildId, userId),
  ]);
  const guild = guildRes!.results[0] as GuildRow | undefined;
  if (!guild) return null;
  if (memberRes!.results.length === 0) return null;
  return {
    guild,
    ctx: {
      isOwner: guild.owner_id === userId,
      userId,
      everyoneRoleId: guild.id,
      roles: (rolesRes!.results as { id: string; permissions: number; position: number }[]).map((r) => ({
        id: r.id,
        permissions: r.permissions,
        position: r.position,
      })),
      memberRoleIds: (memberRolesRes!.results as { role_id: string }[]).map((r) => r.role_id),
    },
  };
}

export async function loadOverwrites(db: D1Database, channelId: string): Promise<ChannelOverwrite[]> {
  const { results } = await db
    .prepare("SELECT target_type, target_id, allow, deny FROM channel_overwrites WHERE channel_id = ?")
    .bind(channelId)
    .all<{ target_type: "role" | "member"; target_id: string; allow: number; deny: number }>();
  return results.map((r) => ({ targetType: r.target_type, targetId: r.target_id, allow: r.allow, deny: r.deny }));
}

/** Üyeliği zorunlu kılar; sunucu düzeyinde izin istenirse kontrol eder. */
export async function requireGuildPermission(
  db: D1Database,
  guildId: string,
  userId: string,
  flag?: number,
): Promise<MemberPermissionData & { perms: number }> {
  const data = await loadMemberContext(db, guildId, userId);
  if (!data) throw notFound("Sunucu bulunamadı");
  const perms = computeBasePermissions(data.ctx);
  if (flag !== undefined && !hasFlag(perms, flag)) throw forbidden();
  return { ...data, perms };
}

/** Kanalı yükler, üyeliği ve kanal düzeyi izni kontrol eder. */
export async function requireChannelPermission(
  db: D1Database,
  channelId: string,
  userId: string,
  flag: number,
): Promise<{ channel: ChannelRow; perms: number; member: MemberPermissionData }> {
  const channel = await db
    .prepare("SELECT id, guild_id, type, name, parent_id, position, is_private FROM channels WHERE id = ?")
    .bind(channelId)
    .first<ChannelRow>();
  if (!channel) throw notFound("Kanal bulunamadı");
  const member = await loadMemberContext(db, channel.guild_id, userId);
  if (!member) throw notFound("Kanal bulunamadı");
  const perms = computeChannelPermissions(member.ctx, await loadOverwrites(db, channel.id));
  // Görünmeyen kanalın varlığını sızdırma
  if (perms === 0) throw notFound("Kanal bulunamadı");
  if (!hasFlag(perms, flag)) throw forbidden();
  return { channel, perms, member };
}
