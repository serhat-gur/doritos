import { LIMITS, SendMessageInput, sniffImageMime, type AttachmentDTO, type MessageDTO, type ReactionDTO } from "@yanki/shared";
import type { Context } from "hono";
import type { AppBindings, Env } from "../env";
import { deleteBlob, putBlob } from "./blobs";
import { messageDto, type MessageRow } from "./dto";
import { badRequest, HttpError, parseJson, parseWith } from "./errors";
import { signedFileUrl } from "./files";
import { newId } from "./ids";

/** Sunucu kanalı mesajları ve DM mesajları aynı biçimde iki tabloda tutulur. */
export type MessageTable = "messages" | "dm_messages";

export const selectMessage = (table: MessageTable) => `SELECT m.id, m.channel_id, m.author_id, m.content, m.reply_to_id, m.created_at, m.edited_at,
        u.username, u.display_name, u.avatar_key
   FROM ${table} m JOIN users u ON u.id = m.author_id`;

/** Mesaj satırlarına ekleri ve tepkileri iliştirerek DTO üretir (tek batch). */
export async function hydrateMessages(env: Env, origin: string, rows: MessageRow[]): Promise<MessageDTO[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const ph = ids.map(() => "?").join(",");
  const [att, reac] = await env.DB.batch([
    env.DB.prepare(`SELECT id, message_id, blob_key, filename, mime, size, is_image FROM attachments WHERE message_id IN (${ph}) ORDER BY id`).bind(...ids),
    env.DB.prepare(`SELECT message_id, user_id, emoji FROM reactions WHERE message_id IN (${ph}) ORDER BY created_at`).bind(...ids),
  ]);
  const attBy = new Map<string, AttachmentDTO[]>();
  for (const a of att!.results as { id: string; message_id: string; blob_key: string; filename: string; mime: string; size: number; is_image: number }[]) {
    const list = attBy.get(a.message_id) ?? [];
    list.push({ id: a.id, filename: a.filename, mime: a.mime, size: a.size, isImage: a.is_image === 1, url: await signedFileUrl(env, origin, a.blob_key) });
    attBy.set(a.message_id, list);
  }
  const reacBy = groupReactions(reac!.results as { message_id: string; user_id: string; emoji: string }[]);
  return Promise.all(
    rows.map(async (r) => {
      const dto = await messageDto(env, origin, r);
      dto.attachments = attBy.get(r.id) ?? [];
      dto.reactions = reacBy.get(r.id) ?? [];
      return dto;
    }),
  );
}

export function groupReactions(rows: { message_id: string; user_id: string; emoji: string }[]): Map<string, ReactionDTO[]> {
  const out = new Map<string, ReactionDTO[]>();
  for (const r of rows) {
    const list = out.get(r.message_id) ?? [];
    let e = list.find((x) => x.emoji === r.emoji);
    if (!e) list.push((e = { emoji: r.emoji, userIds: [] }));
    e.userIds.push(r.user_id);
    out.set(r.message_id, list);
  }
  return out;
}

export async function loadReactions(env: Env, messageId: string): Promise<ReactionDTO[]> {
  const { results } = await env.DB.prepare("SELECT message_id, user_id, emoji FROM reactions WHERE message_id = ? ORDER BY created_at")
    .bind(messageId)
    .all<{ message_id: string; user_id: string; emoji: string }>();
  return groupReactions(results).get(messageId) ?? [];
}

export interface ParsedSend {
  content: string;
  replyToId: string | null;
  nonce?: string;
  files: File[];
}

/** JSON veya multipart (content + files) mesaj gövdesini ayrıştırır ve doğrular. */
export async function parseSendBody(c: Context<AppBindings>): Promise<ParsedSend> {
  const ct = c.req.header("Content-Type") ?? "";
  if (ct.startsWith("multipart/form-data")) {
    const len = Number(c.req.header("Content-Length") ?? "0");
    if (len > LIMITS.ATTACHMENT_MAX_BYTES * LIMITS.ATTACHMENTS_PER_MESSAGE + 64 * 1024) throw new HttpError(413, "too_large", "Dosyalar çok büyük");
    const form = await c.req.formData();
    const body = parseWith(SendMessageInput, {
      content: form.get("content") ?? "",
      replyToId: (form.get("replyToId") as string | null) || null,
      nonce: (form.get("nonce") as string | null) ?? undefined,
    });
    const files = form.getAll("files").filter((f): f is File => typeof f !== "string" && f.size > 0);
    if (files.length > LIMITS.ATTACHMENTS_PER_MESSAGE) throw badRequest(`En fazla ${LIMITS.ATTACHMENTS_PER_MESSAGE} dosya`);
    for (const f of files) {
      if (f.size > LIMITS.ATTACHMENT_MAX_BYTES) throw new HttpError(413, "too_large", `${f.name}: en fazla ${LIMITS.ATTACHMENT_MAX_BYTES / 1024 / 1024} MB`);
    }
    if (!body.content && files.length === 0) throw badRequest("Mesaj boş olamaz");
    return { content: body.content, replyToId: body.replyToId ?? null, nonce: body.nonce, files };
  }
  const body = await parseJson(c, SendMessageInput);
  if (!body.content) throw badRequest("Mesaj boş olamaz");
  return { content: body.content, replyToId: body.replyToId ?? null, nonce: body.nonce, files: [] };
}

function safeFilename(name: string): string {
  const clean = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").trim().slice(0, 120);
  return clean || "dosya";
}

/**
 * Mesajı ve eklerini kaydeder. Ekler önce depolanır; mesaj yazılamazsa
 * yüklenen dosyalar geri silinir.
 */
export async function createMessage(
  env: Env,
  origin: string,
  table: MessageTable,
  opts: { channelId: string; authorId: string; body: ParsedSend },
): Promise<MessageDTO> {
  const { channelId, authorId, body } = opts;
  if (body.replyToId) {
    const ref = await env.DB.prepare(`SELECT 1 FROM ${table} WHERE id = ? AND channel_id = ?`).bind(body.replyToId, channelId).first();
    if (!ref) throw badRequest("Yanıtlanan mesaj bu kanalda değil");
  }
  const id = newId();
  const now = Date.now();
  const stored: { key: string; stmt: D1PreparedStatement }[] = [];
  try {
    for (const f of body.files) {
      const bytes = new Uint8Array(await f.arrayBuffer());
      const image = sniffImageMime(bytes);
      // Resim değilse tarayıcı içinde yorumlanmasın diye her zaman indirilebilir ikili veri
      const mime = image ?? "application/octet-stream";
      const attId = newId();
      const { key } = await putBlob(env, { kind: "attachment", id: attId, ownerId: authorId, bytes, mime, userQuota: LIMITS.ATTACHMENT_USER_QUOTA_BYTES });
      stored.push({
        key,
        stmt: env.DB.prepare(
          "INSERT INTO attachments (id, message_id, uploader_id, blob_key, filename, mime, size, is_image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        ).bind(attId, id, authorId, key, safeFilename(f.name), mime, bytes.length, image ? 1 : 0, now),
      });
    }
    const stmts = [
      env.DB.prepare(`INSERT INTO ${table} (id, channel_id, author_id, content, reply_to_id, created_at) VALUES (?, ?, ?, ?, ?, ?)`).bind(
        id,
        channelId,
        authorId,
        body.content,
        body.replyToId,
        now,
      ),
      ...stored.map((s) => s.stmt),
    ];
    if (table === "dm_messages") stmts.push(env.DB.prepare("UPDATE dm_channels SET last_message_at = ? WHERE id = ?").bind(now, channelId));
    await env.DB.batch(stmts);
  } catch (err) {
    for (const s of stored) await deleteBlob(env, s.key).catch(() => {});
    throw err;
  }
  const row = await env.DB.prepare(`${selectMessage(table)} WHERE m.id = ?`).bind(id).first<MessageRow>();
  const [dto] = await hydrateMessages(env, origin, [row!]);
  if (body.nonce) dto!.nonce = body.nonce;
  return dto!;
}

/**
 * Mesajı KALICI olarak siler: satır, ekler (depodan dosyalarıyla), tepkiler ve
 * arama dizini kaydı (FTS tetikleyicisi). Geriye hiçbir iz bırakılmaz; bu
 * mesaja verilmiş yanıtlarda alıntı kısmı görünmez olur.
 */
export async function hardDeleteMessage(env: Env, table: MessageTable, messageId: string): Promise<void> {
  const { results } = await env.DB.prepare("SELECT blob_key FROM attachments WHERE message_id = ?").bind(messageId).all<{ blob_key: string }>();
  await env.DB.batch([
    env.DB.prepare("DELETE FROM attachments WHERE message_id = ?").bind(messageId),
    env.DB.prepare("DELETE FROM reactions WHERE message_id = ?").bind(messageId),
    env.DB.prepare(`DELETE FROM ${table} WHERE id = ?`).bind(messageId),
  ]);
  for (const r of results) await deleteBlob(env, r.blob_key).catch(() => {});
}
