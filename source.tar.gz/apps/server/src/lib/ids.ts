// Crockford Base32 ULID: 10 karakter zaman (ms) + 16 karakter rastgele.
// Sözlük sırası zaman sırasıyla aynıdır; mesaj sayfalaması bunu kullanır.
const ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

let lastTime = 0;
let lastRandom: number[] = [];

export function newId(now = Date.now()): string {
  let random: number[];
  if (now === lastTime) {
    // Aynı milisaniyede monotonluk: rastgele kısmı 1 artır.
    random = lastRandom.slice();
    for (let i = random.length - 1; i >= 0; i--) {
      if (random[i]! < 31) {
        random[i]!++;
        break;
      }
      random[i] = 0;
    }
  } else {
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    random = Array.from(bytes, (b) => b & 31);
  }
  lastTime = now;
  lastRandom = random;

  let time = "";
  let t = now;
  for (let i = 0; i < 10; i++) {
    time = ALPHABET[t % 32] + time;
    t = Math.floor(t / 32);
  }
  return time + random.map((r) => ALPHABET[r]).join("");
}

export function randomCode(length = 10): string {
  const bytes = crypto.getRandomValues(new Uint8Array(length));
  // Karışabilecek karakterleri çıkaran alfabe
  const alpha = "abcdefghjkmnpqrstuvwxyz23456789";
  return Array.from(bytes, (b) => alpha[b % alpha.length]).join("");
}
