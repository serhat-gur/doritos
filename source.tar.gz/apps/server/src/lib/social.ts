import type { DmChannelDTO, FriendDTO, FriendState } from "@yanki/shared";
import type { Env } from "../env";
import { userDto, type UserRow } from "./dto";
import { forbidden, notFound } from "./errors";

/** İki kullanıcıdan biri diğerini engellediyse true. */
export async function isBlockedBetween(env: Env, a: string, b: string): Promise<boolean> {
  const r = await env.DB.prepare(
    "SELECT 1 FROM friendships WHERE status = 'blocked' AND ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?))",
  )
    .bind(a, b, b, a)
    .first();
  return !!r;
}

/** `me` açısından `other` ile ilişki durumu. */
export async function relation(env: Env, me: string, other: string): Promise<FriendState | null> {
  const { results } = await env.DB.prepare(
    "SELECT user_id, friend_id, status FROM friendships WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)",
  )
    .bind(me, other, other, me)
    .all<{ user_id: string; friend_id: string; status: string }>();
  const mine = results.find((r) => r.user_id === me);
  const theirs = results.find((r) => r.user_id === other);
  if (mine?.status === "blocked") return "blocked";
  if (mine?.status === "accepted") return "friend";
  if (mine?.status === "pending") return "outgoing";
  if (theirs?.status === "pending") return "incoming";
  return null;
}

export async function friendDto(env: Env, origin: string, me: string, otherId: string): Promise<FriendDTO | null> {
  const state = await relation(env, me, otherId);
  if (!state) return null;
  const u = await env.DB.prepare("SELECT id, username, display_name, avatar_key, bio, status FROM users WHERE id = ?").bind(otherId).first<UserRow>();
  if (!u) return null;
  const user = await userDto(env, origin, u);
  if (user.status === "invisible") user.status = "online";
  return { user, state };
}

export interface DmContext {
  id: string;
  type: "dm" | "group";
  memberIds: string[];
}

/** DM kanalının üyesi değilse 404 (varlığı sızdırma). */
export async function dmContext(env: Env, channelId: string, userId: string): Promise<DmContext> {
  const [ch, members] = await env.DB.batch([
    env.DB.prepare("SELECT id, type FROM dm_channels WHERE id = ?").bind(channelId),
    env.DB.prepare("SELECT user_id FROM dm_members WHERE channel_id = ?").bind(channelId),
  ]);
  const row = ch!.results[0] as { id: string; type: "dm" | "group" } | undefined;
  const memberIds = (members!.results as { user_id: string }[]).map((m) => m.user_id);
  if (!row || !memberIds.includes(userId)) throw notFound("Sohbet bulunamadı");
  return { id: row.id, type: row.type, memberIds };
}

/** Birebir DM'de karşı taraf engellediyse/engellendiyse yazma yasak. */
export async function assertCanWriteDm(env: Env, ctx: DmContext, userId: string): Promise<void> {
  if (ctx.type !== "dm") return;
  const other = ctx.memberIds.find((m) => m !== userId);
  if (other && (await isBlockedBetween(env, userId, other))) throw forbidden("Bu kişiyle mesajlaşamazsın (engel)");
}

export async function dmChannelDto(env: Env, origin: string, channelId: string): Promise<DmChannelDTO> {
  const [ch, members] = await env.DB.batch([
    env.DB.prepare("SELECT id, type, name, owner_id, last_message_at FROM dm_channels WHERE id = ?").bind(channelId),
    env.DB.prepare(
      "SELECT u.id, u.username, u.display_name, u.avatar_key, u.bio, u.status FROM dm_members m JOIN users u ON u.id = m.user_id WHERE m.channel_id = ?",
    ).bind(channelId),
  ]);
  const row = ch!.results[0] as { id: string; type: "dm" | "group"; name: string | null; owner_id: string | null; last_message_at: number | null };
  return {
    id: row.id,
    type: row.type,
    name: row.name,
    ownerId: row.owner_id,
    lastMessageAt: row.last_message_at,
    members: await Promise.all(
      (members!.results as UserRow[]).map(async (u) => {
        const d = await userDto(env, origin, u);
        if (d.status === "invisible") d.status = "online";
        return d;
      }),
    ),
  };
}
