import type { Env } from "../env";
import { HttpError } from "./errors";

export function appSecret(env: Env): string {
  const s = env.APP_SECRET;
  if (!s || s.length < 32) {
    throw new HttpError(500, "misconfigured", "APP_SECRET tanımlı değil veya 32 karakterden kısa");
  }
  return s;
}

export function pbkdf2Iterations(env: Env): number {
  const n = Number(env.PBKDF2_ITERATIONS ?? "30000");
  // workerd PBKDF2 için 100000 üst sınırı uygular
  return Number.isInteger(n) && n >= 10_000 && n <= 100_000 ? n : 30_000;
}
