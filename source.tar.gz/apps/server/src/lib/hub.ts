import type { ServerEvent } from "@yanki/shared";
import type { Env } from "../env";
import { log } from "./log";

export function hubStub(env: Env, guildId: string) {
  return env.GUILD_HUB.get(env.GUILD_HUB.idFromName(guildId));
}

/**
 * Kalıcı bir değişiklikten sonra olayı sunucunun DO'suna iletir. Yayın
 * başarısız olsa bile veri D1'e yazılmıştır; istemciler yeniden bağlanınca
 * REST ile güncel durumu çeker. Bu yüzden hata isteği düşürmez.
 */
export async function publish(env: Env, guildId: string, event: ServerEvent, channelId?: string): Promise<void> {
  try {
    await hubStub(env, guildId).broadcast(guildId, event, channelId);
  } catch (err) {
    log("warn", "hub.publish_failed", { guildId, event: event.t, err: String(err) });
  }
}
