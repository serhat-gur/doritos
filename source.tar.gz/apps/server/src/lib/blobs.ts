import { LIMITS } from "@yanki/shared";
import type { Env } from "../env";
import { sha256Hex } from "./crypto";
import { HttpError } from "./errors";

export type BlobKind = "sound" | "attachment" | "avatar" | "icon";
const SHARDS = 16;

function shardOf(key: string): number {
  const m = /^s(\d{2})\//.exec(key);
  return m ? Number(m[1]) % SHARDS : 0;
}

function store(env: Env, key: string) {
  return env.BLOBS.get(env.BLOBS.idFromName(`shard-${shardOf(key)}`));
}

/**
 * Dosyayı kaydeder: önce genel tavan + kullanıcı kotası (D1 kaydından), sonra
 * BlobStore'a yazar, en son D1'e kaydeder. Anahtar içerik hash'ini içerir.
 */
export async function putBlob(
  env: Env,
  opts: { kind: BlobKind; id: string; ownerId: string; bytes: Uint8Array; mime: string; userQuota?: number },
): Promise<{ key: string; sha256: string }> {
  const [total, mine] = await env.DB.batch([
    env.DB.prepare("SELECT COALESCE(SUM(size), 0) AS t FROM blobs"),
    env.DB.prepare("SELECT COALESCE(SUM(size), 0) AS t FROM blobs WHERE owner_id = ? AND kind = ?").bind(opts.ownerId, opts.kind),
  ]);
  const totalBytes = (total!.results[0] as { t: number }).t;
  const myBytes = (mine!.results[0] as { t: number }).t;
  if (totalBytes + opts.bytes.length > LIMITS.STORAGE_GLOBAL_CAP_BYTES) {
    throw new HttpError(507, "storage_full", "Sunucunun ücretsiz depolama alanı doldu; eski dosyaları silin");
  }
  if (opts.userQuota !== undefined && myBytes + opts.bytes.length > opts.userQuota) {
    throw new HttpError(413, "quota", "Depolama kotan doldu");
  }
  const sha256 = await sha256Hex(opts.bytes);
  const shard = String(parseInt(sha256.slice(0, 4), 16) % SHARDS).padStart(2, "0");
  const key = `s${shard}/${opts.kind}/${opts.id}/${sha256}`;
  await store(env, key).put(key, opts.bytes.slice().buffer, opts.mime);
  try {
    await env.DB.prepare("INSERT INTO blobs (key, owner_id, kind, size, mime, created_at) VALUES (?, ?, ?, ?, ?, ?)")
      .bind(key, opts.ownerId, opts.kind, opts.bytes.length, opts.mime, Date.now())
      .run();
  } catch (err) {
    await store(env, key).delete(key);
    throw err;
  }
  return { key, sha256 };
}

export async function getBlob(env: Env, key: string) {
  return store(env, key).get(key);
}

export async function deleteBlob(env: Env, key: string): Promise<void> {
  await store(env, key).delete(key);
  await env.DB.prepare("DELETE FROM blobs WHERE key = ?").bind(key).run();
}

/** Ses deposu kullanımı (eski `sounds.size` + yeni kayıtlar aynı tabloda). */
export async function storageUsage(env: Env): Promise<{ totalBytes: number; capBytes: number }> {
  const r = await env.DB.prepare("SELECT COALESCE(SUM(size), 0) AS t FROM blobs").first<{ t: number }>();
  return { totalBytes: r?.t ?? 0, capBytes: LIMITS.STORAGE_GLOBAL_CAP_BYTES };
}
