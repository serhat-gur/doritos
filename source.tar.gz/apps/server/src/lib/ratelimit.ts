import type { Env } from "../env";
import { tooMany } from "./errors";

export interface RateRule {
  limit: number;
  windowMs: number;
}

export const RATE_RULES = {
  authByIp: { limit: 10, windowMs: 60_000 },
  messageByUser: { limit: 20, windowMs: 10_000 },
  uploadByUser: { limit: 30, windowMs: 60 * 60_000 },
  writeByUser: { limit: 60, windowMs: 60_000 },
} satisfies Record<string, RateRule>;

/**
 * Anahtar başına bir RateLimiter Durable Object'i (sabit pencere sayacı).
 * Her kontrol bir DO isteği maliyetindedir; sadece yazma/yetki açısından
 * hassas uç noktalarda kullanılır.
 */
export async function enforceRateLimit(env: Env, key: string, rule: RateRule): Promise<void> {
  const stub = env.RATE_LIMITER.get(env.RATE_LIMITER.idFromName(key));
  const res = await stub.hit(rule.limit, rule.windowMs);
  if (!res.ok) throw tooMany(res.retryAfterMs);
}
