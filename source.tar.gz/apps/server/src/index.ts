import { Hono } from "hono";
import { cors } from "hono/cors";
import type { AppBindings } from "./env";
import { verifyToken } from "./lib/crypto";
import { HttpError } from "./lib/errors";
import { verifyFileSignature } from "./lib/files";
import { hubStub } from "./lib/hub";
import { log } from "./lib/log";
import { appSecret } from "./lib/secrets";
import { authRoutes, meRoutes } from "./routes/auth";
import { channelRoutes, guildRoutes, inviteRoutes } from "./routes/guilds";
import { messageRoutes } from "./routes/messages";
import { soundRoutes } from "./routes/sounds";
import { voiceRoutes } from "./routes/voice";
import { socialRoutes } from "./routes/social";
import { getBlob } from "./lib/blobs";
import { userHub } from "./lib/userhub";

export { GuildHub } from "./do/GuildHub";
export { RateLimiter } from "./do/RateLimiter";
export { UserHub } from "./do/UserHub";
export { BlobStore } from "./do/BlobStore";

const app = new Hono<AppBindings>();

// Masaüstü istemci Bearer token kullanır (çerez yok), bu yüzden CORS'un açık
// olması CSRF riski doğurmaz.
app.use("/api/*", cors({ origin: "*", allowHeaders: ["Authorization", "Content-Type"], maxAge: 86400 }));

app.onError((err, c) => {
  if (err instanceof HttpError) {
    return c.json({ error: { code: err.code, message: err.message, details: err.details } }, err.status);
  }
  log("error", "unhandled", { path: c.req.path, err: String(err), stack: (err as Error).stack });
  return c.json({ error: { code: "internal", message: "Sunucu hatası" } }, 500);
});

app.notFound((c) => c.json({ error: { code: "not_found", message: "Uç nokta bulunamadı" } }, 404));

app.get("/api/health", (c) => c.json({ ok: true, time: Date.now() }));

// WebSocket gateway: bilet Worker'da doğrulanır, sonra sunucunun DO'suna iletilir.
// Tarayıcı WebSocket API'si özel başlık gönderemediği için kısa ömürlü bilet kullanılır.
app.get("/api/guilds/:gid/gateway", async (c) => {
  if (c.req.header("Upgrade") !== "websocket") return c.text("WebSocket bekleniyor", 426);
  const gid = c.req.param("gid");
  const ticket = c.req.query("ticket");
  const payload = ticket ? await verifyToken<{ uid: string; gid: string; exp: number }>(appSecret(c.env), ticket) : null;
  if (!payload || payload.gid !== gid) return c.text("Geçersiz bilet", 401);
  const member = await c.env.DB.prepare("SELECT 1 FROM guild_members WHERE guild_id = ? AND user_id = ?").bind(gid, payload.uid).first();
  if (!member) return c.text("Üye değil", 403);
  const headers = new Headers(c.req.raw.headers);
  headers.set("X-Yanki-User", payload.uid);
  headers.set("X-Yanki-Guild", gid);
  headers.set("X-Yanki-Origin", new URL(c.req.url).origin);
  return hubStub(c.env, gid).fetch(new Request(c.req.raw.url, { headers }));
});

// Kişisel gateway (arkadaşlar, DM). Bilet POST /api/gateway-ticket ile alınır.
app.get("/api/gateway", async (c) => {
  if (c.req.header("Upgrade") !== "websocket") return c.text("WebSocket bekleniyor", 426);
  const ticket = c.req.query("ticket");
  const payload = ticket ? await verifyToken<{ uid: string; gid: string; exp: number }>(appSecret(c.env), ticket) : null;
  if (!payload || payload.gid !== "@me") return c.text("Geçersiz bilet", 401);
  const headers = new Headers(c.req.raw.headers);
  headers.set("X-Yanki-User", payload.uid);
  return userHub(c.env, payload.uid).fetch(new Request(c.req.raw.url, { headers }));
});

app.route("/api/auth", authRoutes);
app.route("/api/me", meRoutes);
app.route("/api/guilds", guildRoutes);
app.route("/api/channels", channelRoutes);
app.route("/api/invites", inviteRoutes);
app.route("/api/sounds", soundRoutes);
app.route("/api/voice", voiceRoutes);
app.route("/api", messageRoutes);
app.route("/api", socialRoutes);

// İmzalı dosya indirme (R2)
app.get("/files/*", async (c) => {
  const key = decodeURI(c.req.path.slice("/files/".length));
  if (!key || key.includes("..")) return c.text("Bulunamadı", 404);
  if (!(await verifyFileSignature(c.env, key, c.req.query("exp"), c.req.query("sig")))) {
    return c.text("İmza geçersiz veya süresi dolmuş", 403);
  }
  const obj = await getBlob(c.env, key);
  if (!obj) return c.text("Bulunamadı", 404);
  const headers = new Headers();
  const isImageOrAudio = /^(image\/(png|jpeg|gif|webp)|audio\/(mpeg|wav|ogg))$/.test(obj.mime);
  headers.set("Content-Type", isImageOrAudio ? obj.mime : "application/octet-stream");
  // Resim/ses dışındaki her şey indirilir, tarayıcıda yorumlanmaz
  if (!isImageOrAudio) headers.set("Content-Disposition", "attachment");
  headers.set("Content-Length", String(obj.size));
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("Content-Security-Policy", "default-src 'none'; sandbox");
  headers.set("Access-Control-Allow-Origin", "*");
  // Anahtar içerik hash'ini içerir → içerik asla değişmez
  headers.set("Cache-Control", "private, max-age=31536000, immutable");
  return new Response(obj.data, { headers });
});

export default app;
