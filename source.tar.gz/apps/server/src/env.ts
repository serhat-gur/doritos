import type { GuildHub } from "./do/GuildHub";
import type { BlobStore } from "./do/BlobStore";
import type { RateLimiter } from "./do/RateLimiter";
import type { UserHub } from "./do/UserHub";

export interface Env {
  DB: D1Database;
  GUILD_HUB: DurableObjectNamespace<GuildHub>;
  RATE_LIMITER: DurableObjectNamespace<RateLimiter>;
  USER_HUB: DurableObjectNamespace<UserHub>;
  BLOBS: DurableObjectNamespace<BlobStore>;
  APP_SECRET?: string;
  PBKDF2_ITERATIONS?: string;
  REGISTRATION_MODE?: "open" | "code" | "closed";
  REGISTRATION_CODE?: string;
  TURN_KEY_ID?: string;
  TURN_KEY_API_TOKEN?: string;
}

export interface AuthUser {
  id: string;
  username: string;
  displayName: string;
  sessionId: string;
}

export type AppBindings = { Bindings: Env; Variables: { user: AuthUser } };
