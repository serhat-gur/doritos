import { DurableObject } from "cloudflare:workers";
import type { Env } from "../env";

/**
 * Basit sabit-pencere sayacı. Durum bellekte tutulur; DO tahliye edilirse
 * sayaç sıfırlanır (kötüye kullanımı engellemek için yeterli, faturalama için değil).
 */
export class RateLimiter extends DurableObject<Env> {
  private windowStart = 0;
  private count = 0;

  async hit(limit: number, windowMs: number): Promise<{ ok: boolean; retryAfterMs: number }> {
    const now = Date.now();
    if (now - this.windowStart >= windowMs) {
      this.windowStart = now;
      this.count = 0;
    }
    if (this.count >= limit) {
      return { ok: false, retryAfterMs: this.windowStart + windowMs - now };
    }
    this.count++;
    return { ok: true, retryAfterMs: 0 };
  }
}
