import { DurableObject } from "cloudflare:workers";
import { ClientEvent, type PresenceStatus, type ServerEvent } from "@yanki/shared";
import type { Env } from "../env";
import { log } from "../lib/log";

interface SocketState {
  userId: string;
  status: PresenceStatus;
}

/**
 * UserHub — kullanıcı başına bir Durable Object (kişisel gateway).
 *
 * Arkadaşlık olayları, DM mesajları/yazıyor göstergesi ve arkadaşların
 * çevrimiçi durumu buradan gelir. Sunucu (guild) olaylarından ayrıdır;
 * böylece DM'ler hiçbir sunucuya bağlı değildir. Hibernation kullanır.
 */
export class UserHub extends DurableObject<Env> {
  override async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") return new Response("WebSocket bekleniyor", { status: 426 });
    const userId = request.headers.get("X-Yanki-User");
    if (!userId) return new Response("Yetkisiz", { status: 401 });
    const row = await this.env.DB.prepare("SELECT status FROM users WHERE id = ?").bind(userId).first<{ status: PresenceStatus }>();
    const status = row?.status ?? "online";
    const wasOnline = this.ctx.getWebSockets().length > 0;

    const pair = new WebSocketPair();
    const [client, server] = [pair[0], pair[1]];
    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ userId, status } satisfies SocketState);

    const friends = await this.friendIds(userId);
    const online: { userId: string; status: PresenceStatus }[] = [];
    await Promise.all(
      friends.map(async (f) => {
        try {
          const s = await this.env.USER_HUB.get(this.env.USER_HUB.idFromName(f)).presence();
          if (s !== "offline") online.push({ userId: f, status: s });
        } catch {
          /* yoksay */
        }
      }),
    );
    this.sendTo(server, { t: "ready", userId, serverTime: Date.now(), online, voice: [] });
    if (!wasOnline && status !== "invisible") await this.announce(userId, friends, status);
    return new Response(null, { status: 101, webSocket: client });
  }

  override async webSocketMessage(ws: WebSocket, raw: string | ArrayBuffer): Promise<void> {
    const s = ws.deserializeAttachment() as SocketState | null;
    if (!s || typeof raw !== "string" || raw.length > 8_000) return;
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return;
    }
    const r = ClientEvent.safeParse(parsed);
    if (!r.success) return;
    const ev = r.data;
    if (ev.t === "ping") {
      this.sendTo(ws, { t: "pong", clientTime: ev.clientTime, serverTime: Date.now() });
    } else if (ev.t === "presence.set") {
      for (const w of this.ctx.getWebSockets()) w.serializeAttachment({ ...(w.deserializeAttachment() as SocketState), status: ev.status });
      await this.announce(s.userId, await this.friendIds(s.userId), ev.status === "invisible" ? "offline" : ev.status);
    } else if (ev.t === "dm.typing") {
      const { results } = await this.env.DB.prepare("SELECT user_id FROM dm_members WHERE channel_id = ?").bind(ev.channelId).all<{ user_id: string }>();
      const members = results.map((m) => m.user_id);
      if (!members.includes(s.userId)) return;
      await Promise.all(
        members
          .filter((m) => m !== s.userId)
          .map((m) =>
            this.env.USER_HUB.get(this.env.USER_HUB.idFromName(m))
              .send({ t: "typing", channelId: ev.channelId, userId: s.userId })
              .catch(() => {}),
          ),
      );
    }
  }

  override async webSocketClose(ws: WebSocket, code: number): Promise<void> {
    const s = ws.deserializeAttachment() as SocketState | null;
    try {
      ws.close(code === 1005 ? 1000 : code, "kapandı");
    } catch {
      /* zaten kapalı */
    }
    if (!s) return;
    const remaining = this.ctx.getWebSockets().filter((w) => w !== ws && w.readyState === WebSocket.OPEN);
    if (remaining.length === 0) await this.announce(s.userId, await this.friendIds(s.userId), "offline");
  }

  // ------------------------------------------------------------------ RPC
  async send(event: ServerEvent): Promise<void> {
    const data = JSON.stringify(event);
    for (const ws of this.ctx.getWebSockets()) {
      try {
        ws.send(data);
      } catch {
        /* kapanmış */
      }
    }
  }

  async presence(): Promise<PresenceStatus | "offline"> {
    const sockets = this.ctx.getWebSockets();
    if (sockets.length === 0) return "offline";
    const st = (sockets[0]!.deserializeAttachment() as SocketState | null)?.status ?? "online";
    return st === "invisible" ? "offline" : st;
  }

  // ------------------------------------------------------------------ yardımcılar
  private sendTo(ws: WebSocket, ev: ServerEvent) {
    try {
      ws.send(JSON.stringify(ev));
    } catch {
      /* kapanmış */
    }
  }

  private async friendIds(userId: string): Promise<string[]> {
    const { results } = await this.env.DB.prepare("SELECT friend_id FROM friendships WHERE user_id = ? AND status = 'accepted'").bind(userId).all<{ friend_id: string }>();
    return results.map((r) => r.friend_id);
  }

  private async announce(userId: string, friends: string[], status: PresenceStatus | "offline"): Promise<void> {
    await Promise.all(
      friends.map((f) =>
        this.env.USER_HUB.get(this.env.USER_HUB.idFromName(f))
          .send({ t: "presence", userId, status })
          .catch((err: unknown) => log("warn", "userhub.announce_failed", { err: String(err) })),
      ),
    );
  }
}
