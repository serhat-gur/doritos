import { DurableObject } from "cloudflare:workers";
import type { Env } from "../env";

/** SQLite değer sınırı 2 MB; güvenli pay bırakarak 1 MB'lık parçalar. */
const CHUNK = 1024 * 1024;

/**
 * Ücretsiz dosya deposu.
 *
 * R2 ücretsiz katmanı cömert olsa da hesaba ödeme yöntemi eklemeyi gerektirir
 * ve limit aşılırsa ücretlendirir. Bunun yerine dosyalar, ücretsiz planda
 * kullanılabilen SQLite tabanlı Durable Object depolamasında tutulur:
 * aşım olursa ücret değil hata oluşur. Yük, anahtarın önekiyle 16 parçaya
 * (shard) dağıtılır; her DO'nun boyutu küçük kalır.
 */
export class BlobStore extends DurableObject<Env> {
  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    ctx.storage.sql.exec(`
      CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, size INTEGER NOT NULL, mime TEXT NOT NULL, chunks INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS chunks (key TEXT NOT NULL, idx INTEGER NOT NULL, data BLOB NOT NULL, PRIMARY KEY (key, idx));
    `);
  }

  async put(key: string, data: ArrayBuffer, mime: string): Promise<void> {
    const bytes = new Uint8Array(data);
    const n = Math.max(1, Math.ceil(bytes.length / CHUNK));
    this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec("DELETE FROM chunks WHERE key = ?", key);
      for (let i = 0; i < n; i++) {
        this.ctx.storage.sql.exec("INSERT INTO chunks (key, idx, data) VALUES (?, ?, ?)", key, i, bytes.slice(i * CHUNK, (i + 1) * CHUNK).buffer);
      }
      this.ctx.storage.sql.exec("INSERT OR REPLACE INTO meta (key, size, mime, chunks) VALUES (?, ?, ?, ?)", key, bytes.length, mime, n);
    });
  }

  async get(key: string): Promise<{ data: ArrayBuffer; mime: string; size: number } | null> {
    const meta = this.ctx.storage.sql.exec<{ size: number; mime: string }>("SELECT size, mime FROM meta WHERE key = ?", key).toArray()[0];
    if (!meta) return null;
    const out = new Uint8Array(meta.size);
    let offset = 0;
    for (const row of this.ctx.storage.sql.exec<{ data: ArrayBuffer }>("SELECT data FROM chunks WHERE key = ? ORDER BY idx", key)) {
      const part = new Uint8Array(row.data);
      out.set(part, offset);
      offset += part.length;
    }
    return { data: out.buffer, mime: meta.mime, size: meta.size };
  }

  async delete(key: string): Promise<void> {
    this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec("DELETE FROM chunks WHERE key = ?", key);
      this.ctx.storage.sql.exec("DELETE FROM meta WHERE key = ?", key);
    });
  }
}
