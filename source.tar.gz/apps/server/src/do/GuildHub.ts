import { DurableObject } from "cloudflare:workers";
import {
  ClientEvent,
  CloseCode,
  hasFlag,
  LIMITS,
  Permission,
  type PresenceStatus,
  type ServerEvent,
  type VoiceParticipant,
} from "@yanki/shared";
import type { Env } from "../env";
import { signedFileUrl } from "../lib/files";
import { loadGuildSnapshot, snapshotBase, snapshotChannelPerms, type GuildSnapshot } from "../lib/guild-snapshot";
import { newId } from "../lib/ids";
import { log } from "../lib/log";

/** Her WebSocket'e iliştirilen ve hibernation'dan sağ çıkan durum. */
interface SocketState {
  userId: string;
  guildId: string;
  origin: string;
  status: PresenceStatus;
  voice: VoiceParticipant | null;
  voiceSessionId: string | null;
  lastSoundAt: number;
}

const SNAPSHOT_TTL_MS = 5_000;

/**
 * GuildHub — sunucu (guild) başına bir Durable Object.
 *
 * Sorumluluklar: WebSocket oturumları, presence, yazıyor göstergesi, sesli oda
 * üyeliği, WebRTC sinyal aktarımı, soundboard olayları ve Worker'dan gelen
 * kalıcı olayların (mesaj, kanal değişikliği) yetkiye göre yayını.
 *
 * WebSocket Hibernation API kullanılır: bağlantı açıkken boşta kalan DO bellekten
 * atılabilir ve süre (duration) ücreti işlemez. Bu yüzden tüm bağlantı durumu
 * `serializeAttachment` ile sokete yazılır; bellekteki alanlar yalnızca önbellektir.
 */
export class GuildHub extends DurableObject<Env> {
  private snapshot: GuildSnapshot | null = null;
  /** Oda başına son ses çalma zamanları (kayan pencere rate limit). */
  private roomSoundTimes = new Map<string, number[]>();

  // ------------------------------------------------------------------ bağlantı
  override async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("WebSocket bekleniyor", { status: 426 });
    }
    // Worker bileti doğruladı ve bu başlıkları ekledi; DO dışarıya açık değildir.
    const userId = request.headers.get("X-Yanki-User");
    const guildId = request.headers.get("X-Yanki-Guild");
    const origin = request.headers.get("X-Yanki-Origin") ?? new URL(request.url).origin;
    if (!userId || !guildId) return new Response("Yetkisiz", { status: 401 });

    const status = ((await this.env.DB.prepare("SELECT status FROM users WHERE id = ?").bind(userId).first<{ status: PresenceStatus }>())
      ?.status ?? "online") as PresenceStatus;

    const pair = new WebSocketPair();
    const [client, server] = [pair[0], pair[1]];
    const wasOnline = this.socketsOf(userId).length > 0;
    this.ctx.acceptWebSocket(server, [userId]);
    const state: SocketState = {
      userId,
      guildId,
      origin,
      status,
      voice: null,
      voiceSessionId: null,
      lastSoundAt: 0,
    };
    server.serializeAttachment(state);

    this.sendTo(server, {
      t: "ready",
      userId,
      serverTime: Date.now(),
      online: this.onlineList(),
      voice: this.allVoice(),
    });
    if (!wasOnline && status !== "invisible") {
      this.broadcastAll({ t: "presence", userId, status }, server);
    }
    return new Response(null, { status: 101, webSocket: client });
  }

  override async webSocketMessage(ws: WebSocket, raw: string | ArrayBuffer): Promise<void> {
    const state = this.state(ws);
    if (!state) return;
    if (typeof raw !== "string" || raw.length > 64_000) {
      this.sendTo(ws, { t: "error", code: "bad_message", message: "Geçersiz mesaj" });
      return;
    }
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      this.sendTo(ws, { t: "error", code: "bad_message", message: "Geçersiz JSON" });
      return;
    }
    const r = ClientEvent.safeParse(parsed);
    if (!r.success) {
      this.sendTo(ws, { t: "error", code: "bad_message", message: "Bilinmeyen veya hatalı olay" });
      return;
    }
    try {
      await this.handle(ws, state, r.data);
    } catch (err) {
      log("error", "guildhub.handle_failed", { event: r.data.t, err: String(err) });
      this.sendTo(ws, { t: "error", code: "internal", message: "İşlem başarısız", ref: r.data.t });
    }
  }

  override async webSocketClose(ws: WebSocket, code: number): Promise<void> {
    await this.cleanup(ws);
    try {
      ws.close(code === 1005 ? 1000 : code, "kapandı");
    } catch {
      /* zaten kapalı */
    }
  }

  override async webSocketError(ws: WebSocket): Promise<void> {
    await this.cleanup(ws);
  }

  // ------------------------------------------------------------------ Worker RPC
  /**
   * Worker'dan kalıcı olay yayını. `channelId` verilirse yalnızca o kanalı
   * görebilen (VIEW_CHANNEL) kullanıcılara gönderilir.
   */
  async broadcast(guildId: string, event: ServerEvent, channelId?: string): Promise<number> {
    if (event.t.startsWith("channel.") || event.t === "member.join" || event.t === "guild.update") this.snapshot = null;
    let sent = 0;
    let snap: GuildSnapshot | null = null;
    if (channelId) snap = await this.getSnapshot(guildId);
    for (const ws of this.ctx.getWebSockets()) {
      const s = this.state(ws);
      if (!s) continue;
      if (channelId && snap && !hasFlag(snapshotChannelPerms(snap, s.userId, channelId), Permission.VIEW_CHANNEL)) continue;
      this.sendTo(ws, event);
      sent++;
    }
    return sent;
  }

  /** Rol/izin değişikliklerinden sonra önbelleği düşürür. */
  async invalidate(): Promise<void> {
    this.snapshot = null;
  }

  /** Kick/ban sonrası kullanıcının tüm bağlantılarını kapatır. */
  async disconnectUser(userId: string, reason = "Sunucudan çıkarıldın"): Promise<void> {
    this.snapshot = null;
    for (const ws of this.socketsOf(userId)) {
      await this.cleanup(ws);
      ws.close(CloseCode.FORBIDDEN, reason);
    }
  }

  /** Test ve izleme için: odadaki aktif katılımcılar. */
  async voiceParticipants(): Promise<VoiceParticipant[]> {
    return this.allVoice();
  }

  // ------------------------------------------------------------------ olaylar
  private async handle(ws: WebSocket, s: SocketState, ev: ClientEvent): Promise<void> {
    switch (ev.t) {
      case "ping":
        this.sendTo(ws, { t: "pong", clientTime: ev.clientTime, serverTime: Date.now() });
        return;

      case "presence.set": {
        s.status = ev.status;
        this.save(ws, s);
        await this.env.DB.prepare("UPDATE users SET status = ? WHERE id = ?").bind(ev.status, s.userId).run();
        this.broadcastAll({ t: "presence", userId: s.userId, status: ev.status === "invisible" ? "offline" : ev.status });
        return;
      }

      case "typing": {
        const snap = await this.getSnapshot(s.guildId);
        if (!hasFlag(snapshotChannelPerms(snap, s.userId, ev.channelId), Permission.SEND_MESSAGES)) return;
        for (const other of this.ctx.getWebSockets()) {
          const os = this.state(other);
          if (!os || os.userId === s.userId) continue;
          if (!hasFlag(snapshotChannelPerms(snap, os.userId, ev.channelId), Permission.VIEW_CHANNEL)) continue;
          this.sendTo(other, { t: "typing", channelId: ev.channelId, userId: s.userId });
        }
        return;
      }

      case "voice.join": {
        const snap = await this.getSnapshot(s.guildId, true);
        const ch = snap.channels.get(ev.channelId);
        const perms = snapshotChannelPerms(snap, s.userId, ev.channelId);
        if (!ch || ch.type !== "voice" || !hasFlag(perms, Permission.CONNECT_VOICE)) {
          this.sendTo(ws, { t: "error", code: "forbidden", message: "Bu sesli kanala bağlanamazsın", ref: "voice.join" });
          return;
        }
        // Aynı kullanıcının başka bir bağlantısı seste ise onu çıkar (tek ses oturumu).
        for (const other of this.socketsOf(s.userId)) {
          if (other !== ws && this.state(other)?.voice) await this.leaveVoice(other, this.state(other)!);
        }
        if (s.voice) await this.leaveVoice(ws, s);
        const mod = await this.modState(s.userId);
        s.voice = {
          userId: s.userId,
          channelId: ev.channelId,
          selfMute: false,
          selfDeaf: false,
          // SPEAK izni yoksa veya bir yetkili sunucu tarafında susturduysa
          serverMute: mod.mute || !hasFlag(perms, Permission.SPEAK),
          serverDeaf: mod.deafen,
          speaking: false,
          streaming: false,
          stream: null,
        };
        s.voiceSessionId = newId();
        this.save(ws, s);
        await this.env.DB.prepare(
          "INSERT INTO voice_sessions (id, guild_id, channel_id, user_id, joined_at) VALUES (?, ?, ?, ?, ?)",
        )
          .bind(s.voiceSessionId, s.guildId, ev.channelId, s.userId, Date.now())
          .run();
        await this.broadcastVoice({ t: "voice.update", participant: s.voice }, ev.channelId);
        return;
      }

      case "voice.leave":
        if (s.voice) await this.leaveVoice(ws, s);
        return;

      case "voice.state":
      case "voice.speaking": {
        if (!s.voice) return;
        if (ev.t === "voice.state") {
          s.voice.selfMute = ev.selfMute;
          s.voice.selfDeaf = ev.selfDeaf;
          if (ev.selfMute) s.voice.speaking = false;
        } else {
          const speaking = ev.speaking && !s.voice.selfMute && !s.voice.serverMute;
          if (s.voice.speaking === speaking) return;
          s.voice.speaking = speaking;
        }
        this.save(ws, s);
        await this.broadcastVoice({ t: "voice.update", participant: s.voice }, s.voice.channelId);
        return;
      }

      case "rtc.signal": {
        // Sinyal yalnızca aynı sesli kanaldaki iki kullanıcı arasında iletilir.
        if (!s.voice) return;
        for (const other of this.socketsOf(ev.to)) {
          const os = this.state(other);
          if (os?.voice?.channelId === s.voice.channelId) {
            this.sendTo(other, { t: "rtc.signal", from: s.userId, stream: ev.stream, data: ev.data });
          }
        }
        return;
      }

      case "sound.play":
        await this.playSound(ws, s, ev.soundId);
        return;

      case "screen.start": {
        if (!s.voice) return;
        const snap = await this.getSnapshot(s.guildId);
        if (!hasFlag(snapshotChannelPerms(snap, s.userId, s.voice.channelId), Permission.SCREEN_SHARE)) {
          this.sendTo(ws, { t: "error", code: "forbidden", message: "Bu kanalda ekran paylaşma yetkin yok", ref: "screen.start" });
          return;
        }
        s.voice.streaming = true;
        s.voice.stream = { preset: ev.preset, audio: ev.audio };
        this.save(ws, s);
        await this.broadcastVoice({ t: "voice.update", participant: s.voice }, s.voice.channelId);
        return;
      }

      case "screen.stop": {
        if (!s.voice?.streaming) return;
        s.voice.streaming = false;
        s.voice.stream = null;
        this.save(ws, s);
        await this.broadcastVoice({ t: "voice.update", participant: s.voice }, s.voice.channelId);
        return;
      }

      case "voice.moderate":
        await this.moderate(ws, s, ev.userId, ev.mute, ev.deafen);
        return;

      case "voice.move":
        await this.move(ws, s, ev.userId, ev.channelId);
        return;

      case "dm.typing":
        return; // kullanıcı gateway'inde işlenir
    }
  }

  private async playSound(ws: WebSocket, s: SocketState, soundId: string): Promise<void> {
    const fail = (code: string, message: string) => this.sendTo(ws, { t: "error", code, message, ref: "sound.play" });
    if (!s.voice) return fail("not_in_voice", "Ses çalmak için bir sesli kanalda olmalısın");

    const now = Date.now();
    if (now - s.lastSoundAt < LIMITS.SOUND_USER_COOLDOWN_MS) return fail("cooldown", "Biraz bekle");

    const channelId = s.voice.channelId;
    const windowStart = now - LIMITS.SOUND_ROOM_WINDOW_MS;
    const times = (this.roomSoundTimes.get(channelId) ?? []).filter((t) => t > windowStart);
    if (times.length >= LIMITS.SOUND_ROOM_MAX_PER_WINDOW) return fail("room_rate_limited", "Odada çok fazla ses çalınıyor");

    const snap = await this.getSnapshot(s.guildId);
    if (!hasFlag(snapshotChannelPerms(snap, s.userId, channelId), Permission.PLAY_SOUNDS)) {
      return fail("forbidden", "Bu kanalda ses çalma yetkin yok");
    }

    const sound = await this.env.DB.prepare(
      "SELECT id, guild_id, owner_id, r2_key, sha256, volume FROM sounds WHERE id = ?",
    )
      .bind(soundId)
      .first<{ id: string; guild_id: string | null; owner_id: string; r2_key: string; sha256: string; volume: number }>();
    // Sunucu sesi bu sunucuya ait olmalı; kişisel ses yalnızca sahibince çalınabilir.
    const allowed = sound && (sound.guild_id === s.guildId || (sound.guild_id === null && sound.owner_id === s.userId));
    if (!sound || !allowed) return fail("not_found", "Ses bulunamadı");

    s.lastSoundAt = now;
    this.save(ws, s);
    times.push(now);
    this.roomSoundTimes.set(channelId, times);

    const url = await signedFileUrl(this.env, s.origin, sound.r2_key);
    const event: ServerEvent = {
      t: "sound.play",
      soundId: sound.id,
      sha256: sound.sha256,
      url,
      volume: sound.volume,
      byUserId: s.userId,
      channelId,
      playAt: Date.now() + LIMITS.SOUND_SCHEDULE_LEAD_MS,
    };
    // Sadece aynı sesli odadakiler duyar.
    for (const other of this.ctx.getWebSockets()) {
      const v = this.state(other)?.voice;
      if (v?.channelId === channelId && !v.serverDeaf) this.sendTo(other, event);
    }
  }

  // ------------------------------------------------------------------ moderasyon
  /** Sunucu tarafı susturma/sağırlaştırma; kalıcıdır (yeniden katılınca da sürer). */
  private async moderate(ws: WebSocket, s: SocketState, targetId: string, mute?: boolean, deafen?: boolean): Promise<void> {
    const snap = await this.getSnapshot(s.guildId, true);
    const targetSockets = this.socketsOf(targetId).filter((w) => this.state(w)?.voice);
    const channelId = targetSockets.map((w) => this.state(w)!.voice!.channelId)[0];
    const permsIn = (flag: number) => (channelId ? hasFlag(snapshotChannelPerms(snap, s.userId, channelId), flag) : hasFlag(snapshotBase(snap, s.userId), flag));
    if ((mute !== undefined && !permsIn(Permission.MUTE_MEMBERS)) || (deafen !== undefined && !permsIn(Permission.DEAFEN_MEMBERS))) {
      this.sendTo(ws, { t: "error", code: "forbidden", message: "Bu işlem için yetkin yok", ref: "voice.moderate" });
      return;
    }
    if (targetId === snap.ownerId && s.userId !== snap.ownerId) {
      this.sendTo(ws, { t: "error", code: "forbidden", message: "Sunucu sahibine bu uygulanamaz", ref: "voice.moderate" });
      return;
    }
    const cur = await this.modState(targetId);
    const next = { mute: mute ?? cur.mute, deafen: deafen ?? cur.deafen };
    await this.ctx.storage.put(`mod:${targetId}`, next);
    for (const w of targetSockets) {
      const ts = this.state(w)!;
      const perms = snapshotChannelPerms(snap, targetId, ts.voice!.channelId);
      ts.voice!.serverMute = next.mute || !hasFlag(perms, Permission.SPEAK);
      ts.voice!.serverDeaf = next.deafen;
      if (ts.voice!.serverMute) ts.voice!.speaking = false;
      this.save(w, ts);
      await this.broadcastVoice({ t: "voice.update", participant: ts.voice! }, ts.voice!.channelId);
    }
  }

  /** Kullanıcıyı başka sesli kanala taşı veya (null) sesten at. */
  private async move(ws: WebSocket, s: SocketState, targetId: string, channelId: string | null): Promise<void> {
    const snap = await this.getSnapshot(s.guildId, true);
    const target = this.socketsOf(targetId).find((w) => this.state(w)?.voice);
    if (!target) {
      this.sendTo(ws, { t: "error", code: "not_in_voice", message: "Kullanıcı seste değil", ref: "voice.move" });
      return;
    }
    const ts = this.state(target)!;
    const from = ts.voice!.channelId;
    const canFrom = hasFlag(snapshotChannelPerms(snap, s.userId, from), Permission.MOVE_MEMBERS);
    const toCh = channelId ? snap.channels.get(channelId) : null;
    const canTo = channelId === null || (toCh?.type === "voice" && hasFlag(snapshotChannelPerms(snap, s.userId, channelId), Permission.MOVE_MEMBERS));
    if (!canFrom || !canTo || (targetId === snap.ownerId && s.userId !== snap.ownerId)) {
      this.sendTo(ws, { t: "error", code: "forbidden", message: "Bu kullanıcıyı taşıyamazsın", ref: "voice.move" });
      return;
    }
    if (channelId && !hasFlag(snapshotChannelPerms(snap, targetId, channelId), Permission.CONNECT_VOICE)) {
      this.sendTo(ws, { t: "error", code: "forbidden", message: "Kullanıcının o kanala bağlanma izni yok", ref: "voice.move" });
      return;
    }
    // ÖNCE taşınan kişiye haber verilir: istemci "voice.leave" olayını önce
    // görürse sesli oturumu kapatıp "voice.moved"u hiç işlemez ve taşınacağına
    // sesten düşer. Sonra sunucu tarafında eski kanaldan çıkarılır (sinyal
    // aktarımı kesilir); istemci yeni kanala kendisi katılır.
    this.sendTo(target, { t: "voice.moved", channelId, byUserId: s.userId });
    await this.leaveVoice(target, ts);
  }

  private async modState(userId: string): Promise<{ mute: boolean; deafen: boolean }> {
    return (await this.ctx.storage.get<{ mute: boolean; deafen: boolean }>(`mod:${userId}`)) ?? { mute: false, deafen: false };
  }

  private async leaveVoice(ws: WebSocket, s: SocketState): Promise<void> {
    if (!s.voice) return;
    const channelId = s.voice.channelId;
    const sessionId = s.voiceSessionId;
    s.voice = null;
    s.voiceSessionId = null;
    this.save(ws, s);
    if (sessionId) {
      await this.env.DB.prepare("UPDATE voice_sessions SET left_at = ? WHERE id = ?").bind(Date.now(), sessionId).run();
    }
    await this.broadcastVoice({ t: "voice.leave", userId: s.userId, channelId }, channelId);
  }

  private async cleanup(ws: WebSocket): Promise<void> {
    const s = this.state(ws);
    if (!s) return;
    if (s.voice) {
      try {
        await this.leaveVoice(ws, s);
      } catch (err) {
        log("warn", "guildhub.leave_failed", { err: String(err) });
      }
    }
    // Hâlâ açık başka bağlantısı yoksa çevrimdışı yayınla
    const remaining = this.socketsOf(s.userId).filter((o) => o !== ws && o.readyState === WebSocket.OPEN);
    if (remaining.length === 0) this.broadcastAll({ t: "presence", userId: s.userId, status: "offline" }, ws);
  }

  // ------------------------------------------------------------------ yardımcılar
  private state(ws: WebSocket): SocketState | null {
    return (ws.deserializeAttachment() as SocketState | null) ?? null;
  }

  private save(ws: WebSocket, s: SocketState): void {
    ws.serializeAttachment(s);
  }

  private socketsOf(userId: string): WebSocket[] {
    return this.ctx.getWebSockets(userId);
  }

  private sendTo(ws: WebSocket, ev: ServerEvent): void {
    try {
      ws.send(JSON.stringify(ev));
    } catch {
      /* kapanmış soket */
    }
  }

  private broadcastAll(ev: ServerEvent, except?: WebSocket): void {
    for (const ws of this.ctx.getWebSockets()) if (ws !== except) this.sendTo(ws, ev);
  }

  /** Ses durumunu o kanalı görebilen herkese yayınla. */
  private async broadcastVoice(ev: ServerEvent, channelId: string): Promise<void> {
    const anyState = this.ctx.getWebSockets().map((w) => this.state(w)).find(Boolean);
    if (!anyState) return;
    const snap = await this.getSnapshot(anyState.guildId);
    for (const ws of this.ctx.getWebSockets()) {
      const s = this.state(ws);
      if (s && hasFlag(snapshotChannelPerms(snap, s.userId, channelId), Permission.VIEW_CHANNEL)) this.sendTo(ws, ev);
    }
  }

  private onlineList(): { userId: string; status: PresenceStatus }[] {
    const seen = new Map<string, PresenceStatus>();
    for (const ws of this.ctx.getWebSockets()) {
      const s = this.state(ws);
      if (s && s.status !== "invisible") seen.set(s.userId, s.status);
    }
    return [...seen].map(([userId, status]) => ({ userId, status }));
  }

  private allVoice(): VoiceParticipant[] {
    const out: VoiceParticipant[] = [];
    for (const ws of this.ctx.getWebSockets()) {
      const v = this.state(ws)?.voice;
      if (v) out.push(v);
    }
    return out;
  }

  private async getSnapshot(guildId: string, fresh = false): Promise<GuildSnapshot> {
    if (!fresh && this.snapshot && Date.now() - this.snapshot.loadedAt < SNAPSHOT_TTL_MS) return this.snapshot;
    const snap = await loadGuildSnapshot(this.env.DB, guildId);
    if (!snap) throw new Error("Sunucu bulunamadı");
    this.snapshot = snap;
    return snap;
  }
}
