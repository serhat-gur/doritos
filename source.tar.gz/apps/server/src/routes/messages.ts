import { Hono } from "hono";
import { EditMessageInput, EmojiSchema, hasFlag, LIMITS, ListMessagesQuery, Permission, SearchQuery } from "@yanki/shared";
import type { AppBindings, Env } from "../env";
import { requireAuth } from "../lib/auth";
import type { MessageRow } from "../lib/dto";
import { badRequest, forbidden, notFound, parseJson, parseWith } from "../lib/errors";
import { loadGuildSnapshot, snapshotChannelPerms } from "../lib/guild-snapshot";
import { publish } from "../lib/hub";
import { createMessage, hydrateMessages, loadReactions, parseSendBody, selectMessage, hardDeleteMessage, type MessageTable } from "../lib/messages";
import { requireChannelPermission, requireGuildPermission } from "../lib/perms";
import { enforceRateLimit, RATE_RULES } from "../lib/ratelimit";
import { dmContext } from "../lib/social";
import { publishUsers } from "../lib/userhub";

/** Bir mesajın nerede olduğunu bulur ve isteyenin erişimini doğrular. */
async function locateMessage(env: Env, messageId: string, userId: string, need: number) {
  const g = await env.DB.prepare("SELECT id, channel_id, author_id FROM messages WHERE id = ? AND deleted_at IS NULL")
    .bind(messageId)
    .first<{ id: string; channel_id: string; author_id: string }>();
  if (g) {
    const { channel, perms } = await requireChannelPermission(env.DB, g.channel_id, userId, need);
    return {
      table: "messages" as MessageTable,
      row: g,
      perms,
      publish: (ev: Parameters<typeof publish>[2]) => publish(env, channel.guild_id, ev, g.channel_id),
    };
  }
  const d = await env.DB.prepare("SELECT id, channel_id, author_id FROM dm_messages WHERE id = ? AND deleted_at IS NULL")
    .bind(messageId)
    .first<{ id: string; channel_id: string; author_id: string }>();
  if (!d) throw notFound("Mesaj bulunamadı");
  const ctx = await dmContext(env, d.channel_id, userId);
  return {
    table: "dm_messages" as MessageTable,
    row: d,
    perms: 0,
    publish: (ev: Parameters<typeof publish>[2]) => publishUsers(env, ctx.memberIds, ev),
  };
}

/** FTS5 sorgusu: her kelime ayrı, önek eşleşmeli, özel karakterler etkisiz. */
function ftsQuery(q: string): string {
  return q
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 8)
    .map((t) => `"${t.replace(/"/g, '""')}"*`)
    .join(" ");
}

export const messageRoutes = new Hono<AppBindings>()
  .use(requireAuth)

  .get("/channels/:cid/messages", async (c) => {
    const me = c.get("user");
    const cid = c.req.param("cid");
    const { channel } = await requireChannelPermission(c.env.DB, cid, me.id, Permission.VIEW_CHANNEL);
    if (channel.type !== "text") throw badRequest("Bu kanal yazı kanalı değil");
    const q = parseWith(ListMessagesQuery, c.req.query());
    const { results } = await c.env.DB.prepare(
      `${selectMessage("messages")} WHERE m.channel_id = ? AND m.deleted_at IS NULL ${q.before ? "AND m.id < ?" : ""} ORDER BY m.id DESC LIMIT ?`,
    )
      .bind(...(q.before ? [cid, q.before, q.limit] : [cid, q.limit]))
      .all<MessageRow>();
    return c.json(await hydrateMessages(c.env, new URL(c.req.url).origin, results.reverse()));
  })

  .post("/channels/:cid/messages", async (c) => {
    const me = c.get("user");
    const cid = c.req.param("cid");
    await enforceRateLimit(c.env, `msg:${me.id}`, RATE_RULES.messageByUser);
    const { channel } = await requireChannelPermission(c.env.DB, cid, me.id, Permission.SEND_MESSAGES);
    if (channel.type !== "text") throw badRequest("Bu kanal yazı kanalı değil");
    const body = await parseSendBody(c);
    const dto = await createMessage(c.env, new URL(c.req.url).origin, "messages", { channelId: cid, authorId: me.id, body });
    await publish(c.env, channel.guild_id, { t: "message.create", message: dto }, cid);
    return c.json(dto, 201);
  })

  .patch("/messages/:mid", async (c) => {
    const me = c.get("user");
    const loc = await locateMessage(c.env, c.req.param("mid"), me.id, Permission.VIEW_CHANNEL);
    if (loc.row.author_id !== me.id) throw forbidden("Yalnızca kendi mesajını düzenleyebilirsin");
    const body = await parseJson(c, EditMessageInput);
    await c.env.DB.prepare(`UPDATE ${loc.table} SET content = ?, edited_at = ? WHERE id = ?`).bind(body.content, Date.now(), loc.row.id).run();
    const row = await c.env.DB.prepare(`${selectMessage(loc.table)} WHERE m.id = ?`).bind(loc.row.id).first<MessageRow>();
    const [dto] = await hydrateMessages(c.env, new URL(c.req.url).origin, [row!]);
    await loc.publish({ t: "message.update", message: dto! });
    return c.json(dto);
  })

  .delete("/messages/:mid", async (c) => {
    const me = c.get("user");
    const loc = await locateMessage(c.env, c.req.param("mid"), me.id, Permission.VIEW_CHANNEL);
    const canManage = loc.table === "messages" && hasFlag(loc.perms, Permission.MANAGE_MESSAGES);
    if (loc.row.author_id !== me.id && !canManage) throw forbidden();
    await hardDeleteMessage(c.env, loc.table, loc.row.id);
    await loc.publish({ t: "message.delete", channelId: loc.row.channel_id, messageId: loc.row.id });
    return c.json({ ok: true });
  })

  // ---------------- Tepkiler ----------------
  .put("/messages/:mid/reactions/:emoji", async (c) => reactionChange(c, true))
  .delete("/messages/:mid/reactions/:emoji", async (c) => reactionChange(c, false))

  // ---------------- Arama (sunucu mesajları, FTS5) ----------------
  .get("/guilds/:gid/search", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    await requireGuildPermission(c.env.DB, gid, me.id);
    const q = parseWith(SearchQuery, c.req.query());
    const snap = await loadGuildSnapshot(c.env.DB, gid);
    if (!snap) throw notFound();
    const { results } = await c.env.DB.prepare(
      `SELECT m.id, m.channel_id, m.author_id, m.content, m.reply_to_id, m.created_at, m.edited_at,
              u.username, u.display_name, u.avatar_key
         FROM messages_fts f
         JOIN messages m ON m.rowid = f.rowid
         JOIN channels ch ON ch.id = m.channel_id
         JOIN users u ON u.id = m.author_id
        WHERE messages_fts MATCH ? AND ch.guild_id = ? AND m.deleted_at IS NULL ${q.channelId ? "AND m.channel_id = ?" : ""}
        ORDER BY m.id DESC LIMIT 200`,
    )
      .bind(...(q.channelId ? [ftsQuery(q.q), gid, q.channelId] : [ftsQuery(q.q), gid]))
      .all<MessageRow>();
    // Yalnızca görülebilen kanallardaki sonuçlar
    const visible = results.filter((m) => hasFlag(snapshotChannelPerms(snap, me.id, m.channel_id), Permission.VIEW_CHANNEL)).slice(0, LIMITS.SEARCH_RESULTS_MAX);
    return c.json(await hydrateMessages(c.env, new URL(c.req.url).origin, visible));
  });

async function reactionChange(c: import("hono").Context<AppBindings>, add: boolean) {
  const me = c.get("user");
  const emoji = parseWith(EmojiSchema, decodeURIComponent(c.req.param("emoji") ?? ""));
  const loc = await locateMessage(c.env, c.req.param("mid")!, me.id, Permission.VIEW_CHANNEL);
  if (add) {
    if (loc.table === "messages" && !hasFlag(loc.perms, Permission.SEND_MESSAGES)) throw forbidden();
    await enforceRateLimit(c.env, `write:${me.id}`, RATE_RULES.writeByUser);
    const distinct = await c.env.DB.prepare("SELECT COUNT(DISTINCT emoji) AS n FROM reactions WHERE message_id = ? AND emoji != ?")
      .bind(loc.row.id, emoji)
      .first<{ n: number }>();
    if ((distinct?.n ?? 0) >= LIMITS.REACTIONS_PER_MESSAGE) throw badRequest("Bu mesajda çok fazla farklı tepki var");
    await c.env.DB.prepare("INSERT OR IGNORE INTO reactions (message_id, user_id, emoji, created_at) VALUES (?, ?, ?, ?)")
      .bind(loc.row.id, me.id, emoji, Date.now())
      .run();
  } else {
    await c.env.DB.prepare("DELETE FROM reactions WHERE message_id = ? AND user_id = ? AND emoji = ?").bind(loc.row.id, me.id, emoji).run();
  }
  const reactions = await loadReactions(c.env, loc.row.id);
  await loc.publish({ t: "message.reactions", channelId: loc.row.channel_id, messageId: loc.row.id, reactions });
  return c.json(reactions);
}
