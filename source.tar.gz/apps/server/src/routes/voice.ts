import { Hono } from "hono";
import type { IceServersResponse } from "@yanki/shared";
import type { AppBindings } from "../env";
import { requireAuth } from "../lib/auth";
import { log } from "../lib/log";

const STUN_ONLY: IceServersResponse = {
  iceServers: [{ urls: "stun:stun.cloudflare.com:3478" }],
  turn: false,
};

/**
 * ICE sunucuları. TURN anahtarı istemciye ASLA gömülmez: Worker, Cloudflare
 * Realtime TURN API'sinden kullanıcıya özel, kısa ömürlü kimlik bilgisi üretir.
 * TURN yapılandırılmamışsa yalnızca STUN döner (P2P çoğu NAT'ta çalışır,
 * simetrik NAT / kurumsal ağlarda çalışmayabilir).
 */
export const voiceRoutes = new Hono<AppBindings>().use(requireAuth).get("/ice-servers", async (c) => {
  const { TURN_KEY_ID, TURN_KEY_API_TOKEN } = c.env;
  if (!TURN_KEY_ID || !TURN_KEY_API_TOKEN) return c.json(STUN_ONLY);
  try {
    const res = await fetch(`https://rtc.live.cloudflare.com/v1/turn/keys/${TURN_KEY_ID}/credentials/generate-ice-servers`, {
      method: "POST",
      headers: { Authorization: `Bearer ${TURN_KEY_API_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ ttl: 6 * 60 * 60 }),
    });
    if (!res.ok) throw new Error(`TURN API ${res.status}`);
    const data = (await res.json()) as { iceServers: IceServersResponse["iceServers"] | IceServersResponse["iceServers"][number] };
    const list = Array.isArray(data.iceServers) ? data.iceServers : [data.iceServers];
    // Tarayıcılar 53 numaralı portu engeller; zaman aşımını beklememek için çıkar.
    const filtered = list.map((s) => ({
      ...s,
      urls: (Array.isArray(s.urls) ? s.urls : [s.urls]).filter((u) => !/:53(\?|$)/.test(u)),
    }));
    return c.json({ iceServers: filtered, turn: true } satisfies IceServersResponse);
  } catch (err) {
    log("warn", "turn.credentials_failed", { err: String(err) });
    return c.json(STUN_ONLY);
  }
});
