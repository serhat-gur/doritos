import { Hono } from "hono";
import { z } from "zod";
import { LIMITS, LoginInput, PresenceStatus, RegisterInput, sniffImageMime } from "@yanki/shared";
import { deleteBlob, putBlob } from "../lib/blobs";
import { newId as newBlobId } from "../lib/ids";
import type { AppBindings } from "../env";
import { createSession, requireAuth } from "../lib/auth";
import { hashPassword, verifyPassword } from "../lib/crypto";
import { userDto, type UserRow } from "../lib/dto";
import { badRequest, conflict, forbidden, HttpError, parseJson, unauthorized } from "../lib/errors";
import { newId } from "../lib/ids";
import { enforceRateLimit, RATE_RULES } from "../lib/ratelimit";
import { pbkdf2Iterations } from "../lib/secrets";

const RegisterBody = RegisterInput.extend({ registrationCode: z.string().max(128).optional() });

// Kullanıcı yokken de doğrulama yapılır ki yanıt süresi kullanıcı varlığını sızdırmasın.
let dummyHash: string | null = null;

export const authRoutes = new Hono<AppBindings>()
  .post("/register", async (c) => {
    const ip = c.req.header("CF-Connecting-IP") ?? "local";
    await enforceRateLimit(c.env, `auth:${ip}`, RATE_RULES.authByIp);
    const body = await parseJson(c, RegisterBody);

    const mode = c.env.REGISTRATION_MODE ?? "open";
    if (mode === "closed") throw forbidden("Kayıt kapalı");
    if (mode === "code" && (!c.env.REGISTRATION_CODE || body.registrationCode !== c.env.REGISTRATION_CODE)) {
      throw forbidden("Geçersiz kayıt kodu");
    }

    const exists = await c.env.DB.prepare("SELECT 1 FROM users WHERE username = ?").bind(body.username).first();
    if (exists) throw conflict("Bu kullanıcı adı alınmış");

    const id = newId();
    const passwordHash = await hashPassword(body.password, pbkdf2Iterations(c.env));
    try {
      await c.env.DB.prepare(
        "INSERT INTO users (id, username, display_name, password_hash, created_at) VALUES (?, ?, ?, ?, ?)",
      )
        .bind(id, body.username, body.displayName, passwordHash, Date.now())
        .run();
    } catch (err) {
      if (String(err).includes("UNIQUE")) throw conflict("Bu kullanıcı adı alınmış");
      throw err;
    }
    const token = await createSession(c.env, id, c.req.header("User-Agent") ?? null);
    const user: UserRow = { id, username: body.username, display_name: body.displayName, avatar_key: null, bio: "", status: "online" };
    return c.json({ token, user: await userDto(c.env, new URL(c.req.url).origin, user) }, 201);
  })

  .post("/login", async (c) => {
    const ip = c.req.header("CF-Connecting-IP") ?? "local";
    await enforceRateLimit(c.env, `auth:${ip}`, RATE_RULES.authByIp);
    const body = await parseJson(c, LoginInput);
    const row = await c.env.DB.prepare(
      "SELECT id, username, display_name, avatar_key, bio, status, password_hash FROM users WHERE username = ?",
    )
      .bind(body.username.toLowerCase())
      .first<UserRow & { password_hash: string }>();
    if (!row) {
      dummyHash ??= await hashPassword("yanki-dummy-password", pbkdf2Iterations(c.env));
      await verifyPassword(body.password, dummyHash);
      throw unauthorized("Kullanıcı adı veya şifre hatalı");
    }
    if (!(await verifyPassword(body.password, row.password_hash))) {
      throw unauthorized("Kullanıcı adı veya şifre hatalı");
    }
    const token = await createSession(c.env, row.id, c.req.header("User-Agent") ?? null);
    return c.json({ token, user: await userDto(c.env, new URL(c.req.url).origin, row) });
  })

  .post("/logout", requireAuth, async (c) => {
    await c.env.DB.prepare("DELETE FROM sessions WHERE id = ?").bind(c.get("user").sessionId).run();
    return c.json({ ok: true });
  });

const UpdateMeInput = z.object({
  displayName: z.string().trim().min(1).max(48).optional(),
  bio: z.string().max(190).optional(),
  status: PresenceStatus.optional(),
});

export const meRoutes = new Hono<AppBindings>()
  .use(requireAuth)
  .get("/", async (c) => {
    const row = await c.env.DB.prepare("SELECT id, username, display_name, avatar_key, bio, status FROM users WHERE id = ?")
      .bind(c.get("user").id)
      .first<UserRow>();
    if (!row) throw unauthorized();
    return c.json(await userDto(c.env, new URL(c.req.url).origin, row));
  })
  .patch("/", async (c) => {
    const body = await parseJson(c, UpdateMeInput);
    const me = c.get("user");
    await c.env.DB.prepare(
      `UPDATE users SET display_name = COALESCE(?, display_name), bio = COALESCE(?, bio), status = COALESCE(?, status) WHERE id = ?`,
    )
      .bind(body.displayName ?? null, body.bio ?? null, body.status ?? null, me.id)
      .run();
    const row = await c.env.DB.prepare("SELECT id, username, display_name, avatar_key, bio, status FROM users WHERE id = ?")
      .bind(me.id)
      .first<UserRow>();
    return c.json(await userDto(c.env, new URL(c.req.url).origin, row!));
  })
  // Profil resmi (PNG/JPEG/GIF/WebP, ≤ 1 MB; istemci 256 px'e küçültür)
  .post("/avatar", async (c) => {
    const me = c.get("user");
    const bytes = await readImageUpload(c, LIMITS.AVATAR_MAX_BYTES);
    const old = await c.env.DB.prepare("SELECT avatar_key FROM users WHERE id = ?").bind(me.id).first<{ avatar_key: string | null }>();
    const { key } = await putBlob(c.env, { kind: "avatar", id: newBlobId(), ownerId: me.id, bytes: bytes.data, mime: bytes.mime });
    await c.env.DB.prepare("UPDATE users SET avatar_key = ? WHERE id = ?").bind(key, me.id).run();
    if (old?.avatar_key) await deleteBlob(c.env, old.avatar_key).catch(() => {});
    const row = await c.env.DB.prepare("SELECT id, username, display_name, avatar_key, bio, status FROM users WHERE id = ?").bind(me.id).first<UserRow>();
    return c.json(await userDto(c.env, new URL(c.req.url).origin, row!));
  })
  .delete("/avatar", async (c) => {
    const me = c.get("user");
    const old = await c.env.DB.prepare("SELECT avatar_key FROM users WHERE id = ?").bind(me.id).first<{ avatar_key: string | null }>();
    await c.env.DB.prepare("UPDATE users SET avatar_key = NULL WHERE id = ?").bind(me.id).run();
    if (old?.avatar_key) await deleteBlob(c.env, old.avatar_key).catch(() => {});
    return c.json({ ok: true });
  });

/** multipart "file" alanından resim okur ve içeriğinden doğrular. */
export async function readImageUpload(c: import("hono").Context<AppBindings>, maxBytes: number) {
  let form: FormData;
  try {
    form = await c.req.formData();
  } catch {
    throw badRequest("multipart/form-data bekleniyor");
  }
  const file = form.get("file");
  if (!file || typeof file === "string") throw badRequest("'file' alanı gerekli");
  if (file.size > maxBytes) throw new HttpError(413, "too_large", `En fazla ${Math.round(maxBytes / 1024)} KB`);
  const data = new Uint8Array(await file.arrayBuffer());
  const mime = sniffImageMime(data);
  if (!mime) throw new HttpError(415, "unsupported_media", "Yalnızca PNG, JPEG, GIF veya WebP");
  return { data, mime };
}
