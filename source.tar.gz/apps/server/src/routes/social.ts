import { Hono } from "hono";
import { CreateDmInput, FriendRequestInput, LIMITS, ListMessagesQuery, type DmChannelDTO, type FriendDTO } from "@yanki/shared";
import type { AppBindings } from "../env";
import { requireAuth } from "../lib/auth";
import { signToken } from "../lib/crypto";
import type { MessageRow } from "../lib/dto";
import { badRequest, conflict, forbidden, notFound, parseJson, parseWith } from "../lib/errors";
import { newId } from "../lib/ids";
import { createMessage, hydrateMessages, parseSendBody, selectMessage } from "../lib/messages";
import { enforceRateLimit, RATE_RULES } from "../lib/ratelimit";
import { appSecret } from "../lib/secrets";
import { assertCanWriteDm, dmChannelDto, dmContext, friendDto, isBlockedBetween, relation } from "../lib/social";
import { publishUsers, userHub } from "../lib/userhub";

const origin = (url: string) => new URL(url).origin;

/** Arkadaşlık değişince her iki tarafın gateway'ine kendi bakış açısından durum gönder. */
async function notifyRelation(env: AppBindings["Bindings"], o: string, a: string, b: string) {
  for (const [me, other] of [
    [a, b],
    [b, a],
  ] as const) {
    const dto = await friendDto(env, o, me, other);
    await publishUsers(env, [me], dto ? { t: "friend.update", friend: dto } : { t: "friend.remove", userId: other });
    // Yeni arkadaşın o anki çevrimiçi durumu (yoksa bir sonraki bağlantıya kadar gri görünürdü)
    if (dto?.state === "friend") {
      const status = await userHub(env, other).presence().catch(() => "offline" as const);
      await publishUsers(env, [me], { t: "presence", userId: other, status });
    }
  }
}

export const socialRoutes = new Hono<AppBindings>()
  .use(requireAuth)

  // Kişisel gateway bileti (arkadaş/DM olayları)
  .post("/gateway-ticket", async (c) => {
    const ticket = await signToken(appSecret(c.env), { uid: c.get("user").id, gid: "@me", exp: Date.now() + LIMITS.GATEWAY_TICKET_TTL_MS });
    return c.json({ ticket });
  })

  // ---------------- Arkadaşlar ----------------
  .get("/friends", async (c) => {
    const me = c.get("user").id;
    const { results } = await c.env.DB.prepare(
      "SELECT friend_id AS other FROM friendships WHERE user_id = ? UNION SELECT user_id AS other FROM friendships WHERE friend_id = ? AND status = 'pending'",
    )
      .bind(me, me)
      .all<{ other: string }>();
    const out: FriendDTO[] = [];
    for (const r of results) {
      const dto = await friendDto(c.env, origin(c.req.url), me, r.other);
      if (dto) out.push(dto);
    }
    return c.json(out);
  })

  // İstek gönder (karşı taraf zaten istek gönderdiyse doğrudan kabul edilir)
  .post("/friends", async (c) => {
    const me = c.get("user").id;
    await enforceRateLimit(c.env, `write:${me}`, RATE_RULES.writeByUser);
    const { username } = await parseJson(c, FriendRequestInput);
    const target = await c.env.DB.prepare("SELECT id FROM users WHERE username = ?").bind(username.toLowerCase()).first<{ id: string }>();
    // Engellenmişsen de "bulunamadı" denir (engel bilgisi sızdırılmaz)
    if (!target || target.id === me || (await isBlockedBetween(c.env, me, target.id))) throw notFound("Kullanıcı bulunamadı");
    const rel = await relation(c.env, me, target.id);
    if (rel === "friend") throw conflict("Zaten arkadaşsınız");
    if (rel === "outgoing") throw conflict("İstek zaten gönderildi");
    const now = Date.now();
    if (rel === "incoming") {
      await c.env.DB.batch([
        c.env.DB.prepare("UPDATE friendships SET status = 'accepted' WHERE user_id = ? AND friend_id = ?").bind(target.id, me),
        c.env.DB.prepare("INSERT OR REPLACE INTO friendships (user_id, friend_id, status, created_at) VALUES (?, ?, 'accepted', ?)").bind(me, target.id, now),
      ]);
    } else {
      await c.env.DB.prepare("INSERT INTO friendships (user_id, friend_id, status, created_at) VALUES (?, ?, 'pending', ?)").bind(me, target.id, now).run();
    }
    await notifyRelation(c.env, origin(c.req.url), me, target.id);
    return c.json(await friendDto(c.env, origin(c.req.url), me, target.id), 201);
  })

  // Gelen isteği kabul et
  .put("/friends/:uid", async (c) => {
    const me = c.get("user").id;
    const other = c.req.param("uid");
    if ((await relation(c.env, me, other)) !== "incoming") throw notFound("Bekleyen istek yok");
    await c.env.DB.batch([
      c.env.DB.prepare("UPDATE friendships SET status = 'accepted' WHERE user_id = ? AND friend_id = ?").bind(other, me),
      c.env.DB.prepare("INSERT OR REPLACE INTO friendships (user_id, friend_id, status, created_at) VALUES (?, ?, 'accepted', ?)").bind(me, other, Date.now()),
    ]);
    await notifyRelation(c.env, origin(c.req.url), me, other);
    return c.json(await friendDto(c.env, origin(c.req.url), me, other));
  })

  // Arkadaşlıktan çıkar / isteği reddet / isteği geri çek
  .delete("/friends/:uid", async (c) => {
    const me = c.get("user").id;
    const other = c.req.param("uid");
    await c.env.DB.prepare(
      "DELETE FROM friendships WHERE status != 'blocked' AND ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?))",
    )
      .bind(me, other, other, me)
      .run();
    await notifyRelation(c.env, origin(c.req.url), me, other);
    return c.json({ ok: true });
  })

  // ---------------- Engelleme ----------------
  .put("/blocks/:uid", async (c) => {
    const me = c.get("user").id;
    const other = c.req.param("uid");
    if (other === me) throw badRequest("Kendini engelleyemezsin");
    const exists = await c.env.DB.prepare("SELECT 1 FROM users WHERE id = ?").bind(other).first();
    if (!exists) throw notFound("Kullanıcı bulunamadı");
    await c.env.DB.batch([
      // Arkadaşlık ve bekleyen istekler iki yönde silinir; benim kaydım "blocked" olur
      c.env.DB.prepare("DELETE FROM friendships WHERE user_id = ? AND friend_id = ? AND status != 'blocked'").bind(other, me),
      c.env.DB.prepare("INSERT OR REPLACE INTO friendships (user_id, friend_id, status, created_at) VALUES (?, ?, 'blocked', ?)").bind(me, other, Date.now()),
    ]);
    await notifyRelation(c.env, origin(c.req.url), me, other);
    return c.json({ ok: true });
  })
  .delete("/blocks/:uid", async (c) => {
    const me = c.get("user").id;
    const other = c.req.param("uid");
    await c.env.DB.prepare("DELETE FROM friendships WHERE user_id = ? AND friend_id = ? AND status = 'blocked'").bind(me, other).run();
    await notifyRelation(c.env, origin(c.req.url), me, other);
    return c.json({ ok: true });
  })

  // ---------------- Özel mesajlar ----------------
  .get("/dms", async (c) => {
    const me = c.get("user").id;
    const { results } = await c.env.DB.prepare(
      "SELECT d.id FROM dm_channels d JOIN dm_members m ON m.channel_id = d.id WHERE m.user_id = ? ORDER BY COALESCE(d.last_message_at, d.created_at) DESC",
    )
      .bind(me)
      .all<{ id: string }>();
    const out: DmChannelDTO[] = [];
    for (const r of results) out.push(await dmChannelDto(c.env, origin(c.req.url), r.id));
    return c.json(out);
  })

  // Birebir DM (varsa mevcut olanı döner) veya grup DM oluştur
  .post("/dms", async (c) => {
    const me = c.get("user").id;
    await enforceRateLimit(c.env, `write:${me}`, RATE_RULES.writeByUser);
    const body = await parseJson(c, CreateDmInput);
    const others = [...new Set(body.userIds.filter((u) => u !== me))];
    if (others.length === 0) throw badRequest("En az bir kişi seç");
    for (const o of others) {
      if (await isBlockedBetween(c.env, me, o)) throw forbidden("Engellenen biriyle sohbet açılamaz");
      // Birebir DM: arkadaş veya ortak sunucu üyesi olmalı. Grup DM: yalnızca arkadaşlar.
      const friend = (await relation(c.env, me, o)) === "friend";
      if (!friend) {
        if (others.length > 1) throw forbidden("Grup sohbetine yalnızca arkadaşlarını ekleyebilirsin");
        const shared = await c.env.DB.prepare(
          "SELECT 1 FROM guild_members a JOIN guild_members b ON a.guild_id = b.guild_id WHERE a.user_id = ? AND b.user_id = ? LIMIT 1",
        )
          .bind(me, o)
          .first();
        if (!shared) throw forbidden("Bu kişiyle ortak bir sunucunuz veya arkadaşlığınız yok");
      }
    }
    const now = Date.now();
    let id: string;
    if (others.length === 1) {
      const key = [me, others[0]!].sort().join(":");
      const existing = await c.env.DB.prepare("SELECT id FROM dm_channels WHERE dm_key = ?").bind(key).first<{ id: string }>();
      if (existing) return c.json(await dmChannelDto(c.env, origin(c.req.url), existing.id));
      id = newId();
      await c.env.DB.batch([
        c.env.DB.prepare("INSERT INTO dm_channels (id, type, dm_key, created_at) VALUES (?, 'dm', ?, ?)").bind(id, key, now),
        c.env.DB.prepare("INSERT INTO dm_members (channel_id, user_id) VALUES (?, ?), (?, ?)").bind(id, me, id, others[0]!),
      ]);
    } else {
      id = newId();
      await c.env.DB.batch([
        c.env.DB.prepare("INSERT INTO dm_channels (id, type, name, owner_id, created_at) VALUES (?, 'group', ?, ?, ?)").bind(id, body.name ?? null, me, now),
        ...[me, ...others].map((u) => c.env.DB.prepare("INSERT INTO dm_members (channel_id, user_id) VALUES (?, ?)").bind(id, u)),
      ]);
    }
    const dto = await dmChannelDto(c.env, origin(c.req.url), id);
    await publishUsers(c.env, [me, ...others], { t: "dm.channel", channel: dto });
    return c.json(dto, 201);
  })

  // Grup DM'den ayrıl
  .delete("/dms/:id/members/@me", async (c) => {
    const me = c.get("user").id;
    const ctx = await dmContext(c.env, c.req.param("id"), me);
    if (ctx.type !== "group") throw badRequest("Birebir sohbetten ayrılınamaz");
    await c.env.DB.prepare("DELETE FROM dm_members WHERE channel_id = ? AND user_id = ?").bind(ctx.id, me).run();
    const rest = ctx.memberIds.filter((m) => m !== me);
    if (rest.length) await publishUsers(c.env, rest, { t: "dm.channel", channel: await dmChannelDto(c.env, origin(c.req.url), ctx.id) });
    return c.json({ ok: true });
  })

  .get("/dms/:id/messages", async (c) => {
    const me = c.get("user").id;
    const ctx = await dmContext(c.env, c.req.param("id"), me);
    const q = parseWith(ListMessagesQuery, c.req.query());
    const { results } = await c.env.DB.prepare(
      `${selectMessage("dm_messages")} WHERE m.channel_id = ? AND m.deleted_at IS NULL ${q.before ? "AND m.id < ?" : ""} ORDER BY m.id DESC LIMIT ?`,
    )
      .bind(...(q.before ? [ctx.id, q.before, q.limit] : [ctx.id, q.limit]))
      .all<MessageRow>();
    return c.json(await hydrateMessages(c.env, origin(c.req.url), results.reverse()));
  })

  .post("/dms/:id/messages", async (c) => {
    const me = c.get("user").id;
    await enforceRateLimit(c.env, `msg:${me}`, RATE_RULES.messageByUser);
    const ctx = await dmContext(c.env, c.req.param("id"), me);
    await assertCanWriteDm(c.env, ctx, me);
    const body = await parseSendBody(c);
    const dto = await createMessage(c.env, origin(c.req.url), "dm_messages", { channelId: ctx.id, authorId: me, body });
    await publishUsers(c.env, ctx.memberIds, { t: "message.create", message: dto });
    return c.json(dto, 201);
  });
