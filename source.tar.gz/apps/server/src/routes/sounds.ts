import { Hono } from "hono";
import { hasFlag, LIMITS, Permission, sniffSoundMime, SoundMetaInput, UpdateSoundInput } from "@yanki/shared";
import type { AppBindings } from "../env";
import { requireAuth } from "../lib/auth";
import { deleteBlob, putBlob } from "../lib/blobs";
import { soundDto, type SoundRow } from "../lib/dto";
import { badRequest, forbidden, HttpError, notFound, parseJson, parseWith } from "../lib/errors";
import { publish } from "../lib/hub";
import { newId } from "../lib/ids";
import { requireGuildPermission } from "../lib/perms";
import { enforceRateLimit, RATE_RULES } from "../lib/ratelimit";

const SOUND_COLS = "id, guild_id, owner_id, name, emoji, category, volume, r2_key, mime, size, sha256, created_at";

export const soundRoutes = new Hono<AppBindings>()
  .use(requireAuth)

  // Kişisel sesler
  .get("/me", async (c) => {
    const me = c.get("user");
    const { results } = await c.env.DB.prepare(`SELECT ${SOUND_COLS} FROM sounds WHERE guild_id IS NULL AND owner_id = ? ORDER BY category, name`)
      .bind(me.id)
      .all<SoundRow>();
    const origin = new URL(c.req.url).origin;
    return c.json(await Promise.all(results.map((s) => soundDto(c.env, origin, s))));
  })

  // Sunucu sesleri
  .get("/guild/:gid", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    await requireGuildPermission(c.env.DB, gid, me.id);
    const { results } = await c.env.DB.prepare(`SELECT ${SOUND_COLS} FROM sounds WHERE guild_id = ? ORDER BY category, name`)
      .bind(gid)
      .all<SoundRow>();
    const origin = new URL(c.req.url).origin;
    return c.json(await Promise.all(results.map((s) => soundDto(c.env, origin, s))));
  })

  // Favoriler (id listesi)
  .get("/favorites", async (c) => {
    const { results } = await c.env.DB.prepare("SELECT sound_id FROM sound_favorites WHERE user_id = ?").bind(c.get("user").id).all<{ sound_id: string }>();
    return c.json(results.map((r) => r.sound_id));
  })

  /**
   * Ses yükleme (multipart/form-data): file + name, emoji, category, volume, guildId.
   * Dosya Worker üzerinden geçer; içerik baytlarından biçim doğrulanır,
   * boyut ve kota sınırları sunucu tarafında uygulanır.
   */
  .post("/", async (c) => {
    const me = c.get("user");
    await enforceRateLimit(c.env, `upload:${me.id}`, RATE_RULES.uploadByUser);

    const len = Number(c.req.header("Content-Length") ?? "0");
    if (len > LIMITS.SOUND_MAX_BYTES + 64 * 1024) throw new HttpError(413, "too_large", "Dosya çok büyük");

    let form: FormData;
    try {
      form = await c.req.formData();
    } catch {
      throw badRequest("multipart/form-data bekleniyor");
    }
    const file = form.get("file");
    if (!file || typeof file === "string") throw badRequest("'file' alanı gerekli");
    if (file.size === 0) throw badRequest("Dosya boş");
    if (file.size > LIMITS.SOUND_MAX_BYTES) throw new HttpError(413, "too_large", `En fazla ${LIMITS.SOUND_MAX_BYTES / 1024 / 1024} MB`);

    const meta = parseWith(SoundMetaInput, {
      name: form.get("name") ?? undefined,
      emoji: form.get("emoji") ?? undefined,
      category: form.get("category") ?? undefined,
      volume: form.get("volume") ?? undefined,
      guildId: (form.get("guildId") as string | null) || null,
    });

    if (meta.guildId) {
      await requireGuildPermission(c.env.DB, meta.guildId, me.id, Permission.UPLOAD_SOUNDS);
    }

    const bytes = new Uint8Array(await file.arrayBuffer());
    const mime = sniffSoundMime(bytes);
    if (!mime) throw new HttpError(415, "unsupported_media", "Yalnızca MP3, WAV ve OGG desteklenir");

    // Sunucu paneli kotası (kişisel kota putBlob içinde, genel tavan da orada)
    if (meta.guildId) {
      const g = await c.env.DB.prepare("SELECT COALESCE(SUM(size), 0) AS total FROM sounds WHERE guild_id = ?").bind(meta.guildId).first<{ total: number }>();
      if ((g?.total ?? 0) + bytes.length > LIMITS.SOUND_GUILD_QUOTA_BYTES) throw new HttpError(413, "quota", "Sunucu ses kotası doldu");
    }

    const id = newId();
    const { key, sha256 } = await putBlob(c.env, { kind: "sound", id, ownerId: me.id, bytes, mime, userQuota: LIMITS.SOUND_USER_QUOTA_BYTES });
    const row: SoundRow = {
      id,
      guild_id: meta.guildId ?? null,
      owner_id: me.id,
      name: meta.name,
      emoji: meta.emoji,
      category: meta.category,
      volume: meta.volume,
      r2_key: key,
      mime,
      size: bytes.length,
      sha256,
      created_at: Date.now(),
    };
    try {
      await c.env.DB.prepare(
        `INSERT INTO sounds (${SOUND_COLS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
        .bind(row.id, row.guild_id, row.owner_id, row.name, row.emoji, row.category, row.volume, row.r2_key, row.mime, row.size, row.sha256, row.created_at)
        .run();
    } catch (err) {
      await deleteBlob(c.env, key); // metadata yazılamadıysa yetim dosya bırakma
      throw err;
    }
    const dto = await soundDto(c.env, new URL(c.req.url).origin, row);
    if (row.guild_id) await publish(c.env, row.guild_id, { t: "sound.created", sound: dto });
    return c.json(dto, 201);
  })

  .patch("/:id", async (c) => {
    const me = c.get("user");
    const row = await loadEditableSound(c.env, c.req.param("id"), me.id);
    const body = await parseJson(c, UpdateSoundInput);
    const updated = { ...row, ...Object.fromEntries(Object.entries(body).filter(([, v]) => v !== undefined)) } as SoundRow;
    await c.env.DB.prepare("UPDATE sounds SET name = ?, emoji = ?, category = ?, volume = ? WHERE id = ?")
      .bind(updated.name, updated.emoji, updated.category, updated.volume, row.id)
      .run();
    return c.json(await soundDto(c.env, new URL(c.req.url).origin, updated));
  })

  .delete("/:id", async (c) => {
    const me = c.get("user");
    const row = await loadEditableSound(c.env, c.req.param("id"), me.id);
    await c.env.DB.prepare("DELETE FROM sounds WHERE id = ?").bind(row.id).run();
    await deleteBlob(c.env, row.r2_key);
    if (row.guild_id) await publish(c.env, row.guild_id, { t: "sound.deleted", soundId: row.id });
    return c.json({ ok: true });
  })

  .put("/:id/favorite", async (c) => {
    const me = c.get("user");
    await loadVisibleSound(c.env, c.req.param("id"), me.id);
    await c.env.DB.prepare("INSERT OR IGNORE INTO sound_favorites (user_id, sound_id) VALUES (?, ?)").bind(me.id, c.req.param("id")).run();
    return c.json({ ok: true });
  })
  .delete("/:id/favorite", async (c) => {
    await c.env.DB.prepare("DELETE FROM sound_favorites WHERE user_id = ? AND sound_id = ?").bind(c.get("user").id, c.req.param("id")).run();
    return c.json({ ok: true });
  });

async function loadVisibleSound(env: AppBindings["Bindings"], id: string, userId: string): Promise<SoundRow> {
  const row = await env.DB.prepare(`SELECT ${SOUND_COLS} FROM sounds WHERE id = ?`).bind(id).first<SoundRow>();
  if (!row) throw notFound("Ses bulunamadı");
  if (row.guild_id === null) {
    if (row.owner_id !== userId) throw notFound("Ses bulunamadı");
  } else {
    await requireGuildPermission(env.DB, row.guild_id, userId);
  }
  return row;
}

/** Sahibi veya (sunucu sesi ise) MANAGE_SOUNDBOARD yetkisi olan düzenleyebilir. */
async function loadEditableSound(env: AppBindings["Bindings"], id: string, userId: string): Promise<SoundRow> {
  const row = await loadVisibleSound(env, id, userId);
  if (row.owner_id === userId) return row;
  if (row.guild_id) {
    const { perms } = await requireGuildPermission(env.DB, row.guild_id, userId);
    if (hasFlag(perms, Permission.MANAGE_SOUNDBOARD)) return row;
  }
  throw forbidden("Bu sesi düzenleyemezsin");
}
