import { Hono } from "hono";
import { z } from "zod";
import {
  ALL_PERMISSIONS,
  computeBasePermissions,
  computeChannelPermissions,
  CreateChannelInput,
  CreateGuildInput,
  CreateInviteInput,
  DEFAULT_EVERYONE_PERMISSIONS,
  hasFlag,
  highestRolePosition,
  LIMITS,
  Permission,
  ROLE_PRESETS,
  UpdateChannelInput,
  UpdateGuildInput,
  type ChannelDTO,
  type GuildDTO,
  type RoleDTO,
} from "@yanki/shared";
import type { AppBindings } from "../env";
import { requireAuth } from "../lib/auth";
import { signToken } from "../lib/crypto";
import { channelDto, userDto, type UserRow } from "../lib/dto";
import { badRequest, conflict, forbidden, notFound, parseJson } from "../lib/errors";
import { newId, randomCode } from "../lib/ids";
import { hubStub, publish } from "../lib/hub";
import { loadMemberContext, loadOverwrites, requireChannelPermission, requireGuildPermission, type ChannelRow, type GuildRow } from "../lib/perms";
const loadMemberContextOrNull = loadMemberContext;
import { enforceRateLimit, RATE_RULES } from "../lib/ratelimit";
import { appSecret } from "../lib/secrets";
import { signedFileUrl } from "../lib/files";
import { deleteBlob, putBlob } from "../lib/blobs";
import { readImageUpload } from "./auth";
import { BanInput, UpdateRoleInput, LIMITS as L } from "@yanki/shared";
import { publishUsers } from "../lib/userhub";

async function guildDto(env: AppBindings["Bindings"], origin: string, g: GuildRow, perms: number): Promise<GuildDTO> {
  return {
    id: g.id,
    name: g.name,
    iconUrl: g.icon_key ? await signedFileUrl(env, origin, g.icon_key) : null,
    ownerId: g.owner_id,
    afkChannelId: g.afk_channel_id ?? null,
    afkSoundId: g.afk_sound_id ?? null,
    myPermissions: perms,
  };
}

export const guildRoutes = new Hono<AppBindings>()
  .use(requireAuth)

  // Üyesi olduğum sunucular
  .get("/", async (c) => {
    const me = c.get("user");
    const { results } = await c.env.DB.prepare(
      `SELECT g.id, g.name, g.icon_key, g.owner_id, g.afk_channel_id, g.afk_sound_id FROM guilds g
         JOIN guild_members m ON m.guild_id = g.id WHERE m.user_id = ? ORDER BY m.joined_at`,
    )
      .bind(me.id)
      .all<GuildRow>();
    const origin = new URL(c.req.url).origin;
    const out: GuildDTO[] = [];
    for (const g of results) {
      const data = await requireGuildPermission(c.env.DB, g.id, me.id);
      out.push(await guildDto(c.env, origin, g, data.perms));
    }
    return c.json(out);
  })

  // Sunucu oluştur: @everyone, Admin ve Moderator rolleri + varsayılan kanallar
  .post("/", async (c) => {
    const me = c.get("user");
    await enforceRateLimit(c.env, `write:${me.id}`, RATE_RULES.writeByUser);
    const body = await parseJson(c, CreateGuildInput);
    const id = newId();
    const now = Date.now();
    const catText = newId(now);
    const catVoice = newId(now);
    const text = newId(now);
    const voice = newId(now);
    const db = c.env.DB;
    await db.batch([
      db.prepare("INSERT INTO guilds (id, name, owner_id, created_at) VALUES (?, ?, ?, ?)").bind(id, body.name, me.id, now),
      db.prepare("INSERT INTO guild_members (guild_id, user_id, joined_at) VALUES (?, ?, ?)").bind(id, me.id, now),
      db
        .prepare("INSERT INTO roles (id, guild_id, name, position, permissions, created_at) VALUES (?, ?, '@everyone', 0, ?, ?)")
        .bind(id, id, DEFAULT_EVERYONE_PERMISSIONS, now),
      db
        .prepare("INSERT INTO roles (id, guild_id, name, color, position, permissions, created_at) VALUES (?, ?, 'Admin', '#e5484d', 3, ?, ?)")
        .bind(newId(now), id, ROLE_PRESETS.Admin, now),
      db
        .prepare("INSERT INTO roles (id, guild_id, name, color, position, permissions, created_at) VALUES (?, ?, 'Moderator', '#3e9b6f', 2, ?, ?)")
        .bind(newId(now), id, ROLE_PRESETS.Moderator, now),
      db
        .prepare("INSERT INTO channels (id, guild_id, type, name, position, created_at) VALUES (?, ?, 'category', 'Yazı Kanalları', 0, ?)")
        .bind(catText, id, now),
      db
        .prepare("INSERT INTO channels (id, guild_id, type, name, position, created_at) VALUES (?, ?, 'category', 'Ses Kanalları', 1, ?)")
        .bind(catVoice, id, now),
      db
        .prepare("INSERT INTO channels (id, guild_id, type, name, parent_id, position, created_at) VALUES (?, ?, 'text', 'genel', ?, 0, ?)")
        .bind(text, id, catText, now),
      db
        .prepare("INSERT INTO channels (id, guild_id, type, name, parent_id, position, created_at) VALUES (?, ?, 'voice', 'Sohbet', ?, 0, ?)")
        .bind(voice, id, catVoice, now),
    ]);
    const guild: GuildRow = { id, name: body.name, icon_key: null, owner_id: me.id, afk_channel_id: null, afk_sound_id: null };
    return c.json(await guildDto(c.env, new URL(c.req.url).origin, guild, ALL_PERMISSIONS), 201);
  })

  // Sunucu ayrıntısı: kanallar (görünür olanlar), roller, üyeler
  .get("/:gid", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    const data = await requireGuildPermission(c.env.DB, gid, me.id);
    const db = c.env.DB;
    const [channels, overwrites, roles, members, memberRoles] = await db.batch([
      db.prepare("SELECT id, guild_id, type, name, parent_id, position, is_private FROM channels WHERE guild_id = ? ORDER BY position, id").bind(gid),
      db
        .prepare(
          "SELECT o.channel_id, o.target_type, o.target_id, o.allow, o.deny FROM channel_overwrites o JOIN channels c ON c.id = o.channel_id WHERE c.guild_id = ?",
        )
        .bind(gid),
      db.prepare("SELECT id, guild_id, name, color, position, permissions FROM roles WHERE guild_id = ? ORDER BY position DESC").bind(gid),
      db
        .prepare(
          `SELECT u.id, u.username, u.display_name, u.avatar_key, u.bio, u.status, m.nickname
             FROM guild_members m JOIN users u ON u.id = m.user_id WHERE m.guild_id = ?`,
        )
        .bind(gid),
      db.prepare("SELECT user_id, role_id FROM member_roles WHERE guild_id = ?").bind(gid),
    ]);
    const owByChannel = new Map<string, { targetType: "role" | "member"; targetId: string; allow: number; deny: number }[]>();
    for (const o of overwrites!.results as { channel_id: string; target_type: "role" | "member"; target_id: string; allow: number; deny: number }[]) {
      const list = owByChannel.get(o.channel_id) ?? [];
      list.push({ targetType: o.target_type, targetId: o.target_id, allow: o.allow, deny: o.deny });
      owByChannel.set(o.channel_id, list);
    }
    const visible: ChannelDTO[] = [];
    for (const ch of channels!.results as ChannelRow[]) {
      const perms = computeChannelPermissions(data.ctx, owByChannel.get(ch.id) ?? []);
      if (hasFlag(perms, Permission.VIEW_CHANNEL)) {
        visible.push({
          ...channelDto(ch),
          myPermissions: perms,
          ...(hasFlag(data.perms, Permission.MANAGE_ROLES) ? { overwrites: owByChannel.get(ch.id) ?? [] } : {}),
        });
      }
    }
    const origin = new URL(c.req.url).origin;
    const rolesByUser = new Map<string, string[]>();
    for (const r of memberRoles!.results as { user_id: string; role_id: string }[]) {
      rolesByUser.set(r.user_id, [...(rolesByUser.get(r.user_id) ?? []), r.role_id]);
    }
    const memberList = await Promise.all(
      (members!.results as (UserRow & { nickname: string | null })[]).map(async (m) => {
        const u = await userDto(c.env, origin, m);
        // Görünmez kullanıcılar diğerlerine çevrimdışı gibi görünür
        if (u.status === "invisible" && m.id !== me.id) u.status = "online";
        return { user: u, roleIds: rolesByUser.get(m.id) ?? [], nickname: m.nickname };
      }),
    );
    return c.json({
      guild: await guildDto(c.env, origin, data.guild, data.perms),
      channels: visible,
      roles: roles!.results.map((r) => {
        const row = r as { id: string; guild_id: string; name: string; color: string | null; position: number; permissions: number };
        return { id: row.id, guildId: row.guild_id, name: row.name, color: row.color, position: row.position, permissions: row.permissions } satisfies RoleDTO;
      }),
      members: memberList,
    });
  })

  .patch("/:gid", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    await requireGuildPermission(c.env.DB, gid, me.id, Permission.MANAGE_SERVER);
    const body = await parseJson(c, UpdateGuildInput);
    if (body.afkChannelId) {
      const ch = await c.env.DB.prepare("SELECT type FROM channels WHERE id = ? AND guild_id = ?").bind(body.afkChannelId, gid).first<{ type: string }>();
      if (!ch || ch.type !== "voice") throw badRequest("AFK kanalı bu sunucudaki bir sesli kanal olmalı");
    }
    if (body.afkSoundId) {
      const snd = await c.env.DB.prepare("SELECT 1 AS ok FROM sounds WHERE id = ? AND guild_id = ?").bind(body.afkSoundId, gid).first();
      if (!snd) throw badRequest("AFK sesi bu sunucunun soundboard'unda olmalı");
    }
    const sets: string[] = [];
    const vals: (string | null)[] = [];
    if (body.name) (sets.push("name = ?"), vals.push(body.name));
    if (body.afkChannelId !== undefined) (sets.push("afk_channel_id = ?"), vals.push(body.afkChannelId));
    if (body.afkSoundId !== undefined) (sets.push("afk_sound_id = ?"), vals.push(body.afkSoundId));
    if (sets.length) await c.env.DB.prepare(`UPDATE guilds SET ${sets.join(", ")} WHERE id = ?`).bind(...vals, gid).run();
    await publish(c.env, gid, { t: "guild.update" });
    return c.json({ ok: true });
  })

  .post("/:gid/icon", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    const data = await requireGuildPermission(c.env.DB, gid, me.id, Permission.MANAGE_SERVER);
    const img = await readImageUpload(c, L.AVATAR_MAX_BYTES);
    const { key } = await putBlob(c.env, { kind: "icon", id: gid, ownerId: me.id, bytes: img.data, mime: img.mime });
    await c.env.DB.prepare("UPDATE guilds SET icon_key = ? WHERE id = ?").bind(key, gid).run();
    if (data.guild.icon_key) await deleteBlob(c.env, data.guild.icon_key).catch(() => {});
    await publish(c.env, gid, { t: "guild.update" });
    return c.json({ ok: true });
  })

  // ---------------- Kanallar ----------------
  .post("/:gid/channels", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    await requireGuildPermission(c.env.DB, gid, me.id, Permission.MANAGE_CHANNELS);
    await enforceRateLimit(c.env, `write:${me.id}`, RATE_RULES.writeByUser);
    const body = await parseJson(c, CreateChannelInput);
    if (body.parentId) {
      const parent = await c.env.DB.prepare("SELECT type FROM channels WHERE id = ? AND guild_id = ?").bind(body.parentId, gid).first<{ type: string }>();
      if (!parent || parent.type !== "category") throw badRequest("Üst öğe bu sunucuda bir kategori olmalı");
      if (body.type === "category") throw badRequest("Kategori başka kategori içine konamaz");
    }
    const pos = await c.env.DB.prepare("SELECT COALESCE(MAX(position), -1) + 1 AS p FROM channels WHERE guild_id = ? AND parent_id IS ?")
      .bind(gid, body.parentId ?? null)
      .first<{ p: number }>();
    const row: ChannelRow = {
      id: newId(),
      guild_id: gid,
      type: body.type,
      name: body.type === "text" ? body.name.toLowerCase().replace(/\s+/g, "-") : body.name,
      parent_id: body.parentId ?? null,
      position: pos?.p ?? 0,
      is_private: body.isPrivate ? 1 : 0,
    };
    const stmts = [
      c.env.DB.prepare("INSERT INTO channels (id, guild_id, type, name, parent_id, position, is_private, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)").bind(
        row.id, gid, row.type, row.name, row.parent_id, row.position, row.is_private, Date.now(),
      ),
    ];
    if (body.isPrivate) {
      // Özel kanal: @everyone'dan VIEW_CHANNEL kaldırılır, oluşturan kişiye açıkça verilir.
      stmts.push(
        c.env.DB.prepare("INSERT INTO channel_overwrites (channel_id, target_type, target_id, allow, deny) VALUES (?, 'role', ?, 0, ?)").bind(row.id, gid, Permission.VIEW_CHANNEL),
        c.env.DB.prepare("INSERT INTO channel_overwrites (channel_id, target_type, target_id, allow, deny) VALUES (?, 'member', ?, ?, 0)").bind(row.id, me.id, Permission.VIEW_CHANNEL),
      );
    }
    await c.env.DB.batch(stmts);
    await publish(c.env, gid, { t: "channel.create", channel: channelDto(row) }, row.id);
    return c.json({ ...channelDto(row), myPermissions: ALL_PERMISSIONS }, 201);
  })

  // ---------------- Roller ----------------
  .post("/:gid/roles", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    const data = await requireGuildPermission(c.env.DB, gid, me.id, Permission.MANAGE_ROLES);
    const body = await parseJson(
      c,
      z.object({
        name: z.string().trim().min(1).max(32),
        color: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullable().optional(),
        permissions: z.number().int().min(0).max(ALL_PERMISSIONS),
      }),
    );
    // Kimse kendinde olmayan bir izni başkasına veremez.
    if ((body.permissions & ~data.perms) !== 0) throw forbidden("Sahip olmadığın izinleri veremezsin");
    // Yeni roller @everyone'ın hemen üstüne (1) eklenir; sıralama ayrı uç noktayla yapılır.
    const position = 1;
    const id = newId();
    await c.env.DB.prepare("INSERT INTO roles (id, guild_id, name, color, position, permissions, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)")
      .bind(id, gid, body.name, body.color ?? null, position, body.permissions, Date.now())
      .run();
    await hubStub(c.env, gid).invalidate();
    return c.json({ id, guildId: gid, name: body.name, color: body.color ?? null, position, permissions: body.permissions } satisfies RoleDTO, 201);
  })

  .patch("/:gid/roles/:rid", async (c) => {
    const me = c.get("user");
    const { gid, rid } = c.req.param();
    const data = await requireGuildPermission(c.env.DB, gid, me.id, Permission.MANAGE_ROLES);
    const role = data.ctx.roles.find((r) => r.id === rid);
    if (!role) throw notFound("Rol bulunamadı");
    const myTop = highestRolePosition(data.ctx);
    // @everyone düzenlenebilir (yalnızca izinler); diğer roller hiyerarşiye tabi
    if (rid !== gid && !data.ctx.isOwner && role.position >= myTop) throw forbidden("Kendi rolünle eşit veya üstteki bir rolü düzenleyemezsin");
    const body = await parseJson(c, UpdateRoleInput);
    if (body.permissions !== undefined && (body.permissions & ~data.perms) !== 0) throw forbidden("Sahip olmadığın izinleri veremezsin");
    if (body.position !== undefined && (rid === gid || (!data.ctx.isOwner && body.position >= myTop))) throw forbidden("Bu konuma taşıyamazsın");
    await c.env.DB.prepare(
      "UPDATE roles SET name = COALESCE(?, name), color = CASE WHEN ? THEN ? ELSE color END, permissions = COALESCE(?, permissions), position = COALESCE(?, position) WHERE id = ? AND guild_id = ?",
    )
      .bind(rid === gid ? null : (body.name ?? null), body.color !== undefined ? 1 : 0, body.color ?? null, body.permissions ?? null, body.position ?? null, rid, gid)
      .run();
    await hubStub(c.env, gid).invalidate();
    await publish(c.env, gid, { t: "guild.update" });
    return c.json({ ok: true });
  })

  .delete("/:gid/roles/:rid", async (c) => {
    const me = c.get("user");
    const { gid, rid } = c.req.param();
    const data = await requireGuildPermission(c.env.DB, gid, me.id, Permission.MANAGE_ROLES);
    const role = data.ctx.roles.find((r) => r.id === rid);
    if (!role || rid === gid) throw notFound("Rol bulunamadı");
    if (!data.ctx.isOwner && role.position >= highestRolePosition(data.ctx)) throw forbidden();
    await c.env.DB.batch([
      c.env.DB.prepare("DELETE FROM channel_overwrites WHERE target_type = 'role' AND target_id = ?").bind(rid),
      c.env.DB.prepare("DELETE FROM roles WHERE id = ? AND guild_id = ?").bind(rid, gid),
    ]);
    await hubStub(c.env, gid).invalidate();
    await publish(c.env, gid, { t: "guild.update" });
    return c.json({ ok: true });
  })

  // ---------------- Yasaklar ----------------
  .get("/:gid/bans", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    await requireGuildPermission(c.env.DB, gid, me.id, Permission.BAN_MEMBERS);
    const { results } = await c.env.DB.prepare(
      "SELECT u.id, u.username, u.display_name, u.avatar_key, u.bio, u.status, b.reason, b.created_at FROM bans b JOIN users u ON u.id = b.user_id WHERE b.guild_id = ?",
    )
      .bind(gid)
      .all<UserRow & { reason: string | null; created_at: number }>();
    const origin = new URL(c.req.url).origin;
    return c.json(await Promise.all(results.map(async (r) => ({ user: await userDto(c.env, origin, r), reason: r.reason, createdAt: r.created_at }))));
  })
  .put("/:gid/bans/:uid", async (c) => {
    const me = c.get("user");
    const { gid, uid } = c.req.param();
    const data = await requireGuildPermission(c.env.DB, gid, me.id, Permission.BAN_MEMBERS);
    if (uid === me.id) throw badRequest("Kendini yasaklayamazsın");
    const target = await loadMemberContextOrNull(c.env.DB, gid, uid);
    if (target && (target.ctx.isOwner || highestRolePosition(target.ctx) >= highestRolePosition(data.ctx))) {
      throw forbidden("Kendinle eşit veya üst roldeki birini yasaklayamazsın");
    }
    const body = await parseJson(c, BanInput);
    await c.env.DB.batch([
      c.env.DB.prepare("INSERT OR REPLACE INTO bans (guild_id, user_id, reason, created_by, created_at) VALUES (?, ?, ?, ?, ?)").bind(gid, uid, body.reason ?? null, me.id, Date.now()),
      c.env.DB.prepare("DELETE FROM guild_members WHERE guild_id = ? AND user_id = ?").bind(gid, uid),
    ]);
    await hubStub(c.env, gid).disconnectUser(uid, "Sunucudan yasaklandın");
    await publishUsers(c.env, [uid], { t: "guild.remove", guildId: gid });
    await publish(c.env, gid, { t: "guild.update" });
    return c.json({ ok: true });
  })
  .delete("/:gid/bans/:uid", async (c) => {
    const me = c.get("user");
    const { gid, uid } = c.req.param();
    await requireGuildPermission(c.env.DB, gid, me.id, Permission.BAN_MEMBERS);
    await c.env.DB.prepare("DELETE FROM bans WHERE guild_id = ? AND user_id = ?").bind(gid, uid).run();
    return c.json({ ok: true });
  })

  .put("/:gid/members/:uid/roles/:rid", async (c) => assignRole(c, true))
  .delete("/:gid/members/:uid/roles/:rid", async (c) => assignRole(c, false))

  // Üyeyi at (KICK_MEMBERS)
  .delete("/:gid/members/:uid", async (c) => {
    const me = c.get("user");
    const { gid, uid } = c.req.param();
    if (uid === me.id) {
      // Kendi isteğiyle ayrılma
      const g = await c.env.DB.prepare("SELECT owner_id FROM guilds WHERE id = ?").bind(gid).first<{ owner_id: string }>();
      if (g?.owner_id === me.id) throw badRequest("Sahip sunucudan ayrılamaz");
    } else {
      const data = await requireGuildPermission(c.env.DB, gid, me.id, Permission.KICK_MEMBERS);
      const target = await requireGuildPermission(c.env.DB, gid, uid);
      if (target.ctx.isOwner || highestRolePosition(target.ctx) >= highestRolePosition(data.ctx)) {
        throw forbidden("Kendinle eşit veya üst roldeki birini atamazsın");
      }
    }
    await c.env.DB.prepare("DELETE FROM guild_members WHERE guild_id = ? AND user_id = ?").bind(gid, uid).run();
    await hubStub(c.env, gid).disconnectUser(uid);
    await publishUsers(c.env, [uid], { t: "guild.remove", guildId: gid });
    await publish(c.env, gid, { t: "guild.update" });
    return c.json({ ok: true });
  })

  // ---------------- Davetler ----------------
  .post("/:gid/invites", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    await requireGuildPermission(c.env.DB, gid, me.id, Permission.CREATE_INVITE);
    const body = await parseJson(c, CreateInviteInput);
    const code = randomCode(10);
    const expiresAt = body.expiresInHours ? Date.now() + body.expiresInHours * 3600_000 : null;
    await c.env.DB.prepare("INSERT INTO invites (code, guild_id, creator_id, max_uses, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?)")
      .bind(code, gid, me.id, body.maxUses ?? 0, expiresAt, Date.now())
      .run();
    return c.json({ code, guildId: gid, maxUses: body.maxUses ?? 0, expiresAt }, 201);
  })

  // ---------------- Gateway bileti ----------------
  .post("/:gid/gateway-ticket", async (c) => {
    const me = c.get("user");
    const gid = c.req.param("gid");
    await requireGuildPermission(c.env.DB, gid, me.id);
    const ticket = await signToken(appSecret(c.env), {
      uid: me.id,
      gid,
      exp: Date.now() + LIMITS.GATEWAY_TICKET_TTL_MS,
    });
    return c.json({ ticket });
  });

async function assignRole(c: import("hono").Context<AppBindings>, add: boolean) {
  const me = c.get("user");
  const { gid, uid, rid } = c.req.param() as { gid: string; uid: string; rid: string };
  const data = await requireGuildPermission(c.env.DB, gid, me.id, Permission.MANAGE_ROLES);
  const role = data.ctx.roles.find((r) => r.id === rid);
  if (!role || rid === gid) throw notFound("Rol bulunamadı");
  if (!data.ctx.isOwner && role.position >= highestRolePosition(data.ctx)) {
    throw forbidden("Kendi rolünle eşit veya üstteki bir rolü yönetemezsin");
  }
  // Hedef üye olmalı (değilse 404)
  await requireGuildPermission(c.env.DB, gid, uid);
  if (add) {
    await c.env.DB.prepare("INSERT OR IGNORE INTO member_roles (guild_id, user_id, role_id) VALUES (?, ?, ?)").bind(gid, uid, rid).run();
  } else {
    await c.env.DB.prepare("DELETE FROM member_roles WHERE guild_id = ? AND user_id = ? AND role_id = ?").bind(gid, uid, rid).run();
  }
  await hubStub(c.env, gid).invalidate();
  await publish(c.env, gid, { t: "guild.update" });
  return c.json({ ok: true });
}

// ---------------- Kanal düzenleme/silme (kanal id ile) ----------------
export const channelRoutes = new Hono<AppBindings>()
  .use(requireAuth)
  .patch("/:cid", async (c) => {
    const me = c.get("user");
    const { channel } = await requireChannelPermission(c.env.DB, c.req.param("cid"), me.id, Permission.MANAGE_CHANNELS);
    const body = await parseJson(c, UpdateChannelInput);
    if (body.parentId) {
      const parent = await c.env.DB.prepare("SELECT type FROM channels WHERE id = ? AND guild_id = ?").bind(body.parentId, channel.guild_id).first<{ type: string }>();
      if (!parent || parent.type !== "category" || channel.type === "category") throw badRequest("Geçersiz üst kategori");
    }
    const updated: ChannelRow = {
      ...channel,
      name: body.name ?? channel.name,
      parent_id: body.parentId !== undefined ? body.parentId : channel.parent_id,
      position: body.position ?? channel.position,
    };
    await c.env.DB.prepare("UPDATE channels SET name = ?, parent_id = ?, position = ? WHERE id = ?")
      .bind(updated.name, updated.parent_id, updated.position, channel.id)
      .run();
    await publish(c.env, channel.guild_id, { t: "channel.update", channel: channelDto(updated) }, channel.id);
    return c.json(channelDto(updated));
  })
  .delete("/:cid", async (c) => {
    const me = c.get("user");
    const { channel } = await requireChannelPermission(c.env.DB, c.req.param("cid"), me.id, Permission.MANAGE_CHANNELS);
    // Yayın, silmeden önce (görme izni hesaplanabilsin diye) yapılır.
    await publish(c.env, channel.guild_id, { t: "channel.delete", channelId: channel.id }, channel.id);
    await c.env.DB.prepare("DELETE FROM channels WHERE id = ?").bind(channel.id).run();
    return c.json({ ok: true });
  })
  // Kanal izin overwrite'ı yaz (rol veya üye)
  .put("/:cid/overwrites/:type/:target", async (c) => {
    const me = c.get("user");
    const { cid, type, target } = c.req.param();
    if (type !== "role" && type !== "member") throw badRequest("Tür role veya member olmalı");
    const { channel, member } = await requireChannelPermission(c.env.DB, cid, me.id, Permission.MANAGE_ROLES);
    const base = computeBasePermissions(member.ctx);
    const body = await parseJson(c, z.object({ allow: z.number().int().min(0), deny: z.number().int().min(0) }));
    if (((body.allow | body.deny) & ~base) !== 0) throw forbidden("Sahip olmadığın izinleri düzenleyemezsin");
    await c.env.DB.prepare(
      `INSERT INTO channel_overwrites (channel_id, target_type, target_id, allow, deny) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT (channel_id, target_type, target_id) DO UPDATE SET allow = excluded.allow, deny = excluded.deny`,
    )
      .bind(cid, type, target, body.allow, body.deny)
      .run();
    await hubStub(c.env, channel.guild_id).invalidate();
    await publish(c.env, channel.guild_id, { t: "guild.update" });
    return c.json({ ok: true, overwrites: await loadOverwrites(c.env.DB, cid) });
  })
  .delete("/:cid/overwrites/:type/:target", async (c) => {
    const me = c.get("user");
    const { cid, type, target } = c.req.param();
    const { channel } = await requireChannelPermission(c.env.DB, cid, me.id, Permission.MANAGE_ROLES);
    await c.env.DB.prepare("DELETE FROM channel_overwrites WHERE channel_id = ? AND target_type = ? AND target_id = ?").bind(cid, type, target).run();
    await hubStub(c.env, channel.guild_id).invalidate();
    await publish(c.env, channel.guild_id, { t: "guild.update" });
    return c.json({ ok: true });
  });

// ---------------- Davet kabul ----------------
export const inviteRoutes = new Hono<AppBindings>()
  .use(requireAuth)
  .post("/:code/accept", async (c) => {
    const me = c.get("user");
    const code = c.req.param("code");
    const inv = await c.env.DB.prepare("SELECT code, guild_id, max_uses, uses, expires_at FROM invites WHERE code = ?")
      .bind(code)
      .first<{ code: string; guild_id: string; max_uses: number; uses: number; expires_at: number | null }>();
    if (!inv || (inv.expires_at && inv.expires_at < Date.now()) || (inv.max_uses > 0 && inv.uses >= inv.max_uses)) {
      throw notFound("Davet geçersiz veya süresi dolmuş");
    }
    const banned = await c.env.DB.prepare("SELECT 1 FROM bans WHERE guild_id = ? AND user_id = ?").bind(inv.guild_id, me.id).first();
    if (banned) throw forbidden("Bu sunucudan yasaklandın");
    const already = await c.env.DB.prepare("SELECT 1 FROM guild_members WHERE guild_id = ? AND user_id = ?").bind(inv.guild_id, me.id).first();
    if (already) throw conflict("Zaten bu sunucunun üyesisin");
    // Kullanım sayısı koşullu artırılır (yarış durumuna karşı)
    const upd = await c.env.DB.prepare("UPDATE invites SET uses = uses + 1 WHERE code = ? AND (max_uses = 0 OR uses < max_uses)").bind(code).run();
    if (!upd.meta.changes) throw notFound("Davet geçersiz veya süresi dolmuş");
    await c.env.DB.prepare("INSERT INTO guild_members (guild_id, user_id, joined_at) VALUES (?, ?, ?)").bind(inv.guild_id, me.id, Date.now()).run();
    await publish(c.env, inv.guild_id, { t: "member.join", userId: me.id });
    return c.json({ guildId: inv.guild_id });
  });
