import { SELF } from "cloudflare:test";
import type { ServerEvent } from "@yanki/shared";

export const BASE = "http://yanki.test";

export async function api<T = any>(
  path: string,
  opts: { method?: string; token?: string; body?: unknown; form?: FormData } = {},
): Promise<{ status: number; data: T }> {
  // Üretimde CF-Connecting-IP'yi Cloudflare yazar; testte IP başına auth
  // rate limit'ine takılmamak için her isteğe farklı IP verilir.
  const headers: Record<string, string> = { "CF-Connecting-IP": `10.0.${counter % 250}.${Math.floor(Math.random() * 250)}` };
  if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
  let body: BodyInit | undefined;
  if (opts.form) body = opts.form;
  else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  const res = await SELF.fetch(BASE + path, { method: opts.method ?? (body ? "POST" : "GET"), headers, body });
  const text = await res.text();
  let data: any = text;
  try {
    data = JSON.parse(text);
  } catch {
    /* metin */
  }
  return { status: res.status, data };
}

let counter = 0;
export async function registerUser(name?: string) {
  const username = name ?? `user${Date.now() % 100000}${counter++}`;
  const r = await api<{ token: string; user: { id: string } }>("/api/auth/register", {
    body: { username, displayName: username.toUpperCase(), password: "correct horse battery" },
  });
  if (r.status !== 201) throw new Error(`register failed ${r.status} ${JSON.stringify(r.data)}`);
  return { token: r.data.token, id: r.data.user.id, username };
}

/** Test için WebSocket istemcisi: gelen olayları kuyrukta tutar. */
export class TestSocket {
  events: ServerEvent[] = [];
  /** Gelen tüm olay türleri, geliş sırasıyla (sıralama testleri için) */
  received: string[] = [];
  private waiters: { pred: (e: ServerEvent) => boolean; resolve: (e: ServerEvent) => void }[] = [];
  constructor(public ws: WebSocket) {
    ws.addEventListener("message", (m) => {
      const ev = JSON.parse(m.data as string) as ServerEvent;
      this.received.push(ev.t);
      const i = this.waiters.findIndex((w) => w.pred(ev));
      if (i >= 0) {
        const [w] = this.waiters.splice(i, 1);
        w!.resolve(ev);
      } else {
        this.events.push(ev);
      }
    });
  }
  send(ev: unknown) {
    this.ws.send(JSON.stringify(ev));
  }
  next<T extends ServerEvent["t"]>(t: T, pred: (e: Extract<ServerEvent, { t: T }>) => boolean = () => true, timeoutMs = 3000): Promise<Extract<ServerEvent, { t: T }>> {
    const match = (e: ServerEvent) => e.t === t && pred(e as Extract<ServerEvent, { t: T }>);
    const idx = this.events.findIndex(match);
    if (idx >= 0) return Promise.resolve(this.events.splice(idx, 1)[0] as Extract<ServerEvent, { t: T }>);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`'${t}' olayı gelmedi`)), timeoutMs);
      this.waiters.push({
        pred: match,
        resolve: (e) => {
          clearTimeout(timer);
          resolve(e as Extract<ServerEvent, { t: T }>);
        },
      });
    });
  }
  /** Belirli süre içinde bu olayın GELMEDİĞİNİ doğrular. */
  async expectNone(t: ServerEvent["t"], ms = 300): Promise<void> {
    await new Promise((r) => setTimeout(r, ms));
    if (this.events.some((e) => e.t === t)) throw new Error(`beklenmeyen '${t}' olayı`);
  }
  close() {
    this.ws.close(1000);
  }
}

export async function connect(token: string, guildId: string): Promise<TestSocket> {
  const t = await api<{ ticket: string }>(`/api/guilds/${guildId}/gateway-ticket`, { method: "POST", token });
  if (t.status !== 200) throw new Error(`ticket ${t.status}`);
  const res = await SELF.fetch(`${BASE}/api/guilds/${guildId}/gateway?ticket=${encodeURIComponent(t.data.ticket)}`, {
    headers: { Upgrade: "websocket" },
  });
  if (res.status !== 101 || !res.webSocket) throw new Error(`upgrade ${res.status}`);
  const ws = res.webSocket;
  const sock = new TestSocket(ws);
  ws.accept();
  await sock.next("ready");
  return sock;
}

/** 0.1 sn sessizlikten oluşan geçerli bir WAV dosyası. */
export function tinyWav(): Uint8Array {
  const sampleRate = 8000;
  const samples = 800;
  const dataSize = samples * 2;
  const buf = new ArrayBuffer(44 + dataSize);
  const v = new DataView(buf);
  const str = (o: number, s: string) => [...s].forEach((ch, i) => v.setUint8(o + i, ch.charCodeAt(0)));
  str(0, "RIFF");
  v.setUint32(4, 36 + dataSize, true);
  str(8, "WAVE");
  str(12, "fmt ");
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, sampleRate, true);
  v.setUint32(28, sampleRate * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  str(36, "data");
  v.setUint32(40, dataSize, true);
  return new Uint8Array(buf);
}

/** Kişisel (kullanıcı) gateway'ine bağlanır: arkadaşlık ve DM olayları. */
export async function connectUser(token: string): Promise<TestSocket> {
  const t = await api<{ ticket: string }>(`/api/gateway-ticket`, { method: "POST", token });
  if (t.status !== 200) throw new Error(`ticket ${t.status}`);
  const res = await SELF.fetch(`${BASE}/api/gateway?ticket=${encodeURIComponent(t.data.ticket)}`, { headers: { Upgrade: "websocket" } });
  if (res.status !== 101 || !res.webSocket) throw new Error(`upgrade ${res.status}`);
  const sock = new TestSocket(res.webSocket);
  res.webSocket.accept();
  await sock.next("ready");
  return sock;
}

/** 1x1 PNG */
export function tinyPng(): Uint8Array {
  return Uint8Array.from(
    atob("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="),
    (c) => c.charCodeAt(0),
  );
}

export async function setupGuild() {
  const a = await registerUser();
  const b = await registerUser();
  const gid = (await api("/api/guilds", { token: a.token, body: { name: "Ekip" } })).data.id as string;
  const code = (await api(`/api/guilds/${gid}/invites`, { token: a.token, body: {} })).data.code;
  await api(`/api/invites/${code}/accept`, { method: "POST", token: b.token });
  const detail = (await api(`/api/guilds/${gid}`, { token: a.token })).data;
  const text = detail.channels.find((c: any) => c.type === "text").id as string;
  const voice = detail.channels.find((c: any) => c.type === "voice").id as string;
  return { a, b, gid, text, voice, detail };
}
