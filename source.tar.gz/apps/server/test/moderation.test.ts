import { describe, expect, it } from "vitest";
import { Permission } from "@yanki/shared";
import { api, connect, registerUser, setupGuild, tinyWav } from "./helpers";

describe("roller ve yasaklar", () => {
  it("rol düzenleme, silme ve hiyerarşi", async () => {
    const { a, b, gid, detail } = await setupGuild();
    const role = await api(`/api/guilds/${gid}/roles`, { token: a.token, body: { name: "DJ", color: "#ff8800", permissions: Permission.MANAGE_SOUNDBOARD } });
    expect(role.status).toBe(201);
    expect((await api(`/api/guilds/${gid}/roles/${role.data.id}`, { method: "PATCH", token: a.token, body: { name: "Süper DJ", permissions: Permission.MANAGE_SOUNDBOARD | Permission.PLAY_SOUNDS } })).status).toBe(200);
    const after = await api(`/api/guilds/${gid}`, { token: a.token });
    expect(after.data.roles.find((r: any) => r.id === role.data.id)).toMatchObject({ name: "Süper DJ", color: "#ff8800" });
    // Üye rol düzenleyemez
    expect((await api(`/api/guilds/${gid}/roles/${role.data.id}`, { method: "PATCH", token: b.token, body: { name: "x" } })).status).toBe(403);
    // Moderator, kendinden üstteki Admin rolünü düzenleyemez
    const mod = detail.roles.find((r: any) => r.name === "Moderator");
    const admin = detail.roles.find((r: any) => r.name === "Admin");
    await api(`/api/guilds/${gid}/roles/${mod.id}`, { method: "PATCH", token: a.token, body: { permissions: mod.permissions | Permission.MANAGE_ROLES } });
    await api(`/api/guilds/${gid}/members/${b.id}/roles/${mod.id}`, { method: "PUT", token: a.token });
    expect((await api(`/api/guilds/${gid}/roles/${admin.id}`, { method: "PATCH", token: b.token, body: { name: "x" } })).status).toBe(403);
    expect((await api(`/api/guilds/${gid}/roles/${role.data.id}`, { method: "DELETE", token: a.token })).status).toBe(200);
    expect((await api(`/api/guilds/${gid}`, { token: a.token })).data.roles.some((r: any) => r.id === role.data.id)).toBe(false);
    // Sahip için kanal overwrite'ları görünür, üyeye görünmez
    expect((await api(`/api/guilds/${gid}`, { token: a.token })).data.channels[0].overwrites).toBeDefined();
  });

  it("yasaklanan üye atılır, bağlantısı kesilir ve davetle geri dönemez", async () => {
    const { a, b, gid } = await setupGuild();
    const wb = await connect(b.token, gid);
    expect((await api(`/api/guilds/${gid}/bans/${b.id}`, { method: "PUT", token: b.token, body: {} })).status).toBe(403);
    expect((await api(`/api/guilds/${gid}/bans/${b.id}`, { method: "PUT", token: a.token, body: { reason: "spam" } })).status).toBe(200);
    await new Promise((r) => setTimeout(r, 100));
    expect(wb.ws.readyState).toBeGreaterThanOrEqual(2); // kapanıyor/kapandı
    expect((await api(`/api/guilds/${gid}`, { token: b.token })).status).toBe(404);
    const code = (await api(`/api/guilds/${gid}/invites`, { token: a.token, body: {} })).data.code;
    expect((await api(`/api/invites/${code}/accept`, { method: "POST", token: b.token })).status).toBe(403);
    const bans = await api(`/api/guilds/${gid}/bans`, { token: a.token });
    expect(bans.data).toMatchObject([{ user: { id: b.id }, reason: "spam" }]);
    await api(`/api/guilds/${gid}/bans/${b.id}`, { method: "DELETE", token: a.token });
    expect((await api(`/api/invites/${code}/accept`, { method: "POST", token: b.token })).status).toBe(200);
  });
});

describe("ses moderasyonu ve ekran paylaşımı", () => {
  it("sunucu susturma/sağırlaştırma kalıcıdır; sağırlaştırılan soundboard duymaz", async () => {
    const { a, b, gid, voice } = await setupGuild();
    const wa = await connect(a.token, gid);
    const wb = await connect(b.token, gid);
    wb.send({ t: "voice.join", channelId: voice });
    await wa.next("voice.update", (e) => e.participant.userId === b.id);

    // Yetkisiz üye başkasını susturamaz
    wb.send({ t: "voice.moderate", userId: a.id, mute: true });
    expect((await wb.next("error")).ref).toBe("voice.moderate");

    wa.send({ t: "voice.moderate", userId: b.id, mute: true, deafen: true });
    const u = await wb.next("voice.update", (e) => e.participant.userId === b.id && e.participant.serverMute);
    expect(u.participant).toMatchObject({ serverMute: true, serverDeaf: true });
    await wa.next("voice.update", (e) => e.participant.userId === b.id && e.participant.serverMute);

    // Konuşma olayı susturulmuşken yok sayılır
    wb.send({ t: "voice.speaking", speaking: true });
    await wa.expectNone("voice.update", 200);

    // Ayrılıp gelince de susturulmuş kalır
    wb.send({ t: "voice.leave" });
    await wa.next("voice.leave");
    wb.send({ t: "voice.join", channelId: voice });
    expect((await wa.next("voice.update", (e) => e.participant.userId === b.id)).participant.serverMute).toBe(true);

    // Sağırlaştırılmış B soundboard sesini almaz, odadaki A alır
    const fd = new FormData();
    fd.append("file", new File([tinyWav()], "bip.wav"));
    fd.append("name", "Bip");
    fd.append("guildId", gid);
    const sound = (await api("/api/sounds", { token: a.token, form: fd })).data;
    wa.send({ t: "voice.join", channelId: voice });
    await wb.next("voice.update", (e) => e.participant.userId === a.id);
    wa.send({ t: "sound.play", soundId: sound.id });
    await wa.next("sound.play");
    await wb.expectNone("sound.play");

    wa.send({ t: "voice.moderate", userId: b.id, mute: false, deafen: false });
    expect((await wa.next("voice.update", (e) => e.participant.userId === b.id && !e.participant.serverMute)).participant.serverDeaf).toBe(false);
    wa.close();
    wb.close();
  });

  it("taşıma ve sesten atma", async () => {
    const { a, b, gid, voice } = await setupGuild();
    const second = (await api(`/api/guilds/${gid}/channels`, { token: a.token, body: { name: "Oyun", type: "voice" } })).data;
    const wa = await connect(a.token, gid);
    const wb = await connect(b.token, gid);
    wb.send({ t: "voice.join", channelId: voice });
    await wa.next("voice.update", (e) => e.participant.userId === b.id);

    wa.send({ t: "voice.move", userId: b.id, channelId: second.id });
    expect(await wb.next("voice.moved")).toMatchObject({ channelId: second.id, byUserId: a.id });
    // Sıra önemli: taşınan kişi "voice.moved"u kendi "voice.leave" olayından ÖNCE almalı,
    // yoksa istemci sesli oturumu kapatıp yeni kanala hiç geçmez.
    await wb.next("voice.leave", (e) => e.userId === b.id);
    const order = wb.received.filter((t) => t === "voice.moved" || t === "voice.leave");
    expect(order.slice(-2)).toEqual(["voice.moved", "voice.leave"]);
    await wa.next("voice.leave", (e) => e.userId === b.id);

    wb.send({ t: "voice.join", channelId: second.id });
    await wa.next("voice.update", (e) => e.participant.userId === b.id && e.participant.channelId === second.id);
    wa.send({ t: "voice.move", userId: b.id, channelId: null });
    expect((await wb.next("voice.moved")).channelId).toBeNull();

    // Üye, sahibini taşıyamaz
    wa.send({ t: "voice.join", channelId: voice });
    await wb.next("voice.update", (e) => e.participant.userId === a.id);
    wb.send({ t: "voice.move", userId: a.id, channelId: null });
    expect((await wb.next("error")).ref).toBe("voice.move");
    wa.close();
    wb.close();
  });

  it("ekran paylaşımı durumu ve yayın sinyalleri", async () => {
    const { a, b, gid, voice } = await setupGuild();
    const wa = await connect(a.token, gid);
    const wb = await connect(b.token, gid);
    wa.send({ t: "screen.start", preset: "1080p30", audio: false }); // seste değilken yok sayılır
    wa.send({ t: "voice.join", channelId: voice });
    wb.send({ t: "voice.join", channelId: voice });
    await wa.next("voice.update", (e) => e.participant.userId === b.id);

    wa.send({ t: "screen.start", preset: "1080p30", audio: true });
    const st = await wb.next("voice.update", (e) => e.participant.userId === a.id && e.participant.streaming);
    expect(st.participant.stream).toEqual({ preset: "1080p30", audio: true });

    // İzleyici izleme isteği gönderir, yayıncı teklif döner
    wb.send({ t: "rtc.signal", to: a.id, stream: "screen-down", data: { kind: "watch" } });
    expect(await wa.next("rtc.signal")).toMatchObject({ from: b.id, stream: "screen-down", data: { kind: "watch" } });
    wa.send({ t: "rtc.signal", to: b.id, stream: "screen-up", data: { kind: "description", type: "offer", sdp: "v=0 ekran" } });
    expect((await wb.next("rtc.signal")).stream).toBe("screen-up");

    wa.send({ t: "screen.stop" });
    expect((await wb.next("voice.update", (e) => e.participant.userId === a.id && !e.participant.streaming)).participant.stream).toBeNull();

    // SCREEN_SHARE izni kaldırılınca başlatılamaz
    await api(`/api/channels/${voice}/overwrites/member/${b.id}`, { method: "PUT", token: a.token, body: { allow: 0, deny: Permission.SCREEN_SHARE } });
    await new Promise((r) => setTimeout(r, 50));
    wb.send({ t: "screen.start", preset: "720p30", audio: false });
    expect((await wb.next("error")).ref).toBe("screen.start");
    wa.close();
    wb.close();
  });
});

describe("genel depolama", () => {
  it("üye olmayan kullanıcı sunucu sesi yükleyemez", async () => {
    const { gid } = await setupGuild();
    const outsider = await registerUser();
    const fd = new FormData();
    fd.append("file", new File([new Uint8Array([0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x41, 0x56, 0x45, 0, 0, 0, 0])], "x.wav"));
    fd.append("name", "x");
    fd.append("guildId", gid);
    expect((await api("/api/sounds", { token: outsider.token, form: fd })).status).toBe(404);
  });
});
