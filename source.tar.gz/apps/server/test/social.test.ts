import { SELF } from "cloudflare:test";
import { describe, expect, it } from "vitest";
import { api, connectUser, registerUser, setupGuild, tinyPng } from "./helpers";

describe("arkadaşlar ve engelleme", () => {
  it("istek, kabul, gerçek zamanlı bildirim ve arkadaşlıktan çıkarma", async () => {
    const a = await registerUser();
    const b = await registerUser();
    let wb = await connectUser(b.token);

    const req = await api("/api/friends", { token: a.token, body: { username: b.username } });
    expect(req.status).toBe(201);
    expect(req.data.state).toBe("outgoing");
    const ev = await wb.next("friend.update");
    expect(ev.friend).toMatchObject({ state: "incoming", user: { id: a.id } });

    // Tekrar gönderme çakışır; olmayan kullanıcı 404
    expect((await api("/api/friends", { token: a.token, body: { username: b.username } })).status).toBe(409);
    expect((await api("/api/friends", { token: a.token, body: { username: "yokboyle" } })).status).toBe(404);

    const wa = await connectUser(a.token);
    expect((await api(`/api/friends/${a.id}`, { method: "PUT", token: b.token })).data.state).toBe("friend");
    expect((await wa.next("friend.update", (e) => e.friend.state === "friend")).friend.user.id).toBe(b.id);
    // Kabul anında B'nin çevrimiçi olduğu A'ya bildirilir
    expect((await wa.next("presence", (e) => e.userId === b.id)).status).toBe("online");

    // Arkadaş çevrimiçi/çevrimdışı durumu kişisel gateway'den gelir
    wb.close();
    expect((await wa.next("presence", (e) => e.userId === b.id)).status).toBe("offline");
    wb = await connectUser(b.token);
    expect((await wa.next("presence", (e) => e.userId === b.id)).status).toBe("online");

    const list = await api("/api/friends", { token: a.token });
    expect(list.data.map((f: any) => [f.user.id, f.state])).toEqual([[b.id, "friend"]]);

    expect((await api(`/api/friends/${b.id}`, { method: "DELETE", token: a.token })).status).toBe(200);
    expect((await wb.next("friend.remove")).userId).toBe(a.id);
    expect((await api("/api/friends", { token: b.token })).data).toEqual([]);
    wa.close();
    wb.close();
  });

  it("engellenen kişi istek gönderemez, DM yazamaz", async () => {
    const { a, b } = await setupGuild();
    const dm = await api("/api/dms", { token: a.token, body: { userIds: [b.id] } });
    expect(dm.status).toBe(201);
    expect((await api(`/api/blocks/${a.id}`, { method: "PUT", token: b.token })).status).toBe(200);
    expect((await api("/api/friends", { token: a.token, body: { username: b.username } })).status).toBe(404);
    expect((await api(`/api/dms/${dm.data.id}/messages`, { token: a.token, body: { content: "selam" } })).status).toBe(403);
    expect((await api(`/api/dms/${dm.data.id}/messages`, { token: b.token, body: { content: "selam" } })).status).toBe(403);
    expect((await api("/api/friends", { token: b.token })).data.map((f: any) => f.state)).toEqual(["blocked"]);
    // Engeli kaldırınca tekrar yazılabilir
    await api(`/api/blocks/${a.id}`, { method: "DELETE", token: b.token });
    expect((await api(`/api/dms/${dm.data.id}/messages`, { token: a.token, body: { content: "selam" } })).status).toBe(201);
  });
});

describe("özel mesajlar", () => {
  it("birebir DM tekildir, mesajlar gerçek zamanlı gelir, üye olmayan göremez", async () => {
    const { a, b } = await setupGuild(); // ortak sunucu → arkadaş olmadan DM açılabilir
    const outsider = await registerUser();
    const wb = await connectUser(b.token);

    const dm1 = await api("/api/dms", { token: a.token, body: { userIds: [b.id] } });
    expect(dm1.status).toBe(201);
    expect((await wb.next("dm.channel")).channel.id).toBe(dm1.data.id);
    const dm2 = await api("/api/dms", { token: b.token, body: { userIds: [a.id] } });
    expect(dm2.data.id).toBe(dm1.data.id); // aynı sohbet

    await api(`/api/dms/${dm1.data.id}/messages`, { token: a.token, body: { content: "gizli selam", nonce: "x1" } });
    const ev = await wb.next("message.create");
    expect(ev.message).toMatchObject({ content: "gizli selam", channelId: dm1.data.id, nonce: "x1" });

    // DM'de yazıyor göstergesi
    const wa = await connectUser(a.token);
    wa.send({ t: "dm.typing", channelId: dm1.data.id });
    expect((await wb.next("typing")).userId).toBe(a.id);

    // Ortak sunucusu/arkadaşlığı olmayanla DM açılamaz; başkasının DM'i görünmez
    expect((await api("/api/dms", { token: outsider.token, body: { userIds: [a.id] } })).status).toBe(403);
    expect((await api(`/api/dms/${dm1.data.id}/messages`, { token: outsider.token })).status).toBe(404);

    // Düzenleme / silme DM'de de çalışır ve yayınlanır
    const msgs = await api(`/api/dms/${dm1.data.id}/messages`, { token: b.token });
    const mid = msgs.data[0].id;
    expect((await api(`/api/messages/${mid}`, { method: "PATCH", token: b.token, body: { content: "x" } })).status).toBe(403);
    await api(`/api/messages/${mid}`, { method: "PATCH", token: a.token, body: { content: "düzeltildi" } });
    expect((await wb.next("message.update")).message.content).toBe("düzeltildi");
    expect((await api("/api/dms", { token: b.token })).data[0].members.length).toBe(2);
    wa.close();
    wb.close();
  });

  it("grup DM yalnızca arkadaşlarla kurulur", async () => {
    const a = await registerUser();
    const b = await registerUser();
    const c = await registerUser();
    expect((await api("/api/dms", { token: a.token, body: { userIds: [b.id, c.id] } })).status).toBe(403);
    for (const u of [b, c]) {
      await api("/api/friends", { token: a.token, body: { username: u.username } });
      await api(`/api/friends/${a.id}`, { method: "PUT", token: u.token });
    }
    const g = await api("/api/dms", { token: a.token, body: { userIds: [b.id, c.id], name: "Üçlü" } });
    expect(g.status).toBe(201);
    expect(g.data).toMatchObject({ type: "group", name: "Üçlü" });
    expect(g.data.members).toHaveLength(3);
    expect((await api(`/api/dms/${g.data.id}/messages`, { token: c.token, body: { content: "hey" } })).status).toBe(201);
  });
});

describe("ekler, tepkiler, arama, profil resmi", () => {
  it("resim ve dosya eki, imzalı indirme, güvenli başlıklar", async () => {
    const { a, b, text } = await setupGuild();
    const fd = new FormData();
    fd.append("content", "bak");
    fd.append("files", new File([tinyPng()], "foto.png", { type: "image/png" }));
    fd.append("files", new File([new TextEncoder().encode("<script>alert(1)</script>")], "kotu.html", { type: "text/html" }));
    const r = await api(`/api/channels/${text}/messages`, { token: a.token, form: fd });
    expect(r.status).toBe(201);
    expect(r.data.attachments).toHaveLength(2);
    const [img, html] = r.data.attachments;
    expect(img).toMatchObject({ filename: "foto.png", isImage: true, mime: "image/png" });
    expect(html).toMatchObject({ isImage: false, mime: "application/octet-stream" });

    const imgRes = await SELF.fetch(img.url);
    expect(imgRes.headers.get("Content-Type")).toBe("image/png");
    expect(new Uint8Array(await imgRes.arrayBuffer())).toEqual(tinyPng());
    const htmlRes = await SELF.fetch(html.url);
    expect(htmlRes.headers.get("Content-Type")).toBe("application/octet-stream");
    expect(htmlRes.headers.get("Content-Disposition")).toBe("attachment");
    await htmlRes.arrayBuffer();

    // Yalnızca ek (metinsiz) mesaj
    const only = new FormData();
    only.append("files", new File([tinyPng()], "b.png"));
    expect((await api(`/api/channels/${text}/messages`, { token: b.token, form: only })).status).toBe(201);
    // Boş mesaj reddedilir
    expect((await api(`/api/channels/${text}/messages`, { token: b.token, form: new FormData() })).status).toBe(400);

    // Silinen mesajın eki depodan kalkar
    await api(`/api/messages/${r.data.id}`, { method: "DELETE", token: a.token });
    expect((await SELF.fetch(img.url)).status).toBe(404);
  });

  it("2 MB'tan büyük dosyalar parça parça saklanır ve aynen geri gelir", async () => {
    const { a, text } = await setupGuild();
    const big = new Uint8Array(3 * 1024 * 1024 + 123);
    for (let i = 0; i < big.length; i++) big[i] = (i * 31) % 251;
    const fd = new FormData();
    fd.append("files", new File([big], "veri.bin"));
    const r = await api(`/api/channels/${text}/messages`, { token: a.token, form: fd });
    expect(r.status).toBe(201);
    const back = new Uint8Array(await (await SELF.fetch(r.data.attachments[0].url)).arrayBuffer());
    expect(back.length).toBe(big.length);
    expect(back[3 * 1024 * 1024 + 100]).toBe(big[3 * 1024 * 1024 + 100]);
    expect(back.every((v, i) => v === big[i])).toBe(true);
  });

  it("tepki ekleme/kaldırma ve geçersiz emoji", async () => {
    const { a, b, text, gid } = await setupGuild();
    const { connect } = await import("./helpers");
    const m = (await api(`/api/channels/${text}/messages`, { token: a.token, body: { content: "tepki ver" } })).data;
    const wa = await connect(a.token, gid);
    const enc = encodeURIComponent("👍");
    expect((await api(`/api/messages/${m.id}/reactions/${enc}`, { method: "PUT", token: b.token })).status).toBe(200);
    const ev = await wa.next("message.reactions");
    expect(ev.reactions).toEqual([{ emoji: "👍", userIds: [b.id] }]);
    await api(`/api/messages/${m.id}/reactions/${enc}`, { method: "PUT", token: a.token });
    const list = await api(`/api/channels/${text}/messages`, { token: a.token });
    expect(list.data[0].reactions[0].userIds.sort()).toEqual([a.id, b.id].sort());
    await api(`/api/messages/${m.id}/reactions/${enc}`, { method: "DELETE", token: b.token });
    expect((await wa.next("message.reactions", (e) => e.reactions[0]?.userIds.length === 1)).reactions[0]!.userIds).toEqual([a.id]);
    expect((await api(`/api/messages/${m.id}/reactions/abc`, { method: "PUT", token: b.token })).status).toBe(400);
    // Birleşik emoji (aile, ten rengi) geçerli
    expect((await api(`/api/messages/${m.id}/reactions/${encodeURIComponent("👍🏽")}`, { method: "PUT", token: b.token })).status).toBe(200);
    wa.close();
  });

  it("arama: aksan duyarsız, önek eşleşmeli ve yalnızca görülebilen kanallar", async () => {
    const { a, b, gid, text } = await setupGuild();
    const priv = (await api(`/api/guilds/${gid}/channels`, { token: a.token, body: { name: "gizli", type: "text", isPrivate: true } })).data;
    await api(`/api/channels/${text}/messages`, { token: a.token, body: { content: "Yarın görüşürüz kanka" } });
    await api(`/api/channels/${text}/messages`, { token: a.token, body: { content: "başka bir şey" } });
    await api(`/api/channels/${priv.id}/messages`, { token: a.token, body: { content: "görüşme notları gizli" } });

    const r1 = await api(`/api/guilds/${gid}/search?q=gorus`, { token: b.token });
    expect(r1.status).toBe(200);
    expect(r1.data.map((m: any) => m.content)).toEqual(["Yarın görüşürüz kanka"]);
    const r2 = await api(`/api/guilds/${gid}/search?q=gorus`, { token: a.token });
    expect(r2.data).toHaveLength(2);
    // FTS sözdizimi enjeksiyonu hata vermez
    expect((await api(`/api/guilds/${gid}/search?q=${encodeURIComponent('" OR * NEAR(')}`, { token: a.token })).status).toBe(200);
    // Düzenlenen mesaj yeni içerikle bulunur
    const msg = (await api(`/api/channels/${text}/messages`, { token: a.token })).data[1];
    await api(`/api/messages/${msg.id}`, { method: "PATCH", token: a.token, body: { content: "elma armut" } });
    expect((await api(`/api/guilds/${gid}/search?q=armut`, { token: a.token })).data).toHaveLength(1);
  });

  it("profil resmi ve sunucu ikonu yalnızca resim kabul eder", async () => {
    const { a, b, gid } = await setupGuild();
    const fd = new FormData();
    fd.append("file", new File([tinyPng()], "a.png"));
    const me = await api("/api/me/avatar", { token: a.token, form: fd });
    expect(me.status).toBe(200);
    expect(me.data.avatarUrl).toMatch(/\/files\//);
    expect((await SELF.fetch(me.data.avatarUrl)).headers.get("Content-Type")).toBe("image/png");

    const bad = new FormData();
    bad.append("file", new File([new TextEncoder().encode("<svg onload=alert(1)>")], "x.svg"));
    expect((await api("/api/me/avatar", { token: a.token, form: bad })).status).toBe(415);

    const icon = new FormData();
    icon.append("file", new File([tinyPng()], "i.png"));
    expect((await api(`/api/guilds/${gid}/icon`, { token: b.token, form: icon })).status).toBe(403);
    const icon2 = new FormData();
    icon2.append("file", new File([tinyPng()], "i.png"));
    expect((await api(`/api/guilds/${gid}/icon`, { token: a.token, form: icon2 })).status).toBe(200);
    expect((await api("/api/guilds", { token: b.token })).data[0].iconUrl).toMatch(/\/files\//);
  });
});

describe("kalıcı silme", () => {
  it("silinen mesajın satırı, eki, tepkisi ve arama kaydı tamamen gider", async () => {
    const { env } = await import("cloudflare:test");
    const { a, b, gid, text } = await setupGuild();
    const fd = new FormData();
    fd.append("content", "imha edilecek gizli plan");
    fd.append("files", new File([tinyPng()], "plan.png"));
    const m = (await api(`/api/channels/${text}/messages`, { token: a.token, form: fd })).data;
    await api(`/api/messages/${m.id}/reactions/${encodeURIComponent("👍")}`, { method: "PUT", token: b.token });
    // Yanıt veren mesaj, silinen mesaja referans versin
    const reply = (await api(`/api/channels/${text}/messages`, { token: b.token, body: { content: "tamam", replyToId: m.id } })).data;
    expect((await api(`/api/guilds/${gid}/search?q=gizli`, { token: a.token })).data).toHaveLength(1);

    expect((await api(`/api/messages/${m.id}`, { method: "DELETE", token: a.token })).status).toBe(200);

    const count = async (sql: string) => (await env.DB.prepare(sql).bind(m.id).first<{ n: number }>())!.n;
    expect(await count("SELECT COUNT(*) AS n FROM messages WHERE id = ?")).toBe(0);
    expect(await count("SELECT COUNT(*) AS n FROM attachments WHERE message_id = ?")).toBe(0);
    expect(await count("SELECT COUNT(*) AS n FROM reactions WHERE message_id = ?")).toBe(0);
    expect((await env.DB.prepare("SELECT COUNT(*) AS n FROM messages_fts WHERE messages_fts MATCH ?").bind('"imha"').first<{ n: number }>())!.n).toBe(0);
    expect((await SELF.fetch(m.attachments[0].url)).status).toBe(404);
    expect((await api(`/api/guilds/${gid}/search?q=gizli`, { token: a.token })).data).toHaveLength(0);
    // Yanıt mesajı yerinde kalır
    const list = (await api(`/api/channels/${text}/messages`, { token: a.token })).data;
    expect(list.map((x: any) => x.id)).toEqual([reply.id]);
    // DM'de de kalıcı
    const dm = (await api("/api/dms", { token: a.token, body: { userIds: [b.id] } })).data;
    const dmMsg = (await api(`/api/dms/${dm.id}/messages`, { token: a.token, body: { content: "dm sil" } })).data;
    await api(`/api/messages/${dmMsg.id}`, { method: "DELETE", token: a.token });
    expect((await env.DB.prepare("SELECT COUNT(*) AS n FROM dm_messages WHERE id = ?").bind(dmMsg.id).first<{ n: number }>())!.n).toBe(0);
  });
});
