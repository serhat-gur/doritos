import { describe, expect, it } from "vitest";
import { api, setupGuild, tinyWav } from "./helpers";

describe("AFK odası", () => {
  it("AFK kanalı ve alarm sesi ayarlanır, doğrulanır, silinince boşalır", async () => {
    const { a, b, gid, text } = await setupGuild();
    const afk = (await api(`/api/guilds/${gid}/channels`, { token: a.token, body: { name: "AFK", type: "voice" } })).data;
    const fd = new FormData();
    fd.append("file", new File([tinyWav()], "alarm.wav"));
    fd.append("name", "Alarm");
    fd.append("guildId", gid);
    const sound = (await api("/api/sounds", { token: a.token, form: fd })).data;

    // Yetkisiz üye değiştiremez; yazı kanalı AFK olamaz; başka sunucunun sesi olamaz
    expect((await api(`/api/guilds/${gid}`, { method: "PATCH", token: b.token, body: { afkChannelId: afk.id } })).status).toBe(403);
    expect((await api(`/api/guilds/${gid}`, { method: "PATCH", token: a.token, body: { afkChannelId: text } })).status).toBe(400);
    const personal = new FormData();
    personal.append("file", new File([tinyWav()], "p.wav"));
    personal.append("name", "Kişisel");
    const mine = (await api("/api/sounds", { token: a.token, form: personal })).data;
    expect((await api(`/api/guilds/${gid}`, { method: "PATCH", token: a.token, body: { afkSoundId: mine.id } })).status).toBe(400);

    expect((await api(`/api/guilds/${gid}`, { method: "PATCH", token: a.token, body: { afkChannelId: afk.id, afkSoundId: sound.id } })).status).toBe(200);
    let g = (await api(`/api/guilds/${gid}`, { token: b.token })).data.guild;
    expect(g).toMatchObject({ afkChannelId: afk.id, afkSoundId: sound.id, name: "Ekip" });
    expect((await api("/api/guilds", { token: b.token })).data[0]).toMatchObject({ afkChannelId: afk.id });

    // Ses silinince yerleşik alarma döner; kanal silinince AFK kapanır
    expect((await api(`/api/sounds/${sound.id}`, { method: "DELETE", token: a.token })).status).toBe(200);
    g = (await api(`/api/guilds/${gid}`, { token: a.token })).data.guild;
    expect(g).toMatchObject({ afkChannelId: afk.id, afkSoundId: null });
    expect((await api(`/api/channels/${afk.id}`, { method: "DELETE", token: a.token })).status).toBe(200);
    g = (await api(`/api/guilds/${gid}`, { token: a.token })).data.guild;
    expect(g.afkChannelId).toBeNull();

    // null ile kaldırma
    const afk2 = (await api(`/api/guilds/${gid}/channels`, { token: a.token, body: { name: "AFK2", type: "voice" } })).data;
    await api(`/api/guilds/${gid}`, { method: "PATCH", token: a.token, body: { afkChannelId: afk2.id } });
    await api(`/api/guilds/${gid}`, { method: "PATCH", token: a.token, body: { afkChannelId: null } });
    expect((await api(`/api/guilds/${gid}`, { token: a.token })).data.guild.afkChannelId).toBeNull();
  });
});
