import { describe, expect, it } from "vitest";
import { Permission } from "@yanki/shared";
import { api, registerUser } from "./helpers";

describe("auth", () => {
  it("kayıt, giriş, /me ve çıkış", async () => {
    const u = await registerUser("ayse");
    const me = await api("/api/me", { token: u.token });
    expect(me.status).toBe(200);
    expect(me.data.username).toBe("ayse");
    expect(me.data).not.toHaveProperty("password_hash");

    const bad = await api("/api/auth/login", { body: { username: "ayse", password: "yanlis-sifre" } });
    expect(bad.status).toBe(401);
    const ghost = await api("/api/auth/login", { body: { username: "yokboyle", password: "yanlis-sifre" } });
    expect(ghost.status).toBe(401);

    const ok = await api("/api/auth/login", { body: { username: "ayse", password: "correct horse battery" } });
    expect(ok.status).toBe(200);
    expect(ok.data.token).toBeTypeOf("string");

    expect((await api("/api/auth/logout", { method: "POST", token: ok.data.token })).status).toBe(200);
    expect((await api("/api/me", { token: ok.data.token })).status).toBe(401);
  });

  it("aynı kullanıcı adını ve geçersiz girdiyi reddeder", async () => {
    await registerUser("mehmet");
    const dup = await api("/api/auth/register", { body: { username: "mehmet", displayName: "x", password: "12345678" } });
    expect(dup.status).toBe(409);
    const invalid = await api("/api/auth/register", { body: { username: "A B", displayName: "x", password: "1" } });
    expect(invalid.status).toBe(400);
  });

  it("token olmadan korumalı uçlar 401 döner", async () => {
    expect((await api("/api/guilds")).status).toBe(401);
    expect((await api("/api/guilds", { token: "uydurma" })).status).toBe(401);
  });
});

describe("sunucu, kanal ve RBAC", () => {
  it("sunucu oluşturur, davetle üye ekler, yetkileri sunucuda uygular", async () => {
    const owner = await registerUser();
    const friend = await registerUser();

    const g = await api("/api/guilds", { token: owner.token, body: { name: "Kanka Sunucusu" } });
    expect(g.status).toBe(201);
    const gid = g.data.id as string;

    const detail = await api(`/api/guilds/${gid}`, { token: owner.token });
    expect(detail.data.channels.map((c: any) => c.type).sort()).toEqual(["category", "category", "text", "voice"]);
    expect(detail.data.roles.map((r: any) => r.name)).toContain("@everyone");

    // Üye olmayan sunucuyu göremez
    expect((await api(`/api/guilds/${gid}`, { token: friend.token })).status).toBe(404);

    const inv = await api(`/api/guilds/${gid}/invites`, { token: owner.token, body: { maxUses: 1 } });
    expect(inv.status).toBe(201);
    expect((await api(`/api/invites/${inv.data.code}/accept`, { method: "POST", token: friend.token })).status).toBe(200);
    // Tek kullanımlık davet tükendi
    const third = await registerUser();
    expect((await api(`/api/invites/${inv.data.code}/accept`, { method: "POST", token: third.token })).status).toBe(404);

    // Üye kanal oluşturamaz (MANAGE_CHANNELS yok)
    const denied = await api(`/api/guilds/${gid}/channels`, { token: friend.token, body: { name: "hack", type: "text" } });
    expect(denied.status).toBe(403);

    // Sahip özel kanal oluşturur; üye göremez
    const priv = await api(`/api/guilds/${gid}/channels`, { token: owner.token, body: { name: "Yöneticiler", type: "text", isPrivate: true } });
    expect(priv.status).toBe(201);
    const friendView = await api(`/api/guilds/${gid}`, { token: friend.token });
    expect(friendView.data.channels.find((c: any) => c.id === priv.data.id)).toBeUndefined();
    expect((await api(`/api/channels/${priv.data.id}/messages`, { token: friend.token })).status).toBe(404);
    expect((await api(`/api/channels/${priv.data.id}/messages`, { token: friend.token, body: { content: "selam" } })).status).toBe(404);

    // Moderator rolü verilince kanal yönetemez ama mesaj yönetebilir
    const modRole = detail.data.roles.find((r: any) => r.name === "Moderator");
    expect((await api(`/api/guilds/${gid}/members/${friend.id}/roles/${modRole.id}`, { method: "PUT", token: owner.token })).status).toBe(200);
    const friendGuilds = await api("/api/guilds", { token: friend.token });
    const perms = friendGuilds.data[0].myPermissions as number;
    expect(perms & Permission.MANAGE_MESSAGES).toBeTruthy();
    expect(perms & Permission.MANAGE_CHANNELS).toBeFalsy();

    // Üye, sahip olmadığı izinleri içeren rol oluşturamaz / rol atayamaz
    expect((await api(`/api/guilds/${gid}/roles`, { token: friend.token, body: { name: "x", permissions: 0 } })).status).toBe(403);
  });

  it("kanal overwrite ile yazma izni kaldırılabilir", async () => {
    const owner = await registerUser();
    const friend = await registerUser();
    const gid = (await api("/api/guilds", { token: owner.token, body: { name: "G" } })).data.id;
    const code = (await api(`/api/guilds/${gid}/invites`, { token: owner.token, body: {} })).data.code;
    await api(`/api/invites/${code}/accept`, { method: "POST", token: friend.token });
    const text = (await api(`/api/guilds/${gid}`, { token: owner.token })).data.channels.find((c: any) => c.type === "text");

    expect((await api(`/api/channels/${text.id}/messages`, { token: friend.token, body: { content: "önce" } })).status).toBe(201);
    const ow = await api(`/api/channels/${text.id}/overwrites/member/${friend.id}`, {
      method: "PUT",
      token: owner.token,
      body: { allow: 0, deny: Permission.SEND_MESSAGES },
    });
    expect(ow.status).toBe(200);
    expect((await api(`/api/channels/${text.id}/messages`, { token: friend.token, body: { content: "sonra" } })).status).toBe(403);
    // Okumaya devam edebilir
    const list = await api(`/api/channels/${text.id}/messages`, { token: friend.token });
    expect(list.status).toBe(200);
    expect(list.data.map((m: any) => m.content)).toEqual(["önce"]);
  });
});

describe("mesajlar", () => {
  it("gönderir, sayfalar, düzenler ve siler", async () => {
    const owner = await registerUser();
    const gid = (await api("/api/guilds", { token: owner.token, body: { name: "G" } })).data.id;
    const text = (await api(`/api/guilds/${gid}`, { token: owner.token })).data.channels.find((c: any) => c.type === "text");
    const ids: string[] = [];
    for (let i = 0; i < 5; i++) {
      const r = await api(`/api/channels/${text.id}/messages`, { token: owner.token, body: { content: `m${i}` } });
      expect(r.status).toBe(201);
      ids.push(r.data.id);
    }
    const page = await api(`/api/channels/${text.id}/messages?limit=2&before=${ids[4]}`, { token: owner.token });
    expect(page.data.map((m: any) => m.content)).toEqual(["m2", "m3"]);

    const edit = await api(`/api/messages/${ids[0]}`, { method: "PATCH", token: owner.token, body: { content: "düzenlendi" } });
    expect(edit.data.editedAt).toBeTypeOf("number");
    expect((await api(`/api/messages/${ids[1]}`, { method: "DELETE", token: owner.token })).status).toBe(200);
    const all = await api(`/api/channels/${text.id}/messages`, { token: owner.token });
    expect(all.data.map((m: any) => m.content)).toEqual(["düzenlendi", "m2", "m3", "m4"]);
  });

  it("HTML içeriği düz metin olarak saklanır (XSS istemcide kaçışla önlenir)", async () => {
    const owner = await registerUser();
    const gid = (await api("/api/guilds", { token: owner.token, body: { name: "G" } })).data.id;
    const text = (await api(`/api/guilds/${gid}`, { token: owner.token })).data.channels.find((c: any) => c.type === "text");
    const r = await api(`/api/channels/${text.id}/messages`, { token: owner.token, body: { content: "<img src=x onerror=alert(1)>" } });
    expect(r.data.content).toBe("<img src=x onerror=alert(1)>");
  });
});
