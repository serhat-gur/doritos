import { SELF } from "cloudflare:test";
import { describe, expect, it } from "vitest";
import { Permission } from "@yanki/shared";
import { api, BASE, connect, registerUser, tinyWav } from "./helpers";

async function setupPair() {
  const a = await registerUser();
  const b = await registerUser();
  const gid = (await api("/api/guilds", { token: a.token, body: { name: "Ekip" } })).data.id as string;
  const code = (await api(`/api/guilds/${gid}/invites`, { token: a.token, body: {} })).data.code;
  await api(`/api/invites/${code}/accept`, { method: "POST", token: b.token });
  const detail = (await api(`/api/guilds/${gid}`, { token: a.token })).data;
  const text = detail.channels.find((c: any) => c.type === "text").id as string;
  const voice = detail.channels.find((c: any) => c.type === "voice").id as string;
  return { a, b, gid, text, voice };
}

describe("gateway (WebSocket)", () => {
  it("geçersiz bilet ve üye olmayanı reddeder", async () => {
    const { gid } = await setupPair();
    const r = await SELF.fetch(`${BASE}/api/guilds/${gid}/gateway?ticket=sahte.bilet`, { headers: { Upgrade: "websocket" } });
    expect(r.status).toBe(401);
    const outsider = await registerUser();
    const t = await api(`/api/guilds/${gid}/gateway-ticket`, { method: "POST", token: outsider.token });
    expect(t.status).toBe(404);
  });

  it("iki kullanıcı arasında gerçek zamanlı mesaj, presence ve yazıyor göstergesi", async () => {
    const { a, b, gid, text } = await setupPair();
    const wa = await connect(a.token, gid);
    const wb = await connect(b.token, gid);
    const pres = await wa.next("presence", (e) => e.userId === b.id);
    expect(pres.status).toBe("online");

    wb.send({ t: "typing", channelId: text });
    const typing = await wa.next("typing");
    expect(typing.userId).toBe(b.id);

    const sent = await api(`/api/channels/${text}/messages`, { token: a.token, body: { content: "merhaba!", nonce: "n1" } });
    expect(sent.status).toBe(201);
    const ev = await wb.next("message.create");
    expect(ev.message.content).toBe("merhaba!");
    expect(ev.message.author.id).toBe(a.id);
    expect(ev.message.nonce).toBe("n1");

    // Saat senkronizasyonu
    wb.send({ t: "ping", clientTime: 123 });
    const pong = await wb.next("pong");
    expect(pong.clientTime).toBe(123);
    expect(pong.serverTime).toBeGreaterThan(0);

    wb.close();
    const off = await wa.next("presence", (e) => e.userId === b.id && e.status === "offline");
    expect(off.status).toBe("offline");
    wa.close();
  });

  it("özel kanal mesajı yalnızca görebilenlere yayınlanır", async () => {
    const { a, b, gid } = await setupPair();
    const priv = (await api(`/api/guilds/${gid}/channels`, { token: a.token, body: { name: "gizli", type: "text", isPrivate: true } })).data;
    const wa = await connect(a.token, gid);
    const wb = await connect(b.token, gid);
    await api(`/api/channels/${priv.id}/messages`, { token: a.token, body: { content: "sır" } });
    await wa.next("message.create");
    await wb.expectNone("message.create");
    wa.close();
    wb.close();
  });
});

describe("sesli oda ve WebRTC sinyali", () => {
  it("katılma, sinyal aktarımı ve ayrılma", async () => {
    const { a, b, gid, voice, text } = await setupPair();
    const wa = await connect(a.token, gid);
    const wb = await connect(b.token, gid);

    // Sesli olmayan kanala katılma reddedilir
    wa.send({ t: "voice.join", channelId: text });
    expect((await wa.next("error")).ref).toBe("voice.join");

    wa.send({ t: "voice.join", channelId: voice });
    const upd = await wb.next("voice.update", (e) => e.participant.userId === a.id);
    expect(upd.participant.channelId).toBe(voice);

    // B seste değilken A'nın sinyali B'ye ulaşmaz
    wa.send({ t: "rtc.signal", to: b.id, data: { kind: "description", type: "offer", sdp: "v=0 erken" } });
    await wb.expectNone("rtc.signal");

    wb.send({ t: "voice.join", channelId: voice });
    await wa.next("voice.update", (e) => e.participant.userId === b.id);
    wa.send({ t: "rtc.signal", to: b.id, data: { kind: "description", type: "offer", sdp: "v=0 teklif" } });
    const sig = await wb.next("rtc.signal");
    expect(sig.from).toBe(a.id);
    expect(sig.data).toMatchObject({ kind: "description", type: "offer", sdp: "v=0 teklif" });

    wb.send({ t: "rtc.signal", to: a.id, data: { kind: "candidate", candidate: "candidate:1 1 udp 1 1.2.3.4 5 typ host", sdpMid: "0", sdpMLineIndex: 0 } });
    expect((await wa.next("rtc.signal")).data.kind).toBe("candidate");

    wa.send({ t: "voice.state", selfMute: true, selfDeaf: false });
    const muted = await wb.next("voice.update", (e) => e.participant.userId === a.id && e.participant.selfMute);
    expect(muted.participant.selfMute).toBe(true);

    // Bağlantı kopunca ses odasından düşer
    wa.close();
    const left = await wb.next("voice.leave", (e) => e.userId === a.id);
    expect(left.channelId).toBe(voice);
    wb.close();
  });

  it("CONNECT_VOICE izni kaldırılınca katılamaz", async () => {
    const { a, b, gid, voice } = await setupPair();
    await api(`/api/channels/${voice}/overwrites/member/${b.id}`, { method: "PUT", token: a.token, body: { allow: 0, deny: Permission.CONNECT_VOICE } });
    const wb = await connect(b.token, gid);
    wb.send({ t: "voice.join", channelId: voice });
    expect((await wb.next("error")).code).toBe("forbidden");
    wb.close();
  });
});

describe("soundboard", () => {
  it("yükleme, doğrulama, odaya yayın, cooldown ve indirme", async () => {
    const { a, b, gid, voice } = await setupPair();

    // Ses olmayan dosya reddedilir (uzantı/Content-Type'a bakılmaz)
    const bad = new FormData();
    bad.append("file", new File([new TextEncoder().encode("<html>kötü niyet</html>")], "x.mp3", { type: "audio/mpeg" }));
    bad.append("name", "kötü");
    bad.append("guildId", gid);
    expect((await api("/api/sounds", { token: a.token, form: bad })).status).toBe(415);

    const fd = new FormData();
    fd.append("file", new File([tinyWav()], "bip.wav", { type: "audio/wav" }));
    fd.append("name", "Bip");
    fd.append("emoji", "🎺");
    fd.append("category", "Komik");
    fd.append("volume", "0.8");
    fd.append("guildId", gid);
    const up = await api("/api/sounds", { token: a.token, form: fd });
    expect(up.status).toBe(201);
    expect(up.data.mime).toBe("audio/wav");
    expect(up.data.sha256).toHaveLength(64);

    const list = await api(`/api/sounds/guild/${gid}`, { token: b.token });
    expect(list.data.map((s: any) => s.name)).toEqual(["Bip"]);

    const wa = await connect(a.token, gid);
    const wb = await connect(b.token, gid);
    const outside = await connect(b.token, gid); // B'nin seste olmayan ikinci bağlantısı

    // Seste değilken çalınamaz
    wa.send({ t: "sound.play", soundId: up.data.id });
    expect((await wa.next("error")).code).toBe("not_in_voice");

    wa.send({ t: "voice.join", channelId: voice });
    wb.send({ t: "voice.join", channelId: voice });
    await wa.next("voice.update", (e) => e.participant.userId === b.id);
    await new Promise((r) => setTimeout(r, 50));

    wa.send({ t: "sound.play", soundId: up.data.id });
    const [pa, pb] = await Promise.all([wa.next("sound.play"), wb.next("sound.play")]);
    expect(pa.soundId).toBe(up.data.id);
    expect(pb.byUserId).toBe(a.id);
    expect(pb.volume).toBeCloseTo(0.8);
    expect(pb.playAt).toBeGreaterThan(Date.now() - 1000);
    // Sesli odada olmayan bağlantı duymaz
    await outside.expectNone("sound.play");

    // Cooldown
    wa.send({ t: "sound.play", soundId: up.data.id });
    expect((await wa.next("error")).code).toBe("cooldown");

    // İmzalı URL'den indirme
    const file = await SELF.fetch(pb.url);
    expect(file.status).toBe(200);
    expect(file.headers.get("Content-Type")).toBe("audio/wav");
    expect(new Uint8Array(await file.arrayBuffer()).length).toBe(tinyWav().length);
    // İmza bozulursa reddedilir
    expect((await SELF.fetch(pb.url.replace(/sig=[^&]+/, "sig=AAAA"))).status).toBe(403);

    // Kişisel ses başkası tarafından çalınamaz
    const pfd = new FormData();
    pfd.append("file", new File([tinyWav()], "p.wav"));
    pfd.append("name", "Benim");
    const personal = await api("/api/sounds", { token: a.token, form: pfd });
    expect(personal.status).toBe(201);
    await new Promise((r) => setTimeout(r, 1600));
    wb.send({ t: "sound.play", soundId: personal.data.id });
    expect((await wb.next("error")).code).toBe("not_found");

    // Üye başkasının sunucu sesini silemez, sahibi silebilir
    expect((await api(`/api/sounds/${up.data.id}`, { method: "DELETE", token: b.token })).status).toBe(403);
    expect((await api(`/api/sounds/${up.data.id}`, { method: "DELETE", token: a.token })).status).toBe(200);

    wa.close();
    wb.close();
    outside.close();
  });

  it("PLAY_SOUNDS izni olmayan çalamaz", async () => {
    const { a, b, gid, voice } = await setupPair();
    const fd = new FormData();
    fd.append("file", new File([tinyWav()], "bip.wav"));
    fd.append("name", "Bip");
    fd.append("guildId", gid);
    const up = await api("/api/sounds", { token: a.token, form: fd });
    await api(`/api/channels/${voice}/overwrites/member/${b.id}`, { method: "PUT", token: a.token, body: { allow: 0, deny: Permission.PLAY_SOUNDS } });
    const wb = await connect(b.token, gid);
    wb.send({ t: "voice.join", channelId: voice });
    await wb.next("voice.update");
    wb.send({ t: "sound.play", soundId: up.data.id });
    expect((await wb.next("error")).code).toBe("forbidden");
    wb.close();
  });
});
