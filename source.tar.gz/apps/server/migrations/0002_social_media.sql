-- 0002: dosya deposu kaydı, ekler, tepkiler, DM, yasak sebebi, arama (FTS5), avatar/ikon

-- Tüm dosyaların kaydı (blob içeriği BlobStore Durable Object'lerinde durur).
-- Genel depolama tavanı ve kotalar buradan hesaplanır.
CREATE TABLE blobs (
  key        TEXT PRIMARY KEY,
  owner_id   TEXT NOT NULL,
  kind       TEXT NOT NULL CHECK (kind IN ('sound','attachment','avatar','icon')),
  size       INTEGER NOT NULL,
  mime       TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_blobs_owner ON blobs(owner_id, kind);

-- Mesaj ekleri (hem sunucu hem DM mesajları; message_id ULID'leri benzersizdir)
CREATE TABLE attachments (
  id          TEXT PRIMARY KEY,
  message_id  TEXT NOT NULL,
  uploader_id TEXT NOT NULL,
  blob_key    TEXT NOT NULL,
  filename    TEXT NOT NULL,
  mime        TEXT NOT NULL,
  size        INTEGER NOT NULL,
  is_image    INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL
);
CREATE INDEX idx_attachments_message ON attachments(message_id);

CREATE TABLE reactions (
  message_id TEXT NOT NULL,
  user_id    TEXT NOT NULL,
  emoji      TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (message_id, user_id, emoji)
);
CREATE INDEX idx_reactions_message ON reactions(message_id);

-- Özel mesajlar: birebir (dm) ve grup. dm_key birebir DM'yi tekil yapar ("a:b", sıralı).
CREATE TABLE dm_channels (
  id              TEXT PRIMARY KEY,
  type            TEXT NOT NULL CHECK (type IN ('dm','group')),
  name            TEXT,
  owner_id        TEXT,
  dm_key          TEXT UNIQUE,
  created_at      INTEGER NOT NULL,
  last_message_at INTEGER
);

CREATE TABLE dm_members (
  channel_id TEXT NOT NULL REFERENCES dm_channels(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (channel_id, user_id)
);
CREATE INDEX idx_dm_members_user ON dm_members(user_id);

CREATE TABLE dm_messages (
  id          TEXT PRIMARY KEY,
  channel_id  TEXT NOT NULL REFERENCES dm_channels(id) ON DELETE CASCADE,
  author_id   TEXT NOT NULL REFERENCES users(id),
  content     TEXT NOT NULL,
  reply_to_id TEXT,
  created_at  INTEGER NOT NULL,
  edited_at   INTEGER,
  deleted_at  INTEGER
);
CREATE INDEX idx_dm_messages_channel ON dm_messages(channel_id, id);

-- Sunucu mesajlarında tam metin arama (Türkçe aksanları yok sayar: "gorusuruz" → "görüşürüz")
CREATE VIRTUAL TABLE messages_fts USING fts5(
  content,
  content = 'messages',
  content_rowid = 'rowid',
  tokenize = 'unicode61 remove_diacritics 2'
);
CREATE TRIGGER messages_fts_ai AFTER INSERT ON messages BEGIN
  INSERT INTO messages_fts(rowid, content) VALUES (new.rowid, new.content);
END;
CREATE TRIGGER messages_fts_ad AFTER DELETE ON messages BEGIN
  INSERT INTO messages_fts(messages_fts, rowid, content) VALUES ('delete', old.rowid, old.content);
END;
CREATE TRIGGER messages_fts_au AFTER UPDATE OF content ON messages BEGIN
  INSERT INTO messages_fts(messages_fts, rowid, content) VALUES ('delete', old.rowid, old.content);
  INSERT INTO messages_fts(rowid, content) VALUES (new.rowid, new.content);
END;
INSERT INTO messages_fts(messages_fts) VALUES ('rebuild');
