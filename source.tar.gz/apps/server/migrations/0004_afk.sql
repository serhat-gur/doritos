-- AFK odası: sunucu bir sesli kanalı AFK kanalı seçebilir; oraya geçen kişide
-- alarm durmadan çalar. Alarm sesi sunucu soundboard'undan seçilebilir.
-- Kanal veya ses silinince ayar kendiliğinden boşalır (ON DELETE SET NULL).
ALTER TABLE guilds ADD COLUMN afk_channel_id TEXT REFERENCES channels(id) ON DELETE SET NULL;
ALTER TABLE guilds ADD COLUMN afk_sound_id TEXT REFERENCES sounds(id) ON DELETE SET NULL;
