-- Yankı başlangıç şeması (Cloudflare D1 / SQLite)
-- Kimlikler: 26 karakterlik zaman sıralı ULID (metin). Zamanlar: Unix ms.

CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,
  display_name  TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  avatar_key    TEXT,
  bio           TEXT NOT NULL DEFAULT '',
  status        TEXT NOT NULL DEFAULT 'online' CHECK (status IN ('online','busy','idle','invisible')),
  created_at    INTEGER NOT NULL
);

CREATE TABLE sessions (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  user_agent  TEXT,
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL
);
CREATE INDEX idx_sessions_user ON sessions(user_id);

-- Arkadaşlık: (user_id, friend_id) yönlüdür. status:
--   pending  → user_id, friend_id'ye istek gönderdi
--   accepted → iki yönlü kayıt tutulur
--   blocked  → user_id, friend_id'yi engelledi
CREATE TABLE friendships (
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  friend_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status     TEXT NOT NULL CHECK (status IN ('pending','accepted','blocked')),
  created_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, friend_id)
);

CREATE TABLE guilds (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  icon_key   TEXT,
  owner_id   TEXT NOT NULL REFERENCES users(id),
  created_at INTEGER NOT NULL
);

CREATE TABLE guild_members (
  guild_id  TEXT NOT NULL REFERENCES guilds(id) ON DELETE CASCADE,
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  nickname  TEXT,
  joined_at INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);
CREATE INDEX idx_members_user ON guild_members(user_id);

-- Roller. @everyone rolünün id'si sunucu id'sine eşittir ve position = 0.
-- İzinler bit alanı olarak tutulur (packages/shared/src/permissions.ts).
CREATE TABLE roles (
  id          TEXT PRIMARY KEY,
  guild_id    TEXT NOT NULL REFERENCES guilds(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  color       TEXT,
  position    INTEGER NOT NULL DEFAULT 0,
  permissions INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL
);
CREATE INDEX idx_roles_guild ON roles(guild_id);

CREATE TABLE member_roles (
  guild_id TEXT NOT NULL,
  user_id  TEXT NOT NULL,
  role_id  TEXT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY (guild_id, user_id, role_id),
  FOREIGN KEY (guild_id, user_id) REFERENCES guild_members(guild_id, user_id) ON DELETE CASCADE
);

CREATE TABLE bans (
  guild_id   TEXT NOT NULL REFERENCES guilds(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason     TEXT,
  created_by TEXT,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (guild_id, user_id)
);

CREATE TABLE channels (
  id         TEXT PRIMARY KEY,
  guild_id   TEXT NOT NULL REFERENCES guilds(id) ON DELETE CASCADE,
  type       TEXT NOT NULL CHECK (type IN ('text','voice','category')),
  name       TEXT NOT NULL,
  parent_id  TEXT REFERENCES channels(id) ON DELETE SET NULL,
  position   INTEGER NOT NULL DEFAULT 0,
  is_private INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_channels_guild ON channels(guild_id);

-- Kanal izin overwrite'ları (rol veya üye bazlı allow/deny)
CREATE TABLE channel_overwrites (
  channel_id  TEXT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK (target_type IN ('role','member')),
  target_id   TEXT NOT NULL,
  allow       INTEGER NOT NULL DEFAULT 0,
  deny        INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (channel_id, target_type, target_id)
);

CREATE TABLE messages (
  id          TEXT PRIMARY KEY,
  channel_id  TEXT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  author_id   TEXT NOT NULL REFERENCES users(id),
  content     TEXT NOT NULL,
  reply_to_id TEXT,
  created_at  INTEGER NOT NULL,
  edited_at   INTEGER,
  deleted_at  INTEGER
);
-- ULID zaman sıralı olduğu için (channel_id, id) sayfalama için yeterlidir.
CREATE INDEX idx_messages_channel ON messages(channel_id, id);

CREATE TABLE invites (
  code       TEXT PRIMARY KEY,
  guild_id   TEXT NOT NULL REFERENCES guilds(id) ON DELETE CASCADE,
  creator_id TEXT NOT NULL REFERENCES users(id),
  max_uses   INTEGER NOT NULL DEFAULT 0,
  uses       INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_invites_guild ON invites(guild_id);

-- Soundboard sesleri. guild_id NULL → kişisel ses (yalnızca sahibi çalabilir).
-- "Panel" mantıksal olarak kapsam (kişisel/sunucu) + kategori ile oluşur.
CREATE TABLE sounds (
  id         TEXT PRIMARY KEY,
  guild_id   TEXT REFERENCES guilds(id) ON DELETE CASCADE,
  owner_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,
  emoji      TEXT NOT NULL DEFAULT '🔊',
  category   TEXT NOT NULL DEFAULT 'Genel',
  volume     REAL NOT NULL DEFAULT 1.0,
  r2_key     TEXT NOT NULL,
  mime       TEXT NOT NULL,
  size       INTEGER NOT NULL,
  sha256     TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX idx_sounds_guild ON sounds(guild_id);
CREATE INDEX idx_sounds_owner ON sounds(owner_id);

CREATE TABLE sound_favorites (
  user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sound_id TEXT NOT NULL REFERENCES sounds(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, sound_id)
);

-- Sesli oturum kayıtları (denetim / kullanım istatistiği)
CREATE TABLE voice_sessions (
  id         TEXT PRIMARY KEY,
  guild_id   TEXT NOT NULL,
  channel_id TEXT NOT NULL,
  user_id    TEXT NOT NULL,
  joined_at  INTEGER NOT NULL,
  left_at    INTEGER
);
CREATE INDEX idx_voice_sessions_open ON voice_sessions(user_id, left_at);
