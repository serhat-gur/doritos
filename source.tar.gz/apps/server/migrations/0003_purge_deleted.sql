-- 0003: Mesajlar artık kalıcı siliniyor. Önceki sürümün "yumuşak silinmiş"
-- (içeriği boşaltılmış) kayıtlarını ve onlara bağlı ek/tepki kayıtlarını temizle.
DELETE FROM reactions WHERE message_id IN (SELECT id FROM messages WHERE deleted_at IS NOT NULL);
DELETE FROM reactions WHERE message_id IN (SELECT id FROM dm_messages WHERE deleted_at IS NOT NULL);
DELETE FROM attachments WHERE message_id IN (SELECT id FROM messages WHERE deleted_at IS NOT NULL);
DELETE FROM attachments WHERE message_id IN (SELECT id FROM dm_messages WHERE deleted_at IS NOT NULL);
DELETE FROM messages WHERE deleted_at IS NOT NULL;
DELETE FROM dm_messages WHERE deleted_at IS NOT NULL;
