import type { WebContents } from "electron";

/**
 * Global klavye + mouse kancası (uiohook-napi). Electron'un globalShortcut
 * API'si tuş bırakmayı ve mouse tuşlarını vermez; bas-konuş ve "Mouse 4 ile
 * sustur" gibi makrolar için yerel kanca gerekir.
 *
 * Gizlilik: Tüm tuşlar renderer'a GÖNDERİLMEZ. Yalnızca kullanıcının atadığı
 * bağlar eşleşince olay iletilir; "tuş ata" ekranında da yalnızca bir sonraki
 * tek tuş/mouse olayı yakalanır.
 */
type Hook = typeof import("uiohook-napi");

let hook: Hook | null = null;
let started = false;
let target: WebContents | null = null;
let bindings = new Set<string>();
let captureResolve: ((v: { code: string; label: string } | null) => void) | null = null;
const held = new Set<string>();
let keyNames = new Map<number, string>();

async function load(): Promise<Hook | null> {
  if (hook) return hook;
  try {
    const m = (await import("uiohook-napi")) as Hook & { default?: Hook };
    hook = m.uIOhook ? m : (m.default ?? null);
    if (!hook) return null;
    keyNames = new Map(Object.entries(hook.UiohookKey).map(([name, code]) => [code as number, name]));
    return hook;
  } catch (err) {
    console.warn("[input-hook] yüklenemedi; global makrolar devre dışı", err);
    return null;
  }
}

function label(code: string): string {
  if (code.startsWith("mouse:")) {
    const n = Number(code.slice(6));
    return n === 3 ? "Mouse 3 (orta tuş)" : `Mouse ${n}`;
  }
  const kc = Number(code.slice(4));
  return keyNames.get(kc) ?? `Tuş ${kc}`;
}

function emit(code: string, down: boolean) {
  if (captureResolve && down) {
    // Sol/sağ tık atanamaz (her tıklamada tetiklenirdi)
    if (code === "mouse:1" || code === "mouse:2") return;
    const r = captureResolve;
    captureResolve = null;
    r({ code, label: label(code) });
    return;
  }
  if (!bindings.has(code)) return;
  // Basılı tutarken gelen tekrar olaylarını tek basışa indir
  if (down) {
    if (held.has(code)) return;
    held.add(code);
  } else held.delete(code);
  if (target && !target.isDestroyed()) target.send("input:event", { code, down });
}

async function ensureStarted(): Promise<boolean> {
  const h = await load();
  if (!h) return false;
  if (started) return true;
  h.uIOhook.on("keydown", (e) => emit(`key:${e.keycode}`, true));
  h.uIOhook.on("keyup", (e) => emit(`key:${e.keycode}`, false));
  h.uIOhook.on("mousedown", (e) => emit(`mouse:${Number(e.button)}`, true));
  h.uIOhook.on("mouseup", (e) => emit(`mouse:${Number(e.button)}`, false));
  h.uIOhook.start();
  started = true;
  return true;
}

export const inputHook = {
  async setBindings(wc: WebContents, codes: string[]): Promise<boolean> {
    target = wc;
    bindings = new Set(codes.filter((c) => /^(key|mouse):\d{1,6}$/.test(c)).slice(0, 32));
    held.clear();
    if (bindings.size === 0 && !captureResolve) return !!hook;
    return ensureStarted();
  },
  async capture(wc: WebContents): Promise<{ code: string; label: string } | null> {
    target = wc;
    if (!(await ensureStarted())) return null;
    captureResolve?.(null);
    return new Promise((resolve) => {
      captureResolve = resolve;
      setTimeout(() => {
        if (captureResolve === resolve) {
          captureResolve = null;
          resolve(null);
        }
      }, 10_000);
    });
  },
  label,
  stop() {
    if (hook && started) hook.uIOhook.stop();
    started = false;
  },
};
