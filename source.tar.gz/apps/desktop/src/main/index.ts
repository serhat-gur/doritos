import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import {
  app,
  BrowserWindow,
  desktopCapturer,
  globalShortcut,
  ipcMain,
  Menu,
  nativeImage,
  Notification,
  safeStorage,
  session,
  shell,
  Tray,
  type IpcMainEvent,
  type IpcMainInvokeEvent,
} from "electron";
import icon from "../../resources/icon.png?asset";
import type { DesktopSettings, ScreenSource, UpdateStatus } from "../preload/api";
import { inputHook } from "./input-hook";

const APP_NAME = "Doritos";
const isDev = !app.isPackaged && !!process.env.ELECTRON_RENDERER_URL;
// Uygulama adı değişse de eski ayarlar, giriş ve makrolar kaybolmasın:
// ayar klasörü ilk sürümdeki adla sabit tutulur.
app.setPath("userData", join(app.getPath("appData"), "Yankı"));
let win: BrowserWindow | null = null;
let tray: Tray | null = null;
let quitting = false;

// ---------------------------------------------------------------- tek örnek
if (!app.requestSingleInstanceLock()) {
  app.quit();
}
app.on("second-instance", () => showWindow());
app.setAppUserModelId("app.yanki.desktop"); // Windows bildirimleri için gerekli

// ---------------------------------------------------------------- ayarlar
const DEFAULT_SETTINGS: DesktopSettings = {
  // Derlemede apps/desktop/.env.production içindeki sunucu adresi gömülür;
  // böylece arkadaşlar adres yazmadan kayıt olabilir.
  apiUrl: process.env.YANKI_API_URL ?? (import.meta.env as unknown as Record<string, string | undefined>).MAIN_VITE_DEFAULT_API_URL ?? "http://127.0.0.1:8787",
  launchAtStartup: false,
  minimizeToTray: true,
};
const dataDir = () => {
  const d = app.getPath("userData");
  if (!existsSync(d)) mkdirSync(d, { recursive: true });
  return d;
};
function readSettings(): DesktopSettings {
  try {
    const raw = JSON.parse(readFileSync(join(dataDir(), "settings.json"), "utf8")) as Partial<DesktopSettings>;
    return { ...DEFAULT_SETTINGS, ...raw };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}
function writeSettings(s: DesktopSettings) {
  writeFileSync(join(dataDir(), "settings.json"), JSON.stringify(s, null, 2));
}

// ---------------------------------------------------------------- oturum (DPAPI)
// Windows'ta safeStorage, kullanıcı hesabına bağlı DPAPI ile şifreler.
const sessionFile = () => join(dataDir(), "session.bin");
function readSession(): string | null {
  try {
    if (!existsSync(sessionFile())) return null;
    const buf = readFileSync(sessionFile());
    return safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(buf) : null;
  } catch {
    return null;
  }
}
function writeSession(token: string | null) {
  if (token === null) {
    writeFileSync(sessionFile(), Buffer.alloc(0));
    return;
  }
  // Şifreleme yoksa token diske düz metin yazılmaz; oturum yalnızca bu açılışta yaşar.
  if (!safeStorage.isEncryptionAvailable()) return;
  writeFileSync(sessionFile(), safeStorage.encryptString(token));
}

// ---------------------------------------------------------------- IPC güvenliği
function trustedSender(e: IpcMainEvent | IpcMainInvokeEvent): boolean {
  const url = e.senderFrame?.url ?? "";
  if (isDev && url.startsWith(process.env.ELECTRON_RENDERER_URL!)) return true;
  return url.startsWith("file://");
}
function handle<T extends unknown[], R>(channel: string, fn: (...args: T) => R) {
  ipcMain.handle(channel, (e, ...args) => {
    if (!trustedSender(e)) throw new Error("Güvenilmeyen gönderici");
    return fn(...(args as T));
  });
}

handle("session:get", () => readSession());
handle("session:set", (token: unknown) => {
  if (typeof token !== "string" || token.length > 200) throw new Error("Geçersiz token");
  writeSession(token);
});
handle("session:clear", () => writeSession(null));
handle("settings:get", () => readSettings());
handle("settings:set", (patch: unknown) => {
  const p = (patch ?? {}) as Partial<DesktopSettings>;
  const next = { ...readSettings() };
  if (typeof p.apiUrl === "string" && /^https?:\/\/[^\s]+$/.test(p.apiUrl)) next.apiUrl = p.apiUrl.replace(/\/+$/, "");
  if (typeof p.launchAtStartup === "boolean") {
    next.launchAtStartup = p.launchAtStartup;
    app.setLoginItemSettings({ openAtLogin: p.launchAtStartup, args: ["--hidden"] });
  }
  if (typeof p.minimizeToTray === "boolean") next.minimizeToTray = p.minimizeToTray;
  writeSettings(next);
  return next;
});

// Global kısayollar (soundboard). Electron globalShortcut yalnızca tuşa basma
// olayını verir, bırakma olayını vermez; bu yüzden global bas-konuş için
// yerel bir klavye kancası gerekir (bkz. README "Henüz uygulanmayanlar").
handle("shortcuts:register", (accelerators: unknown) => {
  globalShortcut.unregisterAll();
  const failed: string[] = [];
  if (!Array.isArray(accelerators)) return failed;
  for (const acc of accelerators.slice(0, 100)) {
    if (typeof acc !== "string" || acc.length > 40) continue;
    try {
      const ok = globalShortcut.register(acc, () => win?.webContents.send("shortcuts:trigger", acc));
      if (!ok) failed.push(acc);
    } catch {
      failed.push(acc);
    }
  }
  return failed;
});

// ---------------------------------------------------------------- makrolar
handle("input:bindings", (codes: unknown) => (win ? inputHook.setBindings(win.webContents, Array.isArray(codes) ? codes.map(String) : []) : false));
handle("input:capture", () => (win ? inputHook.capture(win.webContents) : null));

// ---------------------------------------------------------------- ekran paylaşımı
let pendingScreen: { sourceId: string; systemAudio: boolean } | null = null;
handle("screen:sources", async (): Promise<ScreenSource[]> => {
  const sources = await desktopCapturer.getSources({ types: ["screen", "window"], thumbnailSize: { width: 320, height: 180 } });
  return sources.map((s) => ({ id: s.id, name: s.name, thumbnail: s.thumbnail.toDataURL(), isScreen: s.id.startsWith("screen:") }));
});
handle("screen:select", (sourceId: unknown, systemAudio: unknown) => {
  if (typeof sourceId !== "string" || sourceId.length > 200) throw new Error("Geçersiz kaynak");
  pendingScreen = { sourceId, systemAudio: systemAudio === true };
});

// ---------------------------------------------------------------- güncelleme
// Kurulu (paketlenmiş) sürümde electron-updater ile GitHub Releases'tan
// güncelleme denetlenir. Kaynak electron-builder.yml → publish.
let updater: typeof import("electron-updater").autoUpdater | null = null;
function sendUpdate(s: UpdateStatus) {
  win?.webContents.send("update:status", s);
}
async function initUpdater() {
  if (!app.isPackaged) return;
  try {
    const m = (await import("electron-updater")) as typeof import("electron-updater") & { default?: typeof import("electron-updater") };
    updater = m.autoUpdater ?? m.default?.autoUpdater ?? null;
    if (!updater) return;
  } catch {
    return;
  }
  updater.autoDownload = true;
  updater.autoInstallOnAppQuit = true;
  updater.on("checking-for-update", () => sendUpdate({ state: "checking" }));
  updater.on("update-not-available", () => sendUpdate({ state: "none" }));
  updater.on("update-available", (i) => sendUpdate({ state: "available", version: i.version }));
  updater.on("download-progress", (p) => sendUpdate({ state: "downloading", percent: Math.round(p.percent) }));
  updater.on("update-downloaded", (i) => sendUpdate({ state: "ready", version: i.version }));
  updater.on("error", (err) => sendUpdate({ state: "error", message: String(err?.message ?? err).slice(0, 200) }));
  const check = () => updater?.checkForUpdates().catch(() => {});
  setTimeout(check, 10_000);
  setInterval(check, 6 * 60 * 60 * 1000);
}
handle("update:check", async () => {
  if (!updater) {
    sendUpdate({ state: "error", message: app.isPackaged ? "Güncelleyici yüklenemedi" : "Geliştirme sürümünde güncelleme yok" });
    return;
  }
  await updater.checkForUpdates().catch((e: unknown) => sendUpdate({ state: "error", message: String(e) }));
});
ipcMain.on("update:install", (e) => {
  if (!trustedSender(e) || !updater) return;
  quitting = true;
  updater.quitAndInstall();
});

ipcMain.on("app:notify", (e, payload: { title?: unknown; body?: unknown }) => {
  if (!trustedSender(e) || !Notification.isSupported()) return;
  if (win?.isFocused()) return; // Odaktayken bildirim gösterme
  const n = new Notification({
    title: String(payload?.title ?? APP_NAME).slice(0, 100),
    body: String(payload?.body ?? "").slice(0, 300),
    icon,
  });
  n.on("click", () => showWindow());
  n.show();
});
ipcMain.on("app:badge", (e, count: unknown) => {
  if (!trustedSender(e) || typeof count !== "number") return;
  win?.setOverlayIcon(null, "");
  win?.flashFrame(count > 0 && !win.isFocused());
  tray?.setToolTip(count > 0 ? `${APP_NAME} — ${count} okunmamış` : APP_NAME);
});
ipcMain.on("app:open-external", (e, url: unknown) => {
  if (!trustedSender(e) || typeof url !== "string") return;
  if (/^https:\/\//.test(url)) void shell.openExternal(url);
});

// ---------------------------------------------------------------- pencere
function showWindow() {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
}

function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 800,
    minWidth: 940,
    minHeight: 560,
    show: false,
    backgroundColor: "#0e1014",
    title: APP_NAME,
    icon,
    autoHideMenuBar: true,
    webPreferences: {
      preload: join(import.meta.dirname, "../preload/index.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      spellcheck: false,
      // Arka planda ses/WebRTC zamanlayıcıları yavaşlamasın
      backgroundThrottling: false,
      additionalArguments: [`--yanki=version=${app.getVersion()}`],
    },
  });

  win.once("ready-to-show", () => {
    if (!process.argv.includes("--hidden")) win?.show();
  });

  // Uygulama içinde başka sayfaya gidilmesini ve yeni pencere açılmasını engelle
  win.webContents.on("will-navigate", (e, url) => {
    if (isDev && url.startsWith(process.env.ELECTRON_RENDERER_URL!)) return;
    e.preventDefault();
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) void shell.openExternal(url);
    return { action: "deny" };
  });

  win.on("close", (e) => {
    if (!quitting && readSettings().minimizeToTray) {
      e.preventDefault();
      win?.hide();
    }
  });

  if (isDev) void win.loadURL(process.env.ELECTRON_RENDERER_URL!);
  else void win.loadFile(join(import.meta.dirname, "../renderer/index.html"));
}

function createTray() {
  tray = new Tray(nativeImage.createFromPath(icon).resize({ width: 16, height: 16 }));
  tray.setToolTip(APP_NAME);
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: `${APP_NAME} uygulamasını aç`, click: () => showWindow() },
      { type: "separator" },
      {
        label: "Çıkış",
        click: () => {
          quitting = true;
          app.quit();
        },
      },
    ]),
  );
  tray.on("click", () => showWindow());
}

app.whenReady().then(() => {
  // Yalnızca mikrofon/medya ve bildirim izinlerine, yalnızca kendi sayfamız için izin ver.
  session.defaultSession.setPermissionRequestHandler((wc, permission, callback, details) => {
    const fromApp = details.requestingUrl.startsWith("file://") || (isDev && details.requestingUrl.startsWith(process.env.ELECTRON_RENDERER_URL!));
    callback(fromApp && wc === win?.webContents && ["media", "display-capture", "notifications", "speaker-selection"].includes(permission));
  });
  session.defaultSession.setPermissionCheckHandler((_wc, permission, origin) => {
    const fromApp = origin.startsWith("file://") || (isDev && origin.startsWith(new URL(process.env.ELECTRON_RENDERER_URL!).origin));
    return fromApp && ["media", "display-capture", "notifications", "speaker-selection"].includes(permission);
  });

  // getDisplayMedia: kullanıcının uygulama içi seçicide seçtiği kaynağı ver.
  // Sistem sesi ("loopback") Electron'da yalnızca Windows'ta desteklenir.
  session.defaultSession.setDisplayMediaRequestHandler(async (_req, callback) => {
    const sel = pendingScreen;
    pendingScreen = null;
    if (!sel) return callback({});
    const sources = await desktopCapturer.getSources({ types: ["screen", "window"] });
    const source = sources.find((s) => s.id === sel.sourceId);
    if (!source) return callback({});
    callback(sel.systemAudio && process.platform === "win32" ? { video: source, audio: "loopback" } : { video: source });
  });
  void initUpdater();

  createWindow();
  createTray();
  const s = readSettings();
  app.setLoginItemSettings({ openAtLogin: s.launchAtStartup, args: ["--hidden"] });
});

app.on("before-quit", () => {
  quitting = true;
});
app.on("will-quit", () => {
  globalShortcut.unregisterAll();
  inputHook.stop();
});
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
