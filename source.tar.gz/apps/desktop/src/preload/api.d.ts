/** Preload'un renderer'a açtığı API'nin tipi (window.yanki). */
export interface DesktopSettings {
  apiUrl: string;
  launchAtStartup: boolean;
  minimizeToTray: boolean;
}

export interface ScreenSource {
  id: string;
  name: string;
  /** data: URL küçük önizleme */
  thumbnail: string;
  isScreen: boolean;
}

export type UpdateStatus =
  | { state: "idle" | "checking" | "none" }
  | { state: "available" | "downloading"; version?: string; percent?: number }
  | { state: "ready"; version: string }
  | { state: "error"; message: string };

export interface YankiBridge {
  platform: string;
  session: {
    get(): Promise<string | null>;
    set(token: string): Promise<void>;
    clear(): Promise<void>;
  };
  settings: {
    get(): Promise<DesktopSettings>;
    set(patch: Partial<DesktopSettings>): Promise<DesktopSettings>;
  };
  shortcuts: {
    /** Global kısayolları kaydeder. Döndürülen liste kaydı başarısız olanlardır. */
    register(accelerators: string[]): Promise<string[]>;
    onTrigger(cb: (accelerator: string) => void): () => void;
  };
  /**
   * Global klavye/mouse makroları (bas-konuş, sustur, sağırlaştır).
   * Kodlar backend'e özgü dizelerdir ("key:57", "mouse:4" veya tarayıcıda "dom-key:KeyV").
   */
  input: {
    /** true: pencere arka plandayken de çalışır (Electron + yerel kanca). */
    global: boolean;
    setBindings(codes: string[]): Promise<boolean>;
    /** Bir sonraki tuş veya mouse tuşunu yakalar (10 sn zaman aşımı → null). */
    capture(): Promise<{ code: string; label: string } | null>;
    onEvent(cb: (e: { code: string; down: boolean }) => void): () => void;
  };
  screen: {
    /** Ekran/pencere listesi (yalnızca Electron). */
    sources(): Promise<ScreenSource[]>;
    /** Sonraki getDisplayMedia çağrısında kullanılacak kaynak ve sistem sesi. */
    select(sourceId: string, systemAudio: boolean): Promise<void>;
    /** Sistem sesi yakalama destekleniyor mu (Windows). */
    systemAudioSupported: boolean;
  };
  updates: {
    onStatus(cb: (s: UpdateStatus) => void): () => void;
    check(): Promise<void>;
    install(): void;
    version: string;
  };
  notify(title: string, body: string): void;
  setBadge(count: number): void;
  openExternal(url: string): void;
}

declare global {
  interface Window {
    yanki?: YankiBridge;
  }
}
