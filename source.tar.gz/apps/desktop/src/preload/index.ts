import { contextBridge, ipcRenderer, type IpcRendererEvent } from "electron";
import type { DesktopSettings, ScreenSource, UpdateStatus, YankiBridge } from "./api";

/**
 * Renderer'a yalnızca dar, tipli bir API açılır. ipcRenderer'ın kendisi
 * asla dışarı verilmez (rastgele kanallara mesaj gönderilemesin diye).
 */
function listen<T>(channel: string, cb: (v: T) => void): () => void {
  const listener = (_e: IpcRendererEvent, v: T) => cb(v);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

const args = new URLSearchParams(process.argv.find((a) => a.startsWith("--yanki="))?.slice(8) ?? "");

const bridge: YankiBridge = {
  platform: process.platform,
  session: {
    get: () => ipcRenderer.invoke("session:get") as Promise<string | null>,
    set: (token) => ipcRenderer.invoke("session:set", token) as Promise<void>,
    clear: () => ipcRenderer.invoke("session:clear") as Promise<void>,
  },
  settings: {
    get: () => ipcRenderer.invoke("settings:get") as Promise<DesktopSettings>,
    set: (patch) => ipcRenderer.invoke("settings:set", patch) as Promise<DesktopSettings>,
  },
  shortcuts: {
    register: (accelerators) => ipcRenderer.invoke("shortcuts:register", accelerators) as Promise<string[]>,
    onTrigger: (cb) => listen<string>("shortcuts:trigger", cb),
  },
  input: {
    global: true,
    setBindings: (codes) => ipcRenderer.invoke("input:bindings", codes) as Promise<boolean>,
    capture: () => ipcRenderer.invoke("input:capture") as Promise<{ code: string; label: string } | null>,
    onEvent: (cb) => listen<{ code: string; down: boolean }>("input:event", cb),
  },
  screen: {
    sources: () => ipcRenderer.invoke("screen:sources") as Promise<ScreenSource[]>,
    select: (sourceId, systemAudio) => ipcRenderer.invoke("screen:select", sourceId, systemAudio) as Promise<void>,
    systemAudioSupported: process.platform === "win32",
  },
  updates: {
    onStatus: (cb) => listen<UpdateStatus>("update:status", cb),
    check: () => ipcRenderer.invoke("update:check") as Promise<void>,
    install: () => ipcRenderer.send("update:install"),
    version: args.get("version") ?? "",
  },
  notify: (title, body) => ipcRenderer.send("app:notify", { title, body }),
  setBadge: (count) => ipcRenderer.send("app:badge", count),
  openExternal: (url) => ipcRenderer.send("app:open-external", url),
};

contextBridge.exposeInMainWorld("yanki", bridge);
