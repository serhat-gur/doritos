/**
 * Sunucu saat farkı tahmini (NTP benzeri). Her ping/pong örneğinde
 * offset = serverTime - (clientSend + rtt/2). En düşük RTT'li örnekler en
 * güvenilirdir; son 8 örnekten en düşük RTT'li olan kullanılır.
 */
interface Sample {
  offset: number;
  rtt: number;
}

export class ServerClock {
  private samples: Sample[] = [];

  addSample(clientSend: number, serverTime: number, clientReceive: number): void {
    const rtt = clientReceive - clientSend;
    if (rtt < 0 || rtt > 10_000) return;
    this.samples.push({ offset: serverTime - (clientSend + rtt / 2), rtt });
    if (this.samples.length > 8) this.samples.shift();
  }

  get offset(): number {
    if (this.samples.length === 0) return 0;
    return this.samples.reduce((best, s) => (s.rtt < best.rtt ? s : best)).offset;
  }

  get rtt(): number | null {
    if (this.samples.length === 0) return null;
    return Math.min(...this.samples.map((s) => s.rtt));
  }

  /** Sunucu saatine göre şu an (ms). */
  now(): number {
    return Date.now() + this.offset;
  }

  /** Sunucu zamanındaki bir anın yerel saatte kaç ms sonra olduğu. */
  msUntil(serverTime: number): number {
    return serverTime - this.now();
  }
}
