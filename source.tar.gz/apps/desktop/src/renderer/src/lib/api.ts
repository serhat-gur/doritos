import type {
  BanDTO,
  DmChannelDTO,
  FriendDTO,
  ReactionDTO,
  AuthResponse,
  ChannelDTO,
  GuildDTO,
  IceServersResponse,
  MemberDTO,
  MessageDTO,
  RoleDTO,
  SoundDTO,
  UpdateGuildInput,
  UserDTO,
} from "@yanki/shared";

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

let baseUrl = "http://127.0.0.1:8787";
let token: string | null = null;
let onUnauthorized: (() => void) | null = null;

export const apiConfig = {
  setBaseUrl: (u: string) => (baseUrl = u.replace(/\/+$/, "")),
  getBaseUrl: () => baseUrl,
  setToken: (t: string | null) => (token = t),
  getToken: () => token,
  onUnauthorized: (cb: () => void) => (onUnauthorized = cb),
};

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload: BodyInit | undefined;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }
  let res: Response;
  try {
    res = await fetch(baseUrl + path, { method, headers, body: payload });
  } catch {
    throw new ApiError(0, "network", "Sunucuya ulaşılamadı");
  }
  const text = await res.text();
  const data = text ? (JSON.parse(text) as unknown) : null;
  if (!res.ok) {
    const err = (data as { error?: { code: string; message: string; details?: unknown } } | null)?.error;
    if (res.status === 401 && token) onUnauthorized?.();
    throw new ApiError(res.status, err?.code ?? "http_error", err?.message ?? `HTTP ${res.status}`, err?.details);
  }
  return data as T;
}

export interface GuildDetail {
  guild: GuildDTO;
  channels: ChannelDTO[];
  roles: RoleDTO[];
  members: MemberDTO[];
}

export const api = {
  register: (username: string, displayName: string, password: string, registrationCode?: string) =>
    request<AuthResponse>("POST", "/api/auth/register", { username, displayName, password, registrationCode }),
  login: (username: string, password: string) => request<AuthResponse>("POST", "/api/auth/login", { username, password }),
  logout: () => request<{ ok: true }>("POST", "/api/auth/logout"),
  me: () => request<UserDTO>("GET", "/api/me"),
  updateMe: (patch: Partial<Pick<UserDTO, "displayName" | "bio" | "status">>) => request<UserDTO>("PATCH", "/api/me", patch),

  guilds: () => request<GuildDTO[]>("GET", "/api/guilds"),
  guild: (id: string) => request<GuildDetail>("GET", `/api/guilds/${id}`),
  createGuild: (name: string) => request<GuildDTO>("POST", "/api/guilds", { name }),
  createChannel: (guildId: string, input: { name: string; type: "text" | "voice" | "category"; parentId?: string | null; isPrivate?: boolean }) =>
    request<ChannelDTO>("POST", `/api/guilds/${guildId}/channels`, input),
  updateChannel: (id: string, patch: { name?: string; parentId?: string | null; position?: number }) =>
    request<ChannelDTO>("PATCH", `/api/channels/${id}`, patch),
  deleteChannel: (id: string) => request<{ ok: true }>("DELETE", `/api/channels/${id}`),
  createInvite: (guildId: string) => request<{ code: string }>("POST", `/api/guilds/${guildId}/invites`, {}),
  acceptInvite: (code: string) => request<{ guildId: string }>("POST", `/api/invites/${encodeURIComponent(code)}/accept`),
  gatewayTicket: (guildId: string) => request<{ ticket: string }>("POST", `/api/guilds/${guildId}/gateway-ticket`),

  /** Sunucu kanalı veya DM mesajları (dm=true) */
  messages: (channelId: string, before?: string, dm = false) =>
    request<MessageDTO[]>("GET", `/api/${dm ? "dms" : "channels"}/${channelId}/messages?limit=50${before ? `&before=${before}` : ""}`),
  sendMessage: (channelId: string, content: string, nonce: string, replyToId?: string | null, files: File[] = [], dm = false) => {
    const path = `/api/${dm ? "dms" : "channels"}/${channelId}/messages`;
    if (files.length === 0) return request<MessageDTO>("POST", path, { content, nonce, replyToId });
    const fd = new FormData();
    fd.append("content", content);
    fd.append("nonce", nonce);
    if (replyToId) fd.append("replyToId", replyToId);
    for (const f of files) fd.append("files", f, f.name);
    return request<MessageDTO>("POST", path, fd);
  },
  react: (messageId: string, emoji: string, add: boolean) =>
    request<ReactionDTO[]>(add ? "PUT" : "DELETE", `/api/messages/${messageId}/reactions/${encodeURIComponent(emoji)}`),
  search: (guildId: string, q: string, channelId?: string) =>
    request<MessageDTO[]>("GET", `/api/guilds/${guildId}/search?q=${encodeURIComponent(q)}${channelId ? `&channelId=${channelId}` : ""}`),
  editMessage: (id: string, content: string) => request<MessageDTO>("PATCH", `/api/messages/${id}`, { content }),
  deleteMessage: (id: string) => request<{ ok: true }>("DELETE", `/api/messages/${id}`),

  guildSounds: (guildId: string) => request<SoundDTO[]>("GET", `/api/sounds/guild/${guildId}`),
  mySounds: () => request<SoundDTO[]>("GET", "/api/sounds/me"),
  favorites: () => request<string[]>("GET", "/api/sounds/favorites"),
  uploadSound: (form: FormData) => request<SoundDTO>("POST", "/api/sounds", form),
  updateSound: (id: string, patch: { name?: string; emoji?: string; category?: string; volume?: number }) =>
    request<SoundDTO>("PATCH", `/api/sounds/${id}`, patch),
  deleteSound: (id: string) => request<{ ok: true }>("DELETE", `/api/sounds/${id}`),
  setFavorite: (id: string, fav: boolean) => request<{ ok: true }>(fav ? "PUT" : "DELETE", `/api/sounds/${id}/favorite`),

  iceServers: () => request<IceServersResponse>("GET", "/api/voice/ice-servers"),

  // ---- profil, sunucu ayarları
  uploadAvatar: (file: Blob) => {
    const fd = new FormData();
    fd.append("file", file, "avatar.webp");
    return request<UserDTO>("POST", "/api/me/avatar", fd);
  },
  removeAvatar: () => request<{ ok: true }>("DELETE", "/api/me/avatar"),
  updateGuild: (id: string, patch: UpdateGuildInput) => request<{ ok: true }>("PATCH", `/api/guilds/${id}`, patch),
  uploadGuildIcon: (id: string, file: Blob) => {
    const fd = new FormData();
    fd.append("file", file, "icon.webp");
    return request<{ ok: true }>("POST", `/api/guilds/${id}/icon`, fd);
  },
  createRole: (gid: string, body: { name: string; color?: string | null; permissions: number }) => request<RoleDTO>("POST", `/api/guilds/${gid}/roles`, body),
  updateRole: (gid: string, rid: string, body: { name?: string; color?: string | null; permissions?: number; position?: number }) =>
    request<{ ok: true }>("PATCH", `/api/guilds/${gid}/roles/${rid}`, body),
  deleteRole: (gid: string, rid: string) => request<{ ok: true }>("DELETE", `/api/guilds/${gid}/roles/${rid}`),
  setMemberRole: (gid: string, uid: string, rid: string, add: boolean) => request<{ ok: true }>(add ? "PUT" : "DELETE", `/api/guilds/${gid}/members/${uid}/roles/${rid}`),
  kick: (gid: string, uid: string) => request<{ ok: true }>("DELETE", `/api/guilds/${gid}/members/${uid}`),
  bans: (gid: string) => request<BanDTO[]>("GET", `/api/guilds/${gid}/bans`),
  ban: (gid: string, uid: string, reason?: string) => request<{ ok: true }>("PUT", `/api/guilds/${gid}/bans/${uid}`, { reason }),
  unban: (gid: string, uid: string) => request<{ ok: true }>("DELETE", `/api/guilds/${gid}/bans/${uid}`),
  setOverwrite: (cid: string, type: "role" | "member", target: string, allow: number, deny: number) =>
    request<{ ok: true }>("PUT", `/api/channels/${cid}/overwrites/${type}/${target}`, { allow, deny }),
  deleteOverwrite: (cid: string, type: "role" | "member", target: string) => request<{ ok: true }>("DELETE", `/api/channels/${cid}/overwrites/${type}/${target}`),

  // ---- arkadaşlar, engel, DM
  userGatewayTicket: () => request<{ ticket: string }>("POST", "/api/gateway-ticket"),
  friends: () => request<FriendDTO[]>("GET", "/api/friends"),
  addFriend: (username: string) => request<FriendDTO>("POST", "/api/friends", { username }),
  acceptFriend: (uid: string) => request<FriendDTO>("PUT", `/api/friends/${uid}`),
  removeFriend: (uid: string) => request<{ ok: true }>("DELETE", `/api/friends/${uid}`),
  block: (uid: string) => request<{ ok: true }>("PUT", `/api/blocks/${uid}`),
  unblock: (uid: string) => request<{ ok: true }>("DELETE", `/api/blocks/${uid}`),
  dms: () => request<DmChannelDTO[]>("GET", "/api/dms"),
  openDm: (userIds: string[], name?: string) => request<DmChannelDTO>("POST", "/api/dms", { userIds, name }),
  leaveDm: (id: string) => request<{ ok: true }>("DELETE", `/api/dms/${id}/members/@me`),
};
