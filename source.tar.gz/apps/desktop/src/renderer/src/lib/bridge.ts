import type { DesktopSettings, YankiBridge } from "../../../preload/api";

/** DOM mouse.button → yaygın adlandırma (1 sol, 2 sağ, 3 orta, 4 geri, 5 ileri) */
const DOM_MOUSE = [1, 3, 2, 4, 5];

/**
 * Electron preload köprüsü. Renderer tarayıcıda çalıştırılırsa (geliştirme /
 * uçtan uca test) güvenli olmayan ama işlevsel bir yedek kullanılır:
 * token yalnızca sessionStorage'da tutulur, makrolar yalnızca pencere
 * odaktayken çalışır.
 */
function browserFallback(): YankiBridge {
  const params = new URLSearchParams(location.search);
  let settings: DesktopSettings = {
    apiUrl: params.get("api") ?? (import.meta.env.VITE_API_URL as string | undefined) ?? "http://127.0.0.1:8787",
    launchAtStartup: false,
    minimizeToTray: false,
  };
  let bindings = new Set<string>();
  let capture: ((v: { code: string; label: string } | null) => void) | null = null;
  const listeners = new Set<(e: { code: string; down: boolean }) => void>();
  const held = new Set<string>();
  const emit = (code: string, down: boolean, label: string, ev: Event) => {
    if (capture && down) {
      if (code === "dom-mouse:1" || code === "dom-mouse:2") return;
      ev.preventDefault();
      const c = capture;
      capture = null;
      c({ code, label });
      return;
    }
    if (!bindings.has(code)) return;
    if (down) {
      if (held.has(code)) return;
      held.add(code);
    } else held.delete(code);
    for (const l of listeners) l({ code, down });
  };
  const typing = (e: Event) => {
    const t = e.target as HTMLElement | null;
    return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA");
  };
  window.addEventListener("keydown", (e) => !typing(e) && emit(`dom-key:${e.code}`, true, e.code, e), true);
  window.addEventListener("keyup", (e) => emit(`dom-key:${e.code}`, false, e.code, e), true);
  window.addEventListener("mousedown", (e) => emit(`dom-mouse:${DOM_MOUSE[e.button] ?? e.button + 1}`, true, `Mouse ${DOM_MOUSE[e.button] ?? e.button + 1}`, e), true);
  window.addEventListener("mouseup", (e) => emit(`dom-mouse:${DOM_MOUSE[e.button] ?? e.button + 1}`, false, "", e), true);
  window.addEventListener("blur", () => {
    for (const code of [...held]) emit(code, false, "", new Event("blur"));
  });

  return {
    platform: "web",
    session: {
      get: async () => sessionStorage.getItem("yanki.token"),
      set: async (t) => sessionStorage.setItem("yanki.token", t),
      clear: async () => sessionStorage.removeItem("yanki.token"),
    },
    settings: {
      get: async () => settings,
      set: async (p) => (settings = { ...settings, ...p }),
    },
    shortcuts: { register: async (a) => a, onTrigger: () => () => {} },
    input: {
      global: false,
      setBindings: async (codes) => {
        bindings = new Set(codes);
        return true;
      },
      capture: () =>
        new Promise((resolve) => {
          capture?.(null);
          capture = resolve;
          setTimeout(() => {
            if (capture === resolve) {
              capture = null;
              resolve(null);
            }
          }, 10_000);
        }),
      onEvent: (cb) => {
        listeners.add(cb);
        return () => listeners.delete(cb);
      },
    },
    screen: { sources: async () => [], select: async () => {}, systemAudioSupported: false },
    updates: { onStatus: () => () => {}, check: async () => {}, install: () => {}, version: "web" },
    notify: () => {},
    setBadge: (n) => {
      document.title = n > 0 ? `(${n}) Doritos` : "Doritos";
    },
    openExternal: (url) => window.open(url, "_blank", "noopener"),
  };
}

export const bridge: YankiBridge = window.yanki ?? browserFallback();
export const isElectron = !!window.yanki;
