import type { ClientEvent, ServerEvent } from "@yanki/shared";
import { CloseCode } from "@yanki/shared";
import { api, apiConfig } from "./api";
import { ServerClock } from "./clock";

export type GatewayStatus = "connecting" | "open" | "reconnecting" | "closed";

type Listener = (ev: ServerEvent) => void;

/**
 * Bir sunucunun (guild) Durable Object'ine WebSocket bağlantısı.
 * - Kısa ömürlü bilet ile kimlik doğrulama
 * - Üstel geri çekilme + rastgele sapma ile kontrollü yeniden bağlanma
 * - 25 sn'de bir ping: hem bağlantı canlılığı hem saat senkronizasyonu
 */
export class GatewayClient {
  readonly clock = new ServerClock();
  status: GatewayStatus = "closed";
  private ws: WebSocket | null = null;
  private listeners = new Set<Listener>();
  private statusListeners = new Set<(s: GatewayStatus) => void>();
  private attempts = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private lastPong = 0;
  private stopped = false;

  /** guildId "@me" ise kişisel gateway'e (arkadaşlar, DM) bağlanır. */
  constructor(public readonly guildId: string) {}

  on(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  onStatus(fn: (s: GatewayStatus) => void): () => void {
    this.statusListeners.add(fn);
    return () => this.statusListeners.delete(fn);
  }

  send(ev: ClientEvent): boolean {
    if (this.ws?.readyState !== WebSocket.OPEN) return false;
    this.ws.send(JSON.stringify(ev));
    return true;
  }

  start(): void {
    this.stopped = false;
    void this.connect();
  }

  stop(): void {
    this.stopped = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.ws?.close(1000, "istemci kapattı");
    this.ws = null;
    this.setStatus("closed");
  }

  private setStatus(s: GatewayStatus) {
    this.status = s;
    for (const fn of this.statusListeners) fn(s);
  }

  private async connect(): Promise<void> {
    if (this.stopped) return;
    this.setStatus(this.attempts === 0 ? "connecting" : "reconnecting");
    let ticket: string;
    try {
      ticket = (this.guildId === "@me" ? await api.userGatewayTicket() : await api.gatewayTicket(this.guildId)).ticket;
    } catch (err) {
      const status = (err as { status?: number }).status;
      if (status === 401 || status === 403 || status === 404) {
        this.stop();
        return;
      }
      this.scheduleReconnect();
      return;
    }
    const path = this.guildId === "@me" ? "/api/gateway" : `/api/guilds/${this.guildId}/gateway`;
    const url = `${apiConfig.getBaseUrl().replace(/^http/, "ws")}${path}?ticket=${encodeURIComponent(ticket)}`;
    const ws = new WebSocket(url);
    this.ws = ws;

    ws.onopen = () => {
      this.attempts = 0;
      this.lastPong = Date.now();
      this.setStatus("open");
      this.ping();
      if (this.pingTimer) clearInterval(this.pingTimer);
      this.pingTimer = setInterval(() => {
        // 2 ping boyunca yanıt yoksa bağlantı ölü kabul edilir
        if (Date.now() - this.lastPong > 60_000) {
          ws.close(4000, "ping zaman aşımı");
          return;
        }
        this.ping();
      }, 25_000);
    };
    ws.onmessage = (m) => {
      let ev: ServerEvent;
      try {
        ev = JSON.parse(m.data as string) as ServerEvent;
      } catch {
        return;
      }
      if (ev.t === "pong") {
        this.lastPong = Date.now();
        this.clock.addSample(ev.clientTime, ev.serverTime, Date.now());
      }
      for (const fn of this.listeners) fn(ev);
    };
    ws.onclose = (e) => {
      if (this.ws !== ws) return;
      if (this.pingTimer) clearInterval(this.pingTimer);
      this.ws = null;
      if (this.stopped || e.code === CloseCode.FORBIDDEN || e.code === CloseCode.UNAUTHORIZED) {
        this.setStatus("closed");
        return;
      }
      this.scheduleReconnect();
    };
  }

  /** Ardışık birkaç ping ile saat ofsetini hızlıca oturtur. */
  ping(): void {
    this.send({ t: "ping", clientTime: Date.now() });
  }

  private scheduleReconnect(): void {
    if (this.stopped) return;
    this.setStatus("reconnecting");
    const base = Math.min(30_000, 500 * 2 ** this.attempts);
    const delay = base / 2 + Math.random() * (base / 2);
    this.attempts++;
    this.reconnectTimer = setTimeout(() => void this.connect(), delay);
  }
}
