import type { QueryClient } from "@tanstack/react-query";
import type { ClientEvent, DmChannelDTO, FriendDTO, MessageDTO, ServerEvent } from "@yanki/shared";
import { soundPlayer } from "../media/sound-player";
import { useRealtime, useSession, useVoice } from "../stores/app";
import { useSettings } from "../stores/settings";
import { bridge } from "./bridge";
import { GatewayClient } from "./gateway";

/**
 * Üyesi olunan her sunucu için bir gateway bağlantısı tutar ve gelen olayları
 * React Query önbelleğine ve Zustand store'larına dağıtır.
 */
class RealtimeManager {
  private clients = new Map<string, GatewayClient>();
  private qc: QueryClient | null = null;

  init(qc: QueryClient) {
    this.qc = qc;
  }

  client(guildId: string): GatewayClient | undefined {
    return this.clients.get(guildId);
  }

  /** Bağlı olunması gereken sunucu kümesini eşitle. */
  sync(guildIds: string[]) {
    // "@me": kişisel gateway (arkadaşlar, DM) her zaman bağlı
    const want = new Set(["@me", ...guildIds]);
    for (const [id, c] of this.clients) {
      if (!want.has(id)) {
        c.stop();
        this.clients.delete(id);
      }
    }
    for (const id of want) {
      if (this.clients.has(id)) continue;
      const c = new GatewayClient(id);
      c.on((ev) => this.dispatch(id, ev));
      c.onStatus((status) => useRealtime.getState().patch(id, () => ({ status })));
      this.clients.set(id, c);
      c.start();
    }
  }

  sendAll(ev: ClientEvent) {
    for (const c of this.clients.values()) c.send(ev);
  }

  stopAll() {
    for (const c of this.clients.values()) c.stop();
    this.clients.clear();
  }

  private dispatch(guildId: string, ev: ServerEvent) {
    const rt = useRealtime.getState();
    const qc = this.qc;
    const me = useSession.getState().user?.id;
    switch (ev.t) {
      case "ready":
        rt.patch(guildId, () => ({
          presence: Object.fromEntries(ev.online.map((o) => [o.userId, o.status])),
          voice: Object.fromEntries(ev.voice.map((v) => [v.userId, v])),
        }));
        // Saat ofsetini hızlı oturtmak için birkaç ping
        for (let i = 1; i <= 3; i++) setTimeout(() => this.clients.get(guildId)?.ping(), i * 300);
        // Kopukluk sırasında kaçan mesajları tazele
        void qc?.invalidateQueries({ queryKey: ["messages"] });
        break;
      case "presence":
        rt.patch(guildId, (g) => ({ presence: { ...g.presence, [ev.userId]: ev.status } }));
        break;
      case "typing":
        rt.patch(guildId, (g) => ({ typing: { ...g.typing, [ev.channelId]: { ...g.typing[ev.channelId], [ev.userId]: Date.now() } } }));
        break;
      case "voice.update":
        rt.patch(guildId, (g) => ({ voice: { ...g.voice, [ev.participant.userId]: ev.participant } }));
        break;
      case "voice.leave":
        rt.patch(guildId, (g) => {
          const voice = { ...g.voice };
          if (voice[ev.userId]?.channelId === ev.channelId) delete voice[ev.userId];
          return { voice };
        });
        break;
      case "message.create": {
        const m = ev.message;
        qc?.setQueryData<MessageDTO[]>(["messages", m.channelId], (old) => {
          if (!old) return old;
          // Kendi gönderdiğimiz iyimser mesajı (nonce) gerçeğiyle değiştir
          const withoutOptimistic = m.nonce ? old.filter((x) => x.nonce !== m.nonce || x.id === m.id) : old;
          if (withoutOptimistic.some((x) => x.id === m.id)) return withoutOptimistic;
          return [...withoutOptimistic, m];
        });
        // Yazıyor göstergesini temizle
        rt.patch(guildId, (g) => {
          const t = { ...g.typing[m.channelId] };
          delete t[m.author.id];
          return { typing: { ...g.typing, [m.channelId]: t } };
        });
        if (guildId === "@me") {
          qc?.setQueryData<DmChannelDTO[]>(["dms"], (old) => {
            const d = old?.find((x) => x.id === m.channelId);
            if (!d) {
              void qc.invalidateQueries({ queryKey: ["dms"] });
              return old;
            }
            return [{ ...d, lastMessageAt: m.createdAt }, ...old!.filter((x) => x.id !== m.channelId)];
          });
        }
        // Engellediğim kişilerden bildirim gelmesin
        const blocked = qc?.getQueryData<FriendDTO[]>(["friends"])?.some((f) => f.state === "blocked" && f.user.id === m.author.id);
        const s = useSession.getState();
        const viewing = s.selectedGuildId === guildId && s.selectedChannelId[guildId] === m.channelId && document.hasFocus();
        if (m.author.id !== me && !viewing && !blocked) {
          rt.addUnread(m.channelId);
          bridge.notify(m.author.displayName, m.content.slice(0, 140));
        }
        break;
      }
      case "message.reactions":
        qc?.setQueryData<MessageDTO[]>(["messages", ev.channelId], (old) => old?.map((x) => (x.id === ev.messageId ? { ...x, reactions: ev.reactions } : x)));
        break;
      case "friend.update":
        qc?.setQueryData<FriendDTO[]>(["friends"], (old) => {
          const rest = (old ?? []).filter((f) => f.user.id !== ev.friend.user.id);
          return [...rest, ev.friend];
        });
        if (ev.friend.state === "incoming") bridge.notify("Arkadaşlık isteği", `${ev.friend.user.displayName} seni arkadaş olarak eklemek istiyor`);
        break;
      case "friend.remove":
        qc?.setQueryData<FriendDTO[]>(["friends"], (old) => old?.filter((f) => f.user.id !== ev.userId));
        break;
      case "dm.channel":
        qc?.setQueryData<DmChannelDTO[]>(["dms"], (old) => [ev.channel, ...(old ?? []).filter((d) => d.id !== ev.channel.id)]);
        break;
      case "guild.update":
        void qc?.invalidateQueries({ queryKey: ["guild", guildId] });
        void qc?.invalidateQueries({ queryKey: ["guilds"] });
        break;
      case "guild.remove":
        void qc?.invalidateQueries({ queryKey: ["guilds"] });
        if (useSession.getState().selectedGuildId === ev.guildId) useSession.getState().selectGuild(null);
        window.dispatchEvent(new CustomEvent("yanki:toast", { detail: "Bir sunucudan çıkarıldın" }));
        break;
      case "message.update":
        qc?.setQueryData<MessageDTO[]>(["messages", ev.message.channelId], (old) => old?.map((x) => (x.id === ev.message.id ? ev.message : x)));
        break;
      case "message.delete":
        qc?.setQueryData<MessageDTO[]>(["messages", ev.channelId], (old) => old?.filter((x) => x.id !== ev.messageId));
        break;
      case "channel.create":
      case "channel.update":
      case "channel.delete":
      case "member.join":
        void qc?.invalidateQueries({ queryKey: ["guild", guildId] });
        break;
      case "sound.created":
      case "sound.deleted":
        void qc?.invalidateQueries({ queryKey: ["sounds", guildId] });
        break;
      case "sound.play": {
        const v = useVoice.getState();
        if (v.channelId !== ev.channelId || v.selfDeaf) return;
        const settings = useSettings.getState();
        const perUser = settings.userSoundVolumes[ev.byUserId] ?? 1;
        if (perUser <= 0) return;
        const client = this.clients.get(guildId);
        if (!client) return;
        soundPlayer.setMasterVolume(settings.soundboardVolume);
        void soundPlayer
          .playScheduled({ sha256: ev.sha256, url: ev.url, volume: ev.volume * perUser, playAt: ev.playAt, clock: client.clock })
          .catch((err) => console.warn("[soundboard] çalınamadı", err));
        break;
      }
      case "error":
        if (ev.ref === "sound.play") window.dispatchEvent(new CustomEvent("yanki:toast", { detail: ev.message }));
        break;
    }
  }
}

export const realtime = new RealtimeManager();
