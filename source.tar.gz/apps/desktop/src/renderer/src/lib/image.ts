/**
 * Profil/sunucu resmini kare kırpıp küçültür ve WebP'ye çevirir.
 * Ücretsiz depolama tasarrufu: tipik 3-5 MB'lık fotoğraf ~20-40 KB olur.
 */
export async function squareImage(file: Blob, size = 256): Promise<Blob> {
  const bmp = await createImageBitmap(file);
  const s = Math.min(bmp.width, bmp.height);
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, size, size);
  bmp.close();
  return new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Resim dönüştürülemedi"))), "image/webp", 0.85));
}
