import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
import { ApiError } from "./lib/api";
import { realtime } from "./lib/realtime";
import { cueHistory } from "./media/cues";
import { afkAlarm } from "./media/afk-alarm";
import { soundPlayer } from "./media/sound-player";
import { useVoice } from "./stores/app";
import "./styles.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      refetchOnWindowFocus: false,
      retry: (count, err) => !(err instanceof ApiError && err.status >= 400 && err.status < 500) && count < 3,
    },
  },
});
realtime.init(queryClient);

// Salt okunur tanılama kancası (?debug=1): bağlantı kalitesi ve soundboard zamanlaması.
if (import.meta.env.DEV || new URLSearchParams(location.search).has("debug")) {
  (window as unknown as { __yanki: unknown }).__yanki = {
    voice: () => useVoice.getState(),
    sounds: () => soundPlayer.history,
    cues: () => cueHistory,
    afk: () => afkAlarm.playing,
  };
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </StrictMode>,
);
