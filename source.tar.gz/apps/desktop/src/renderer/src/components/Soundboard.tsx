import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { hasFlag, LIMITS, Permission, type SoundDTO } from "@yanki/shared";
import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "../lib/api";
import { bridge, isElectron } from "../lib/bridge";
import { realtime } from "../lib/realtime";
import { soundPlayer } from "../media/sound-player";
import { useSession } from "../stores/app";
import { useSettings } from "../stores/settings";
import { Button, cx, Icon, Modal, TextInput, toast } from "./ui";

/**
 * Ses paneli. Bir sese tıklamak sunucuya `sound.play` gönderir; sunucu yetkiyi,
 * cooldown'u ve oda limitini kontrol edip odadaki herkese yayınlar. Sağ tık
 * (veya ▶) yalnızca yerelde önizler.
 */
export function Soundboard({ guildId, canManage, onClose }: { guildId: string; canManage: number; onClose: () => void }) {
  const qc = useQueryClient();
  const me = useSession((s) => s.user)!;
  const guildSounds = useQuery({ queryKey: ["sounds", guildId], queryFn: () => api.guildSounds(guildId) });
  const mySounds = useQuery({ queryKey: ["sounds", "me"], queryFn: api.mySounds });
  const favorites = useQuery({ queryKey: ["sounds", "favorites"], queryFn: api.favorites });
  const [tab, setTab] = useState<"guild" | "me" | "fav">("guild");
  const [filter, setFilter] = useState("");
  const [uploadOpen, setUploadOpen] = useState(false);
  const [editing, setEditing] = useState<SoundDTO | null>(null);
  const [cooldownUntil, setCooldownUntil] = useState(0);
  const keybinds = useSettings((s) => s.soundKeybinds);
  const canManageBoard = hasFlag(canManage, Permission.MANAGE_SOUNDBOARD);

  const all = useMemo(() => [...(guildSounds.data ?? []), ...(mySounds.data ?? [])], [guildSounds.data, mySounds.data]);
  const favSet = new Set(favorites.data ?? []);
  const visible = (tab === "guild" ? guildSounds.data : tab === "me" ? mySounds.data : all.filter((s) => favSet.has(s.id))) ?? [];
  const filtered = visible.filter((s) => !filter || s.name.toLowerCase().includes(filter.toLowerCase()) || s.category.toLowerCase().includes(filter.toLowerCase()));
  const byCategory = filtered.reduce<Record<string, SoundDTO[]>>((acc, s) => ((acc[s.category] ??= []).push(s), acc), {});

  // Önbelleği ısıt: panel açılınca sesleri arka planda indir
  useEffect(() => {
    for (const s of all) void soundPlayer.load(s.sha256, s.url).catch(() => {});
  }, [all]);

  function play(s: SoundDTO) {
    if (Date.now() < cooldownUntil) return;
    const ok = realtime.client(guildId)?.send({ t: "sound.play", soundId: s.id });
    if (!ok) return toast("Bağlantı yok");
    setCooldownUntil(Date.now() + LIMITS.SOUND_USER_COOLDOWN_MS);
    setTimeout(() => setCooldownUntil(0), LIMITS.SOUND_USER_COOLDOWN_MS);
  }

  // Global kısayollar (Electron) ve pencere içi kısayollar
  const playRef = useRef(play);
  playRef.current = play;
  useEffect(() => {
    const entries = Object.entries(keybinds).filter(([id]) => all.some((s) => s.id === id));
    void bridge.shortcuts.register(entries.map(([, acc]) => acc)).then((failed) => {
      if (failed.length && isElectron) toast(`Kaydedilemeyen kısayol: ${failed.join(", ")}`);
    });
    return bridge.shortcuts.onTrigger((acc) => {
      const id = entries.find(([, a]) => a === acc)?.[0];
      const s = all.find((x) => x.id === id);
      if (s) playRef.current(s);
    });
  }, [keybinds, all]);

  const toggleFav = useMutation({
    mutationFn: ({ id, fav }: { id: string; fav: boolean }) => api.setFavorite(id, fav),
    onSettled: () => qc.invalidateQueries({ queryKey: ["sounds", "favorites"] }),
  });

  return (
    <div className="absolute bottom-full left-0 z-30 mb-2 flex max-h-[420px] w-[360px] flex-col rounded-2xl border border-ink-700 bg-ink-850 shadow-2xl" role="dialog" aria-label="Ses paneli">
      <div className="flex items-center gap-1 border-b border-ink-700 p-2">
        {(
          [
            ["guild", "Sunucu"],
            ["me", "Kişisel"],
            ["fav", "Favoriler"],
          ] as const
        ).map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)} className={cx("rounded-lg px-2.5 py-1 text-xs font-medium", tab === k ? "bg-ink-700 text-ink-100" : "text-ink-400 hover:text-ink-200")}>
            {label}
          </button>
        ))}
        <div className="flex-1" />
        <button className="rounded-lg px-2 py-1 text-xs text-amber-400 hover:bg-ink-750" onClick={() => setUploadOpen(true)}>
          + Ses yükle
        </button>
        <button className="p-1 text-ink-400 hover:text-ink-100" onClick={onClose} aria-label="Kapat">
          <Icon name="x" size={14} />
        </button>
      </div>
      <div className="px-3 pt-2">
        <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Ara…" className="h-8 w-full rounded-lg bg-ink-950 px-2.5 text-xs outline-none" />
      </div>
      <div className="flex-1 overflow-y-auto p-3">
        {Object.keys(byCategory).length === 0 && <p className="py-6 text-center text-xs text-ink-400">Burada henüz ses yok.</p>}
        {Object.entries(byCategory).map(([cat, sounds]) => (
          <section key={cat} className="mb-3">
            <h4 className="mb-1.5 text-[10px] font-semibold tracking-wider text-ink-400 uppercase">{cat}</h4>
            <div className="grid grid-cols-3 gap-1.5">
              {sounds.map((s) => (
                <div key={s.id} className="group relative">
                  <button
                    onClick={() => play(s)}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      void soundPlayer.preview(s.sha256, s.url, s.volume);
                    }}
                    disabled={Date.now() < cooldownUntil}
                    title={`${s.name}${keybinds[s.id] ? ` (${keybinds[s.id]})` : ""} — sağ tık: önizle`}
                    className="flex h-14 w-full flex-col items-center justify-center rounded-xl bg-ink-750 px-1 text-center transition-colors hover:bg-ink-700 disabled:opacity-60"
                  >
                    <span className="text-lg leading-none">{s.emoji}</span>
                    <span className="mt-1 w-full truncate text-[11px] text-ink-200">{s.name}</span>
                  </button>
                  <div className="absolute top-0.5 right-0.5 hidden gap-0.5 group-hover:flex">
                    <button
                      className={cx("rounded p-0.5", favSet.has(s.id) ? "text-amber-400" : "text-ink-400 hover:text-amber-400")}
                      onClick={() => toggleFav.mutate({ id: s.id, fav: !favSet.has(s.id) })}
                      aria-label="Favori"
                    >
                      <Icon name="star" size={12} />
                    </button>
                    {(s.ownerId === me.id || canManageBoard) && (
                      <button className="rounded p-0.5 text-ink-400 hover:text-ink-100" onClick={() => setEditing(s)} aria-label="Düzenle">
                        <Icon name="edit" size={12} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
      {uploadOpen && <UploadModal guildId={tab === "me" ? null : guildId} onClose={() => setUploadOpen(false)} />}
      {editing && <EditSoundModal sound={editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function UploadModal({ guildId, onClose }: { guildId: string | null; onClose: () => void }) {
  const qc = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState("");
  const [emoji, setEmoji] = useState("🔊");
  const [category, setCategory] = useState("Genel");
  const [volume, setVolume] = useState(1);
  const [scope, setScope] = useState<"guild" | "me">(guildId ? "guild" : "me");
  const m = useMutation({
    mutationFn: () => {
      const fd = new FormData();
      fd.append("file", file!);
      fd.append("name", name.trim());
      fd.append("emoji", emoji);
      fd.append("category", category.trim() || "Genel");
      fd.append("volume", String(volume));
      if (scope === "guild" && guildId) fd.append("guildId", guildId);
      return api.uploadSound(fd);
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["sounds"] });
      toast("Ses yüklendi");
      onClose();
    },
    onError: (e) => toast((e as Error).message),
  });
  const tooBig = !!file && file.size > LIMITS.SOUND_MAX_BYTES;
  return (
    <Modal title="Ses yükle" onClose={onClose}>
      <form
        className="space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (file && name.trim() && !tooBig) m.mutate();
        }}
      >
        <label className="block rounded-xl border border-dashed border-ink-600 p-4 text-center text-sm text-ink-300 hover:border-amber-500">
          <input
            type="file"
            accept=".mp3,.wav,.ogg,audio/mpeg,audio/wav,audio/ogg"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0] ?? null;
              setFile(f);
              if (f && !name) setName(f.name.replace(/\.[^.]+$/, "").slice(0, LIMITS.SOUND_NAME_MAX));
            }}
          />
          {file ? `${file.name} (${(file.size / 1024).toFixed(0)} KB)` : "MP3, WAV veya OGG seç (en fazla 2 MB)"}
        </label>
        {tooBig && <p className="text-xs text-danger-500">Dosya 2 MB sınırını aşıyor.</p>}
        <div className="grid grid-cols-[72px_1fr] gap-2">
          <TextInput label="Simge" value={emoji} maxLength={8} onChange={(e) => setEmoji(e.target.value)} />
          <TextInput label="Ad" value={name} maxLength={LIMITS.SOUND_NAME_MAX} onChange={(e) => setName(e.target.value)} />
        </div>
        <TextInput label="Kategori" value={category} maxLength={LIMITS.SOUND_CATEGORY_MAX} onChange={(e) => setCategory(e.target.value)} />
        <label className="block text-xs text-ink-300">
          Ses seviyesi: {Math.round(volume * 100)}%
          <input type="range" min={0.05} max={1} step={0.05} value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="w-full accent-amber-500" />
        </label>
        {guildId && (
          <div className="flex gap-2 text-sm">
            {(["guild", "me"] as const).map((s) => (
              <button type="button" key={s} onClick={() => setScope(s)} className={cx("flex-1 rounded-lg border px-3 py-1.5", scope === s ? "border-amber-500 text-amber-400" : "border-ink-700 text-ink-300")}>
                {s === "guild" ? "Sunucu paneli" : "Kişisel panel"}
              </button>
            ))}
          </div>
        )}
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button type="submit" disabled={!file || !name.trim() || tooBig || m.isPending}>
            {m.isPending ? "Yükleniyor…" : "Yükle"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}

function EditSoundModal({ sound, onClose }: { sound: SoundDTO; onClose: () => void }) {
  const qc = useQueryClient();
  const [name, setName] = useState(sound.name);
  const [emoji, setEmoji] = useState(sound.emoji);
  const [category, setCategory] = useState(sound.category);
  const [volume, setVolume] = useState(sound.volume);
  const { soundKeybinds, setKeybind } = useSettings();
  const [capturing, setCapturing] = useState(false);

  useEffect(() => {
    if (!capturing) return;
    const on = (e: KeyboardEvent) => {
      e.preventDefault();
      if (["Control", "Shift", "Alt", "Meta"].includes(e.key)) return;
      if (e.key === "Escape") return setCapturing(false);
      const mods = [e.ctrlKey && "Ctrl", e.altKey && "Alt", e.shiftKey && "Shift"].filter(Boolean);
      const key = e.code.startsWith("Key") ? e.code.slice(3) : e.code.startsWith("Digit") ? e.code.slice(5) : e.code.startsWith("Numpad") ? `num${e.code.slice(6)}` : e.key.length === 1 ? e.key.toUpperCase() : e.code;
      setKeybind(sound.id, [...mods, key].join("+"));
      setCapturing(false);
    };
    window.addEventListener("keydown", on, true);
    return () => window.removeEventListener("keydown", on, true);
  }, [capturing, setKeybind, sound.id]);

  async function save() {
    try {
      await api.updateSound(sound.id, { name, emoji, category, volume });
      void qc.invalidateQueries({ queryKey: ["sounds"] });
      onClose();
    } catch (e) {
      toast((e as Error).message);
    }
  }
  async function remove() {
    if (!confirm(`"${sound.name}" silinsin mi?`)) return;
    try {
      await api.deleteSound(sound.id);
      setKeybind(sound.id, null);
      void qc.invalidateQueries({ queryKey: ["sounds"] });
      onClose();
    } catch (e) {
      toast((e as Error).message);
    }
  }

  return (
    <Modal title="Sesi düzenle" onClose={onClose}>
      <div className="space-y-3">
        <div className="grid grid-cols-[72px_1fr] gap-2">
          <TextInput label="Simge" value={emoji} maxLength={8} onChange={(e) => setEmoji(e.target.value)} />
          <TextInput label="Ad" value={name} maxLength={LIMITS.SOUND_NAME_MAX} onChange={(e) => setName(e.target.value)} />
        </div>
        <TextInput label="Kategori" value={category} onChange={(e) => setCategory(e.target.value)} />
        <label className="block text-xs text-ink-300">
          Ses seviyesi: {Math.round(volume * 100)}%
          <input type="range" min={0.05} max={1} step={0.05} value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="w-full accent-amber-500" />
        </label>
        <div className="flex items-center justify-between rounded-lg bg-ink-950 px-3 py-2 text-sm">
          <span className="text-ink-300">Kısayol: {capturing ? "bir tuşa bas…" : (soundKeybinds[sound.id] ?? "yok")}</span>
          <div className="flex gap-1">
            <Button type="button" variant="subtle" className="h-7 px-2 text-xs" onClick={() => setCapturing(true)}>
              Ata
            </Button>
            {soundKeybinds[sound.id] && (
              <Button type="button" variant="ghost" className="h-7 px-2 text-xs" onClick={() => setKeybind(sound.id, null)}>
                Kaldır
              </Button>
            )}
          </div>
        </div>
        <div className="flex justify-between pt-2">
          <Button variant="danger" onClick={() => void remove()}>
            Sil
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => void soundPlayer.preview(sound.sha256, sound.url, volume)}>
              <Icon name="play" size={14} /> Önizle
            </Button>
            <Button onClick={() => void save()}>Kaydet</Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}
