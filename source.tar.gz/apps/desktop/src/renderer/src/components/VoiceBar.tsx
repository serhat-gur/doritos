import { SCREEN_PRESETS, type ScreenPreset } from "@yanki/shared";
import { useEffect, useState } from "react";
import type { ScreenSource, UpdateStatus } from "../../../preload/api";
import type { GuildDetail } from "../lib/api";
import { bridge, isElectron } from "../lib/bridge";
import { captureScreen, screenShare, useScreen } from "../media/screen-share";
import { voiceSession } from "../media/voice-session";
import { useRealtime, useSession, useVoice } from "../stores/app";
import { useSettings } from "../stores/settings";
import { Soundboard } from "./Soundboard";
import { Avatar, Button, cx, Icon, IconButton, Modal, toast } from "./ui";

/** Sesli kanala bağlıyken görünen panel: durum, kalite, ekran paylaşımı, soundboard, ayrılma. */
export function VoiceConnectionPanel({ guild }: { guild: GuildDetail }) {
  const v = useVoice();
  const status = useRealtime((s) => s.guilds[guild.guild.id]?.status);
  const sharing = useScreen((s) => s.sharing);
  const [soundboardOpen, setSoundboardOpen] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const { inputMode, macros } = useSettings();

  if (v.error && v.state === "error") {
    return (
      <div className="mx-2 mb-2 flex items-start gap-2 rounded-xl bg-danger-500/10 p-3 text-xs text-danger-500" role="alert">
        <span className="flex-1">{v.error}</span>
        <button onClick={() => useVoice.getState().set({ error: null, state: "idle" })} aria-label="Kapat">
          <Icon name="x" size={14} />
        </button>
      </div>
    );
  }
  if (!v.channelId || v.guildId !== guild.guild.id) return null;

  const channel = guild.channels.find((c) => c.id === v.channelId);
  const stats = Object.values(v.peerStats);
  const worstRtt = stats.reduce<number | null>((acc, s) => (s.rttMs !== null && (acc === null || s.rttMs > acc) ? s.rttMs : acc), null);
  const loss = stats.reduce((acc, s) => Math.max(acc, s.packetLossPct ?? 0), 0);
  const relayed = stats.some((s) => s.relayed);
  const quality = v.state !== "connected" || status !== "open" ? "bad" : worstRtt === null ? "ok" : worstRtt > 250 || loss > 5 ? "bad" : worstRtt > 120 || loss > 1 ? "meh" : "good";

  return (
    <div className="relative mx-2 mb-2 rounded-xl border border-ink-700 bg-ink-800 p-3">
      <div className="flex items-center gap-1.5">
        <Icon name="signal" size={16} className={cx(quality === "good" ? "text-voice-400" : quality === "meh" ? "text-amber-500" : quality === "bad" ? "text-danger-500" : "text-ink-400")} />
        <div className="min-w-0 flex-1">
          <p className={cx("text-xs font-semibold", v.state === "connected" ? "text-voice-400" : "text-amber-400")}>
            {v.state === "connected" ? "Ses bağlı" : v.state === "reconnecting" || status === "reconnecting" ? "Yeniden bağlanıyor…" : "Bağlanıyor…"}
          </p>
          <p className="truncate text-[11px] text-ink-400" title={relayed ? "TURN üzerinden" : "Doğrudan bağlantı"}>
            {channel?.name ?? "Ses"}
            {worstRtt !== null && ` · ${worstRtt} ms`}
            {loss > 0 && ` · %${loss} kayıp`}
            {relayed && " · TURN"}
          </p>
        </div>
        <IconButton
          icon={sharing ? "monitorOff" : "monitor"}
          label={sharing ? "Paylaşımı durdur" : "Ekran paylaş"}
          className={sharing ? "bg-voice-500/15 text-voice-400" : ""}
          onClick={() => (sharing ? void screenShare.stop() : setPickerOpen(true))}
        />
        <IconButton icon="grid" label="Ses paneli" onClick={() => setSoundboardOpen((o) => !o)} className={soundboardOpen ? "bg-amber-500/15 text-amber-400" : ""} />
        <IconButton icon="phoneOff" label="Bağlantıyı kes" danger onClick={() => void voiceSession.leave()} />
      </div>
      {(v.serverMute || v.serverDeaf) && (
        <p className="mt-2 text-[11px] text-danger-500">Bir yetkili seni sunucuda {v.serverDeaf ? "sağırlaştırdı" : "susturdu"}.</p>
      )}
      {inputMode === "ptt" && (
        <p className={cx("mt-2 text-[11px]", v.pttActive ? "text-voice-400" : "text-ink-500")}>
          Bas-konuş: {v.pttActive ? "konuşuyorsun" : macros.ptt ? `${macros.ptt.label} basılı tut` : "tuş atanmadı (Ayarlar → Makrolar)"}
        </p>
      )}
      {soundboardOpen && <Soundboard guildId={guild.guild.id} canManage={guild.guild.myPermissions} onClose={() => setSoundboardOpen(false)} />}
      {pickerOpen && <ScreenPicker onClose={() => setPickerOpen(false)} />}
    </div>
  );
}

/** Ekran / pencere seçici + kalite (720p/1080p, 15/30/60 FPS) + sistem sesi. */
function ScreenPicker({ onClose }: { onClose: () => void }) {
  const { screenPreset, screenAudio, set } = useSettings();
  const [sources, setSources] = useState<ScreenSource[] | null>(null);
  const [picked, setPicked] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isElectron) return;
    void bridge.screen.sources().then((s) => {
      setSources(s);
      setPicked(s.find((x) => x.isScreen)?.id ?? s[0]?.id ?? null);
    });
  }, []);

  async function start() {
    setBusy(true);
    try {
      const audio = screenAudio && bridge.screen.systemAudioSupported;
      if (isElectron) {
        if (!picked) return;
        await bridge.screen.select(picked, audio);
      }
      const stream = await captureScreen(screenPreset, audio);
      await screenShare.start(screenPreset, stream, audio);
      onClose();
    } catch (err) {
      const name = (err as { name?: string }).name;
      toast(name === "NotAllowedError" ? "Ekran paylaşımı iptal edildi" : (err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const resolutions = ["720p", "1080p"] as const;
  const fpsList = [15, 30, 60] as const;
  const [res, fps] = [screenPreset.startsWith("1080") ? "1080p" : "720p", SCREEN_PRESETS[screenPreset].fps];
  const choose = (r: string, f: number) => set({ screenPreset: `${r}${f}` as ScreenPreset });

  return (
    <Modal title="Ekran paylaş" onClose={onClose} width={640}>
      {isElectron && (
        <div className="mb-4 grid max-h-72 grid-cols-3 gap-2 overflow-y-auto">
          {sources === null && <p className="col-span-3 text-sm text-ink-400">Ekranlar yükleniyor…</p>}
          {sources?.map((s) => (
            <button key={s.id} onClick={() => setPicked(s.id)} className={cx("rounded-lg border p-1.5 text-left", picked === s.id ? "border-amber-500 bg-amber-500/10" : "border-ink-700 hover:border-ink-600")}>
              <img src={s.thumbnail} alt="" className="aspect-video w-full rounded bg-black object-contain" />
              <span className="mt-1 block truncate text-xs text-ink-200">{s.isScreen ? `🖥 ${s.name}` : s.name}</span>
            </button>
          ))}
        </div>
      )}
      {!isElectron && <p className="mb-4 text-sm text-ink-400">Başlatınca tarayıcının ekran seçicisi açılır.</p>}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="mb-1.5 text-xs font-semibold tracking-wide text-ink-300 uppercase">Çözünürlük</p>
          <div className="flex gap-2">
            {resolutions.map((r) => (
              <button key={r} onClick={() => choose(r, fps)} className={cx("flex-1 rounded-lg border px-3 py-1.5 text-sm", res === r ? "border-amber-500 text-amber-400" : "border-ink-700 text-ink-300")}>
                {r}
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="mb-1.5 text-xs font-semibold tracking-wide text-ink-300 uppercase">Kare hızı</p>
          <div className="flex gap-2">
            {fpsList.map((f) => (
              <button key={f} onClick={() => choose(res, f)} className={cx("flex-1 rounded-lg border px-3 py-1.5 text-sm", fps === f ? "border-amber-500 text-amber-400" : "border-ink-700 text-ink-300")}>
                {f} FPS
              </button>
            ))}
          </div>
        </div>
      </div>
      <p className="mt-2 text-[11px] text-ink-500">
        Üst sınır ~{(SCREEN_PRESETS[screenPreset].maxBitrate / 1_000_000).toFixed(1)} Mbps; bağlantı ve izleyici sayısına göre otomatik düşer. Doğrudan (P2P) gönderildiği için ücret yoktur.
      </p>
      {bridge.screen.systemAudioSupported && (
        <label className="mt-3 flex items-start gap-2 text-sm text-ink-300">
          <input type="checkbox" className="mt-0.5 accent-amber-500" checked={screenAudio} onChange={(e) => set({ screenAudio: e.target.checked })} />
          <span>
            Sistem sesini de paylaş
            <span className="block text-[11px] text-ink-500">Bilgisayarındaki tüm sesler yayına girer (sohbetteki arkadaşlarının sesi dahil); oyun/film için aç, sohbet için kapalı tut.</span>
          </span>
        </label>
      )}
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>
          Vazgeç
        </Button>
        <Button onClick={() => void start()} disabled={busy || (isElectron && !picked)}>
          {busy ? "Başlatılıyor…" : "Yayını başlat"}
        </Button>
      </div>
    </Modal>
  );
}

export function UserPanel({ onOpenSettings }: { onOpenSettings: () => void }) {
  const user = useSession((s) => s.user);
  const { selfMute, selfDeaf, speaking, channelId, serverMute } = useVoice();
  if (!user) return null;
  return (
    <div className="flex items-center gap-1.5 bg-ink-950/60 px-2 py-2">
      <Avatar name={user.displayName} id={user.id} url={user.avatarUrl} size={32} speaking={!!channelId && speaking} status={user.status} />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold">{user.displayName}</p>
        <p className="truncate text-[11px] text-ink-400">@{user.username}</p>
      </div>
      <IconButton
        icon={selfMute || serverMute ? "micOff" : "mic"}
        label={selfMute ? "Mikrofonu aç" : "Mikrofonu kapat"}
        active={selfMute || serverMute}
        onClick={() => voiceSession.setMute(!selfMute)}
      />
      <IconButton icon={selfDeaf ? "headphonesOff" : "headphones"} label={selfDeaf ? "Sağırlaştırmayı kaldır" : "Sağırlaştır"} active={selfDeaf} onClick={() => voiceSession.setDeaf(!selfDeaf)} />
      <IconButton icon="settings" label="Ayarlar" onClick={onOpenSettings} />
    </div>
  );
}

/** Yeni sürüm indirildiğinde üstte çıkan şerit. */
export function UpdateBanner() {
  const [status, setStatus] = useState<UpdateStatus>({ state: "idle" });
  useEffect(() => bridge.updates.onStatus(setStatus), []);
  if (status.state !== "ready") return null;
  return (
    <div className="flex items-center justify-center gap-3 bg-voice-500 px-4 py-1.5 text-sm font-medium text-ink-950" role="status">
      Doritos {status.version} hazır.
      <button className="rounded bg-ink-950/20 px-2 py-0.5 hover:bg-ink-950/30" onClick={() => bridge.updates.install()}>
        Yeniden başlat ve güncelle
      </button>
    </div>
  );
}
