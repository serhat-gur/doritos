import { useEffect, useRef, useState } from "react";
import type { GuildDetail } from "../lib/api";
import { screenShare, useScreen } from "../media/screen-share";
import { useVoice } from "../stores/app";
import { cx, Icon } from "./ui";

/** İzlenen ekran paylaşımları (birden fazla yayın yan yana) ve kendi yayınının önizlemesi. */
export function Stage({ detail }: { detail: GuildDetail }) {
  const { watching, sharing, localStream, viewers } = useScreen();
  const inThisGuild = useVoice((s) => s.guildId === detail.guild.id);
  const ids = Object.keys(watching);
  if (!inThisGuild || (ids.length === 0 && !sharing)) return null;
  const nameOf = (id: string) => detail.members.find((m) => m.user.id === id)?.user.displayName ?? "?";
  const tiles = ids.length + (sharing ? 1 : 0);
  return (
    <section className="border-b border-ink-950/60 bg-ink-950 p-3" aria-label="Yayınlar">
      <div className={cx("grid gap-3", tiles > 1 ? "grid-cols-2" : "grid-cols-1")}>
        {ids.map((id) => (
          <VideoTile key={id} stream={watching[id] ?? null} label={nameOf(id)} onClose={() => screenShare.unwatch(id)} />
        ))}
        {sharing && localStream && <VideoTile stream={localStream} label={`Senin yayının · ${viewers.length} izleyici`} muted onClose={() => void screenShare.stop()} closeLabel="Yayını durdur" />}
      </div>
    </section>
  );
}

function VideoTile({ stream, label, muted, onClose, closeLabel = "İzlemeyi bırak" }: { stream: MediaStream | null; label: string; muted?: boolean; onClose: () => void; closeLabel?: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [volume, setVolume] = useState(1);
  const hasAudio = !!stream?.getAudioTracks().length && !muted;
  useEffect(() => {
    if (ref.current) ref.current.srcObject = stream;
  }, [stream]);
  useEffect(() => {
    if (ref.current) ref.current.volume = volume;
  }, [volume]);
  return (
    <div className="group relative aspect-video overflow-hidden rounded-xl bg-black" data-testid="stream-tile">
      {stream ? (
        <video ref={ref} autoPlay playsInline muted={muted} className="h-full w-full object-contain" />
      ) : (
        <div className="flex h-full items-center justify-center text-sm text-ink-400">Yayına bağlanılıyor…</div>
      )}
      <div className="absolute inset-x-0 bottom-0 flex items-center gap-2 bg-gradient-to-t from-black/80 to-transparent px-3 py-2 opacity-0 transition-opacity group-hover:opacity-100">
        <span className="flex items-center gap-1.5 text-xs font-semibold">
          <span className="rounded bg-danger-500 px-1.5 py-0.5 text-[10px] text-white">CANLI</span> {label}
        </span>
        <div className="flex-1" />
        {hasAudio && <input type="range" min={0} max={1} step={0.05} value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="w-24 accent-amber-500" aria-label="Yayın sesi" />}
        <button className="rounded p-1 hover:bg-white/10" aria-label="Tam ekran" onClick={() => void ref.current?.requestFullscreen()}>
          <Icon name="maximize" size={16} />
        </button>
        <button className="rounded p-1 hover:bg-white/10" aria-label={closeLabel} title={closeLabel} onClick={onClose}>
          <Icon name="x" size={16} />
        </button>
      </div>
    </div>
  );
}
