import { useEffect, useState } from "react";
import type { PresenceStatus } from "@yanki/shared";
import type { UpdateStatus } from "../../../preload/api";
import { api, apiConfig } from "../lib/api";
import { bridge, isElectron } from "../lib/bridge";
import { squareImage } from "../lib/image";
import { realtime } from "../lib/realtime";
import { MACRO_LABELS } from "../media/macros";
import { soundPlayer } from "../media/sound-player";
import { voiceSession } from "../media/voice-session";
import { useSession, useVoice } from "../stores/app";
import { useSettings, type MacroAction } from "../stores/settings";
import { Avatar, Button, cx, Modal, TextInput, toast } from "./ui";

export function SettingsModal({ onClose }: { onClose: () => void }) {
  const s = useSettings();
  const user = useSession((x) => x.user)!;
  const setUser = useSession((x) => x.setUser);
  const inputLevel = useVoice((v) => v.inputLevel);
  const inVoice = useVoice((v) => !!v.channelId);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [capturing, setCapturing] = useState<MacroAction | null>(null);
  const [apiUrl, setApiUrl] = useState(apiConfig.getBaseUrl());
  const [startup, setStartup] = useState(false);
  const [displayName, setDisplayName] = useState(user.displayName);
  const [bio, setBio] = useState(user.bio);
  const [update, setUpdate] = useState<UpdateStatus>({ state: "idle" });

  useEffect(() => {
    void navigator.mediaDevices?.enumerateDevices().then(setDevices);
    void bridge.settings.get().then((x) => setStartup(x.launchAtStartup));
    return bridge.updates.onStatus(setUpdate);
  }, []);

  const inputs = devices.filter((d) => d.kind === "audioinput");
  const outputs = devices.filter((d) => d.kind === "audiooutput");

  function update_(patch: Parameters<typeof s.set>[0]) {
    s.set(patch);
    void voiceSession.reconfigure();
    if (patch.outputDeviceId) void soundPlayer.setOutputDevice(patch.outputDeviceId);
    if (patch.soundboardVolume !== undefined) soundPlayer.setMasterVolume(patch.soundboardVolume);
  }

  async function captureMacro(action: MacroAction) {
    setCapturing(action);
    const r = await bridge.input.capture();
    setCapturing(null);
    if (r) s.setMacro(action, r);
    else toast("Tuş algılanmadı");
  }

  async function saveProfile(status?: PresenceStatus) {
    try {
      const u = await api.updateMe({ displayName, bio, ...(status ? { status } : {}) });
      setUser(u);
      if (status) realtime.sendAll({ t: "presence.set", status });
      toast("Profil kaydedildi");
    } catch (e) {
      toast((e as Error).message);
    }
  }

  async function logout() {
    try {
      await api.logout();
    } catch {
      /* çevrimdışı olsa da yerel oturum silinir */
    }
    window.dispatchEvent(new Event("yanki:logout"));
  }

  const select = "h-10 w-full rounded-lg border border-ink-700 bg-ink-950 px-2 text-ink-100 outline-none focus:border-amber-500";
  const h3 = "text-xs font-semibold tracking-wider text-ink-400 uppercase";
  const macroActions: MacroAction[] = s.inputMode === "ptt" ? ["toggleMute", "toggleDeafen", "ptt"] : ["toggleMute", "toggleDeafen"];
  return (
    <Modal title="Ayarlar" onClose={onClose} width={580}>
      <div className="space-y-6">
        <section className="space-y-3">
          <h3 className={h3}>Profil</h3>
          <div className="flex items-center gap-3">
            <Avatar name={user.displayName} id={user.id} url={user.avatarUrl} size={56} />
            <label className="cursor-pointer rounded-lg bg-ink-750 px-3 py-1.5 text-sm hover:bg-ink-700">
              Profil resmi değiştir
              <input
                type="file"
                accept="image/png,image/jpeg,image/gif,image/webp"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  try {
                    setUser(await api.uploadAvatar(await squareImage(f)));
                    toast("Profil resmi güncellendi");
                  } catch (err) {
                    toast((err as Error).message);
                  }
                }}
              />
            </label>
            {user.avatarUrl && (
              <button
                className="text-xs text-ink-400 hover:text-danger-500"
                onClick={async () => {
                  await api.removeAvatar().catch(() => {});
                  setUser({ ...user, avatarUrl: null });
                }}
              >
                Kaldır
              </button>
            )}
          </div>
          <TextInput label="Görünen ad" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
          <TextInput label="Hakkında" value={bio} maxLength={190} onChange={(e) => setBio(e.target.value)} />
          <div className="flex flex-wrap gap-2">
            {(["online", "busy", "idle", "invisible"] as const).map((st) => (
              <button
                key={st}
                onClick={() => void saveProfile(st)}
                className={cx("rounded-lg border px-3 py-1 text-xs", user.status === st ? "border-amber-500 text-amber-400" : "border-ink-700 text-ink-300 hover:bg-ink-750")}
              >
                {{ online: "Çevrimiçi", busy: "Meşgul", idle: "Boşta", invisible: "Görünmez" }[st]}
              </button>
            ))}
            <div className="flex-1" />
            <Button variant="subtle" className="h-7 px-3 text-xs" onClick={() => void saveProfile()}>
              Kaydet
            </Button>
          </div>
        </section>

        <section className="space-y-3">
          <h3 className={h3}>Ses</h3>
          <label className="block text-xs text-ink-300">
            Mikrofon
            <select className={select} value={s.inputDeviceId} onChange={(e) => update_({ inputDeviceId: e.target.value })}>
              <option value="default">Varsayılan</option>
              {inputs.map((d) => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.label || "Mikrofon"}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs text-ink-300">
            Hoparlör / kulaklık
            <select className={select} value={s.outputDeviceId} onChange={(e) => update_({ outputDeviceId: e.target.value })}>
              <option value="default">Varsayılan</option>
              {outputs.map((d) => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.label || "Çıkış"}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs text-ink-300">
            Ses algılama hassasiyeti {inVoice ? "" : "(seviye göstergesi seste çalışır)"}
            <div className="relative mt-1 h-2 overflow-hidden rounded bg-ink-950">
              <div className="absolute inset-y-0 left-0 bg-voice-500 transition-[width]" style={{ width: `${inputLevel * 100}%` }} />
              <div className="absolute inset-y-0 w-0.5 bg-amber-400" style={{ left: `${Math.min(1, s.vadThreshold * 8) * 100}%` }} />
            </div>
            <input type="range" min={0.002} max={0.12} step={0.002} value={s.vadThreshold} onChange={(e) => s.set({ vadThreshold: Number(e.target.value) })} className="w-full accent-amber-500" />
          </label>
          <div className="flex gap-4 text-sm text-ink-300">
            <label className="flex items-center gap-2">
              <input type="checkbox" className="accent-amber-500" checked={s.noiseSuppression} onChange={(e) => update_({ noiseSuppression: e.target.checked })} /> Gürültü bastırma
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" className="accent-amber-500" checked={s.echoCancellation} onChange={(e) => update_({ echoCancellation: e.target.checked })} /> Yankı engelleme
            </label>
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-300">
            <input type="checkbox" className="accent-amber-500" checked={s.voiceCues} onChange={(e) => s.set({ voiceCues: e.target.checked })} /> Odaya giriş / çıkış sesleri
          </label>
          <label className="block text-xs text-ink-300">
            AFK alarmı ses seviyesi: {Math.round(s.afkAlarmVolume * 100)}%
            <input type="range" min={0} max={1} step={0.05} value={s.afkAlarmVolume} onChange={(e) => s.set({ afkAlarmVolume: Number(e.target.value) })} className="w-full accent-amber-500" />
          </label>
          <label className="block text-xs text-ink-300">
            Soundboard ses seviyesi: {Math.round(s.soundboardVolume * 100)}%
            <input type="range" min={0} max={1} step={0.05} value={s.soundboardVolume} onChange={(e) => update_({ soundboardVolume: Number(e.target.value) })} className="w-full accent-amber-500" />
          </label>
        </section>

        <section className="space-y-3">
          <h3 className={h3}>Makrolar (klavye / mouse)</h3>
          <p className="text-[11px] text-ink-500">
            {bridge.input.global
              ? "Mouse yan tuşları (Mouse 4/5), orta tuş veya klavye tuşları atanabilir. Oyundayken de çalışır."
              : "Tarayıcı sürümünde makrolar yalnızca pencere odaktayken çalışır."}
          </p>
          {macroActions.map((a) => (
            <div key={a} className="flex items-center justify-between rounded-lg bg-ink-950 px-3 py-2 text-sm">
              <span className="text-ink-200">{MACRO_LABELS[a]}</span>
              <div className="flex items-center gap-2">
                <span className={cx("min-w-28 rounded-md px-2 py-0.5 text-center text-xs", s.macros[a] ? "bg-ink-750 text-ink-100" : "text-ink-500")}>
                  {capturing === a ? "Bir tuşa / mouse tuşuna bas…" : (s.macros[a]?.label ?? "Atanmadı")}
                </span>
                <Button variant="subtle" className="h-7 px-2 text-xs" disabled={capturing !== null} onClick={() => void captureMacro(a)} aria-label={`${MACRO_LABELS[a]} ata`}>
                  Ata
                </Button>
                {s.macros[a] && (
                  <Button variant="ghost" className="h-7 px-2 text-xs" onClick={() => s.setMacro(a, null)}>
                    Kaldır
                  </Button>
                )}
              </div>
            </div>
          ))}
          <label className="flex items-center gap-2 text-sm text-ink-300">
            <input type="checkbox" className="accent-amber-500" checked={s.macroSounds} onChange={(e) => s.set({ macroSounds: e.target.checked })} /> Makroyla susturunca kısa onay sesi çal
          </label>
          <label className="flex items-start gap-2 text-sm text-ink-300">
            <input type="checkbox" className="mt-0.5 accent-amber-500" checked={s.inputMode === "ptt"} onChange={(e) => update_({ inputMode: e.target.checked ? "ptt" : "vad" })} />
            <span>
              Bas-konuş kullan
              <span className="block text-[11px] text-ink-500">Kapalıyken ses algılama kullanılır (varsayılan). Açınca yalnızca atadığın tuş basılıyken konuşursun.</span>
            </span>
          </label>
        </section>

        <section className="space-y-3">
          <h3 className={h3}>Uygulama</h3>
          <div className="flex items-end gap-2">
            <div className="flex-1">
              <TextInput label="Sunucu adresi" value={apiUrl} onChange={(e) => setApiUrl(e.target.value)} />
            </div>
            <Button
              variant="subtle"
              onClick={async () => {
                const next = await bridge.settings.set({ apiUrl });
                apiConfig.setBaseUrl(next.apiUrl);
                toast("Kaydedildi — yeniden giriş yapman gerekebilir");
              }}
            >
              Kaydet
            </Button>
          </div>
          {isElectron && (
            <>
              <label className="flex items-center gap-2 text-sm text-ink-300">
                <input
                  type="checkbox"
                  className="accent-amber-500"
                  checked={startup}
                  onChange={async (e) => {
                    const next = await bridge.settings.set({ launchAtStartup: e.target.checked });
                    setStartup(next.launchAtStartup);
                  }}
                />
                Windows açılışında başlat
              </label>
              <div className="flex items-center justify-between rounded-lg bg-ink-950 px-3 py-2 text-sm">
                <span className="text-ink-300">
                  Sürüm {bridge.updates.version}
                  <span className="ml-2 text-xs text-ink-500">
                    {update.state === "checking" && "denetleniyor…"}
                    {update.state === "none" && "güncel"}
                    {update.state === "available" && `yeni sürüm bulundu, indiriliyor`}
                    {update.state === "downloading" && `indiriliyor %${update.percent ?? 0}`}
                    {update.state === "ready" && `${update.version} hazır`}
                    {update.state === "error" && update.message}
                  </span>
                </span>
                {update.state === "ready" ? (
                  <Button className="h-7 px-2 text-xs" onClick={() => bridge.updates.install()}>
                    Yeniden başlat
                  </Button>
                ) : (
                  <Button variant="subtle" className="h-7 px-2 text-xs" onClick={() => void bridge.updates.check()}>
                    Güncellemeleri denetle
                  </Button>
                )}
              </div>
            </>
          )}
        </section>

        <div className="flex justify-between border-t border-ink-700 pt-4">
          <Button variant="danger" onClick={() => void logout()}>
            Çıkış yap
          </Button>
          <Button variant="ghost" onClick={onClose}>
            Kapat
          </Button>
        </div>
      </div>
    </Modal>
  );
}
