import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { DmChannelDTO, FriendDTO } from "@yanki/shared";
import { useState } from "react";
import { api } from "../lib/api";
import { useRealtime, useSession } from "../stores/app";
import { Chat } from "./Chat";
import { Avatar, Button, cx, Icon, IconButton, Modal, toast } from "./ui";
import { UserPanel } from "./VoiceBar";

/** Ana sayfa: arkadaşlar + özel mesajlar. */
export function Home({ onOpenSettings }: { onOpenSettings: () => void }) {
  const dms = useQuery({ queryKey: ["dms"], queryFn: api.dms });
  const { selectedChannelId, selectChannel } = useSession();
  const me = useSession((s) => s.user)!;
  const dmId = selectedChannelId["@me"];
  const unread = useRealtime((s) => s.unread);
  const presence = useRealtime((s) => s.guilds["@me"]?.presence ?? {});
  const [groupOpen, setGroupOpen] = useState(false);
  const current = dms.data?.find((d) => d.id === dmId);

  return (
    <>
      <aside className="flex w-60 shrink-0 flex-col bg-ink-850">
        <header className="flex h-12 items-center border-b border-ink-950/60 px-3">
          <h2 className="font-display font-semibold">Ana sayfa</h2>
        </header>
        <div className="flex-1 overflow-y-auto px-2 py-3">
          <button
            onClick={() => selectChannel("@me", "")}
            className={cx("mb-3 flex w-full items-center gap-2 rounded-lg px-2 py-2", !dmId ? "bg-ink-700 text-ink-100" : "text-ink-300 hover:bg-ink-750")}
          >
            <Icon name="users" /> Arkadaşlar
          </button>
          <div className="mb-1 flex items-center justify-between px-2">
            <span className="text-[11px] font-semibold tracking-wider text-ink-400 uppercase">Özel mesajlar</span>
            <button className="text-ink-400 hover:text-ink-100" title="Grup sohbeti oluştur" onClick={() => setGroupOpen(true)}>
              <Icon name="plus" size={14} />
            </button>
          </div>
          {dms.data?.map((d) => {
            const others = d.members.filter((m) => m.id !== me.id);
            const title = d.name ?? others.map((m) => m.displayName).join(", ");
            const single = d.type === "dm" ? others[0] : undefined;
            return (
              <button
                key={d.id}
                onClick={() => selectChannel("@me", d.id)}
                className={cx("flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left", d.id === dmId ? "bg-ink-700 text-ink-100" : "text-ink-300 hover:bg-ink-750")}
              >
                {single ? (
                  <Avatar name={single.displayName} id={single.id} url={single.avatarUrl} size={30} status={(presence[single.id] as string) ?? "offline"} />
                ) : (
                  <div className="flex h-[30px] w-[30px] items-center justify-center rounded-full bg-ink-700">
                    <Icon name="users" size={15} />
                  </div>
                )}
                <span className={cx("flex-1 truncate text-sm", !!unread[d.id] && "font-semibold text-ink-100")}>{title}</span>
                {!!unread[d.id] && d.id !== dmId && <span className="rounded-full bg-amber-500 px-1.5 text-[11px] font-bold text-ink-950">{unread[d.id]}</span>}
              </button>
            );
          })}
        </div>
        <UserPanel onOpenSettings={onOpenSettings} />
      </aside>
      <main className="flex min-w-0 flex-1 flex-col bg-ink-800">{current ? <Chat key={current.id} target={{ kind: "dm", dm: current }} /> : <Friends />}</main>
      {groupOpen && <GroupDmModal onClose={() => setGroupOpen(false)} />}
    </>
  );
}

type Tab = "online" | "all" | "pending" | "blocked" | "add";

function Friends() {
  const qc = useQueryClient();
  const friends = useQuery({ queryKey: ["friends"], queryFn: api.friends });
  const presence = useRealtime((s) => s.guilds["@me"]?.presence ?? {});
  const selectChannel = useSession((s) => s.selectChannel);
  const [tab, setTab] = useState<Tab>("online");
  const [username, setUsername] = useState("");
  const list = friends.data ?? [];
  const pendingCount = list.filter((f) => f.state === "incoming").length;
  const shown = list.filter((f) =>
    tab === "online"
      ? f.state === "friend" && presence[f.user.id] && presence[f.user.id] !== "offline"
      : tab === "all"
        ? f.state === "friend"
        : tab === "pending"
          ? f.state === "incoming" || f.state === "outgoing"
          : tab === "blocked"
            ? f.state === "blocked"
            : false,
  );

  const refresh = () => qc.invalidateQueries({ queryKey: ["friends"] });
  const act = (fn: () => Promise<unknown>, ok?: string) => async () => {
    try {
      await fn();
      if (ok) toast(ok);
      void refresh();
    } catch (e) {
      toast((e as Error).message);
    }
  };
  const add = useMutation({
    mutationFn: () => api.addFriend(username.trim()),
    onSuccess: (f) => {
      toast(f.state === "friend" ? "Artık arkadaşsınız" : "İstek gönderildi");
      setUsername("");
      void refresh();
    },
    onError: (e) => toast((e as Error).message),
  });

  async function openDm(f: FriendDTO) {
    try {
      const dm = await api.openDm([f.user.id]);
      qc.setQueryData<DmChannelDTO[]>(["dms"], (old) => [dm, ...(old ?? []).filter((d) => d.id !== dm.id)]);
      selectChannel("@me", dm.id);
    } catch (e) {
      toast((e as Error).message);
    }
  }

  const tabs: [Tab, string][] = [
    ["online", "Çevrimiçi"],
    ["all", "Tümü"],
    ["pending", pendingCount ? `Bekleyen (${pendingCount})` : "Bekleyen"],
    ["blocked", "Engellenen"],
  ];
  return (
    <>
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-ink-950/60 px-4">
        <Icon name="users" className="text-ink-400" />
        <h2 className="mr-4 font-display font-semibold">Arkadaşlar</h2>
        {tabs.map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)} className={cx("rounded-md px-2.5 py-1 text-sm", tab === k ? "bg-ink-700 text-ink-100" : "text-ink-300 hover:bg-ink-750")}>
            {label}
          </button>
        ))}
        <button onClick={() => setTab("add")} className={cx("rounded-md px-2.5 py-1 text-sm font-medium", tab === "add" ? "text-voice-400" : "bg-voice-500 text-ink-950")}>
          Arkadaş ekle
        </button>
      </header>
      <div className="flex-1 overflow-y-auto p-5">
        {tab === "add" ? (
          <form
            className="max-w-xl"
            onSubmit={(e) => {
              e.preventDefault();
              if (username.trim()) add.mutate();
            }}
          >
            <h3 className="font-display text-lg font-semibold">Arkadaş ekle</h3>
            <p className="mb-3 text-sm text-ink-400">Kullanıcı adıyla arkadaşlık isteği gönder.</p>
            <div className="flex gap-2">
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="kullanici.adi"
                aria-label="Kullanıcı adı"
                className="h-11 flex-1 rounded-lg border border-ink-700 bg-ink-950 px-3 outline-none focus:border-amber-500"
              />
              <Button type="submit" disabled={!username.trim() || add.isPending} className="h-11">
                İstek gönder
              </Button>
            </div>
          </form>
        ) : (
          <>
            <p className="mb-2 text-[11px] font-semibold tracking-wider text-ink-400 uppercase">{shown.length} kişi</p>
            {shown.length === 0 && <p className="mt-8 text-center text-ink-400">Burada kimse yok.</p>}
            <ul className="divide-y divide-ink-750">
              {shown.map((f) => (
                <li key={f.user.id} className="group flex items-center gap-3 rounded-lg px-2 py-2.5 hover:bg-ink-750/60" data-testid="friend-row">
                  <Avatar name={f.user.displayName} id={f.user.id} url={f.user.avatarUrl} size={36} status={f.state === "friend" ? ((presence[f.user.id] as string) ?? "offline") : undefined} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{f.user.displayName}</p>
                    <p className="text-xs text-ink-400">
                      @{f.user.username}
                      {f.state === "incoming" && " · gelen istek"}
                      {f.state === "outgoing" && " · gönderilen istek"}
                    </p>
                  </div>
                  {f.state === "friend" && <IconButton icon="message" label="Mesaj gönder" onClick={() => void openDm(f)} />}
                  {f.state === "incoming" && <IconButton icon="check" label="Kabul et" onClick={act(() => api.acceptFriend(f.user.id), "Artık arkadaşsınız")} />}
                  {(f.state === "incoming" || f.state === "outgoing" || f.state === "friend") && (
                    <IconButton
                      icon="x"
                      label={f.state === "friend" ? "Arkadaşlıktan çıkar" : f.state === "incoming" ? "Reddet" : "İsteği geri çek"}
                      onClick={act(async () => {
                        if (f.state === "friend" && !confirm(`${f.user.displayName} arkadaşlıktan çıkarılsın mı?`)) return;
                        await api.removeFriend(f.user.id);
                      })}
                    />
                  )}
                  {f.state === "blocked" ? (
                    <Button variant="subtle" className="h-8 text-xs" onClick={act(() => api.unblock(f.user.id), "Engel kaldırıldı")}>
                      Engeli kaldır
                    </Button>
                  ) : (
                    <IconButton
                      icon="ban"
                      label="Engelle"
                      danger
                      onClick={act(async () => {
                        if (confirm(`${f.user.displayName} engellensin mi? Sana mesaj ve istek gönderemez.`)) await api.block(f.user.id);
                      }, "Engellendi")}
                    />
                  )}
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </>
  );
}

function GroupDmModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const friends = useQuery({ queryKey: ["friends"], queryFn: api.friends });
  const selectChannel = useSession((s) => s.selectChannel);
  const [picked, setPicked] = useState<string[]>([]);
  const [name, setName] = useState("");
  const list = (friends.data ?? []).filter((f) => f.state === "friend");
  async function create() {
    try {
      const dm = await api.openDm(picked, name.trim() || undefined);
      qc.setQueryData<DmChannelDTO[]>(["dms"], (old) => [dm, ...(old ?? []).filter((d) => d.id !== dm.id)]);
      selectChannel("@me", dm.id);
      onClose();
    } catch (e) {
      toast((e as Error).message);
    }
  }
  return (
    <Modal title="Sohbet başlat" onClose={onClose}>
      <p className="mb-2 text-sm text-ink-400">Bir kişi seçersen birebir, birden fazla seçersen grup sohbeti açılır (en fazla 9 kişi).</p>
      <div className="max-h-64 space-y-1 overflow-y-auto">
        {list.length === 0 && <p className="text-sm text-ink-400">Önce arkadaş eklemelisin.</p>}
        {list.map((f) => (
          <label key={f.user.id} className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 hover:bg-ink-750">
            <input
              type="checkbox"
              className="accent-amber-500"
              checked={picked.includes(f.user.id)}
              onChange={(e) => setPicked(e.target.checked ? [...picked, f.user.id].slice(0, 9) : picked.filter((x) => x !== f.user.id))}
            />
            <Avatar name={f.user.displayName} id={f.user.id} url={f.user.avatarUrl} size={26} />
            <span className="text-sm">{f.user.displayName}</span>
          </label>
        ))}
      </div>
      {picked.length > 1 && (
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Grup adı (isteğe bağlı)" className="mt-3 h-10 w-full rounded-lg border border-ink-700 bg-ink-950 px-3 outline-none" />
      )}
      <div className="mt-4 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>
          Vazgeç
        </Button>
        <Button disabled={picked.length === 0} onClick={() => void create()}>
          Başlat
        </Button>
      </div>
    </Modal>
  );
}
