import { useQuery, useQueryClient } from "@tanstack/react-query";
import { hasFlag, LIMITS, Permission, type AttachmentDTO, type ChannelDTO, type DmChannelDTO, type FriendDTO, type MessageDTO } from "@yanki/shared";
import { Fragment, useEffect, useLayoutEffect, useRef, useState, type ClipboardEvent, type DragEvent, type KeyboardEvent, type ReactNode } from "react";
import { api, type GuildDetail } from "../lib/api";
import { bridge } from "../lib/bridge";
import { realtime } from "../lib/realtime";
import { useRealtime, useSession } from "../stores/app";
import { Avatar, cx, Icon, Modal, toast } from "./ui";

const GROUP_WINDOW_MS = 5 * 60 * 1000;
export const QUICK_EMOJI = ["👍", "❤️", "😂", "😮", "😢", "🔥", "🎉", "👀", "💀", "🙏", "😎", "🤝", "✅", "❌", "😡", "🥲", "🤔", "👏", "💯", "🍿"];

export type ChatTarget = { kind: "guild"; channel: ChannelDTO; detail: GuildDetail } | { kind: "dm"; dm: DmChannelDTO };

interface ChatInfo {
  id: string;
  scope: string; // gateway anahtarı: guildId veya "@me"
  title: string;
  icon: string;
  isDm: boolean;
  canSend: boolean;
  canManage: boolean;
  nameOf: (userId: string) => string | undefined;
  colorOf: (userId: string) => string | undefined;
}

function infoFor(t: ChatTarget, meId: string): ChatInfo {
  if (t.kind === "guild") {
    const { channel, detail } = t;
    return {
      id: channel.id,
      scope: detail.guild.id,
      title: channel.name,
      icon: channel.isPrivate ? "lock" : "hash",
      isDm: false,
      canSend: hasFlag(channel.myPermissions, Permission.SEND_MESSAGES),
      canManage: hasFlag(channel.myPermissions, Permission.MANAGE_MESSAGES),
      nameOf: (id) => {
        const m = detail.members.find((x) => x.user.id === id);
        return m ? (m.nickname ?? m.user.displayName) : undefined;
      },
      colorOf: (id) => {
        const m = detail.members.find((x) => x.user.id === id);
        if (!m) return undefined;
        return detail.roles.filter((r) => m.roleIds.includes(r.id) && r.color).sort((a, b) => b.position - a.position)[0]?.color ?? undefined;
      },
    };
  }
  const others = t.dm.members.filter((m) => m.id !== meId);
  return {
    id: t.dm.id,
    scope: "@me",
    title: t.dm.name ?? others.map((m) => m.displayName).join(", "),
    icon: t.dm.type === "group" ? "users" : "at",
    isDm: true,
    canSend: true,
    canManage: false,
    nameOf: (id) => t.dm.members.find((m) => m.id === id)?.displayName,
    colorOf: () => undefined,
  };
}

export function Chat({ target, onOpenSearch, headerExtra }: { target: ChatTarget; onOpenSearch?: () => void; headerExtra?: ReactNode }) {
  const qc = useQueryClient();
  const me = useSession((s) => s.user)!;
  const info = infoFor(target, me.id);
  const key = ["messages", info.id];
  const messages = useQuery({ queryKey: key, queryFn: () => api.messages(info.id, undefined, info.isDm), staleTime: Infinity });
  const friends = useQuery({ queryKey: ["friends"], queryFn: api.friends });
  const blocked = new Set((friends.data ?? []).filter((f: FriendDTO) => f.state === "blocked").map((f) => f.user.id));
  const [olderDone, setOlderDone] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [replyTo, setReplyTo] = useState<MessageDTO | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [viewer, setViewer] = useState<AttachmentDTO | null>(null);
  const [revealed, setRevealed] = useState<Set<string>>(new Set());
  const scroller = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);
  const clearUnread = useRealtime((s) => s.clearUnread);

  useEffect(() => {
    clearUnread(info.id);
    const onFocus = () => clearUnread(info.id);
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [info.id, clearUnread, messages.data?.length]);

  useLayoutEffect(() => {
    const el = scroller.current;
    if (el && stickToBottom.current) el.scrollTop = el.scrollHeight;
  }, [messages.data]);

  async function loadOlder() {
    const list = messages.data;
    if (!list?.length || loadingOlder) return;
    setLoadingOlder(true);
    const el = scroller.current!;
    const prevHeight = el.scrollHeight;
    try {
      const older = await api.messages(info.id, list[0]!.id, info.isDm);
      if (older.length < LIMITS.MESSAGE_PAGE_SIZE) setOlderDone(true);
      qc.setQueryData<MessageDTO[]>(key, (cur) => [...older, ...(cur ?? [])]);
      requestAnimationFrame(() => (el.scrollTop = el.scrollHeight - prevHeight));
    } finally {
      setLoadingOlder(false);
    }
  }

  async function send(content: string, files: File[]) {
    const nonce = crypto.randomUUID();
    const optimistic: MessageDTO = {
      id: `pending-${nonce}`,
      channelId: info.id,
      author: { id: me.id, username: me.username, displayName: me.displayName, avatarUrl: me.avatarUrl },
      content,
      replyToId: replyTo?.id ?? null,
      createdAt: Date.now(),
      editedAt: null,
      attachments: files.map((f, i) => ({ id: `p${i}`, filename: f.name, mime: f.type, size: f.size, isImage: false, url: "" })),
      reactions: [],
      nonce,
    };
    stickToBottom.current = true;
    qc.setQueryData<MessageDTO[]>(key, (cur) => [...(cur ?? []), optimistic]);
    setReplyTo(null);
    try {
      const real = await api.sendMessage(info.id, content, nonce, optimistic.replyToId, files, info.isDm);
      qc.setQueryData<MessageDTO[]>(key, (cur) => {
        const rest = (cur ?? []).filter((m) => m.id !== optimistic.id);
        return rest.some((m) => m.id === real.id) ? rest : [...rest, real];
      });
    } catch (err) {
      qc.setQueryData<MessageDTO[]>(key, (cur) => (cur ?? []).filter((m) => m.id !== optimistic.id));
      toast((err as Error).message);
    }
  }

  async function react(m: MessageDTO, emoji: string) {
    const mine = m.reactions.find((r) => r.emoji === emoji)?.userIds.includes(me.id);
    try {
      const reactions = await api.react(m.id, emoji, !mine);
      qc.setQueryData<MessageDTO[]>(key, (cur) => cur?.map((x) => (x.id === m.id ? { ...x, reactions } : x)));
    } catch (err) {
      toast((err as Error).message);
    }
  }

  const list = messages.data ?? [];
  const byId = new Map(list.map((m) => [m.id, m]));

  return (
    <>
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-ink-950/60 px-4">
        <Icon name={info.icon} className="text-ink-400" />
        <h2 className="flex-1 truncate font-display font-semibold">{info.title}</h2>
        {onOpenSearch && (
          <button onClick={onOpenSearch} className="flex h-7 items-center gap-2 rounded-md bg-ink-950 px-2.5 text-xs text-ink-400 hover:text-ink-200" aria-label="Mesajlarda ara">
            <Icon name="search" size={14} /> Ara
          </button>
        )}
        {headerExtra}
      </header>

      <div
        ref={scroller}
        className="selectable flex-1 overflow-y-auto px-4 py-4"
        onScroll={(e) => {
          const el = e.currentTarget;
          stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
          if (el.scrollTop < 40 && !olderDone && list.length >= LIMITS.MESSAGE_PAGE_SIZE) void loadOlder();
        }}
      >
        {messages.isLoading && <p className="text-center text-ink-400">Yükleniyor…</p>}
        {!messages.isLoading && list.length === 0 && (
          <div className="mt-10 text-center text-ink-400">
            <p className="font-display text-2xl text-ink-200">{info.isDm ? info.title : `#${info.title}`}</p>
            <p>{info.isDm ? "Özel sohbetinizin başlangıcı." : "Kanalın başlangıcı. İlk mesajı sen yaz!"}</p>
          </div>
        )}
        {list.map((m, i) => {
          const prev = list[i - 1];
          const grouped = !!prev && prev.author.id === m.author.id && m.createdAt - prev.createdAt < GROUP_WINDOW_MS && !m.replyToId;
          const newDay = !prev || new Date(prev.createdAt).toDateString() !== new Date(m.createdAt).toDateString();
          const isBlocked = blocked.has(m.author.id) && !revealed.has(m.id);
          return (
            <Fragment key={m.id}>
              {newDay && (
                <div className="my-3 flex items-center gap-3 text-[11px] text-ink-500">
                  <div className="h-px flex-1 bg-ink-700" />
                  {new Date(m.createdAt).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" })}
                  <div className="h-px flex-1 bg-ink-700" />
                </div>
              )}
              {isBlocked ? (
                <button className="my-1 text-xs text-ink-500 hover:text-ink-300" onClick={() => setRevealed(new Set([...revealed, m.id]))}>
                  Engellediğin birinin mesajı — göster
                </button>
              ) : (
                <MessageRow
                  m={m}
                  grouped={grouped && !newDay}
                  replied={m.replyToId ? byId.get(m.replyToId) : undefined}
                  meId={me.id}
                  canDelete={m.author.id === me.id || info.canManage}
                  editing={editing === m.id}
                  onReply={() => setReplyTo(m)}
                  onEdit={() => setEditing(m.id)}
                  onEditDone={() => setEditing(null)}
                  onReact={(e) => void react(m, e)}
                  onOpenImage={setViewer}
                  nameOf={info.nameOf}
                  roleColor={info.colorOf(m.author.id)}
                />
              )}
            </Fragment>
          );
        })}
      </div>

      <TypingIndicator scope={info.scope} channelId={info.id} nameOf={info.nameOf} />
      <Composer info={info} replyTo={replyTo} onCancelReply={() => setReplyTo(null)} onSend={send} />
      {viewer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-8" onClick={() => setViewer(null)} role="dialog" aria-label="Resim">
          <img src={viewer.url} alt={viewer.filename} className="max-h-full max-w-full rounded-lg object-contain" />
          <a href={viewer.url} download={viewer.filename} onClick={(e) => e.stopPropagation()} className="absolute right-6 bottom-6 rounded-lg bg-ink-800 px-3 py-1.5 text-sm text-ink-100 hover:bg-ink-700">
            İndir
          </a>
        </div>
      )}
    </>
  );
}

/** Yalnızca https bağlantılarını tıklanabilir yapar; geri kalan her şey düz metindir (XSS yok). */
function renderContent(text: string): ReactNode[] {
  const parts = text.split(/(https:\/\/[^\s<>"]+)/g);
  return parts.map((p, i) =>
    /^https:\/\//.test(p) ? (
      <a
        key={i}
        href={p}
        className="text-amber-400 hover:underline"
        onClick={(e) => {
          e.preventDefault();
          bridge.openExternal(p);
        }}
      >
        {p}
      </a>
    ) : (
      <Fragment key={i}>{p}</Fragment>
    ),
  );
}

function formatSize(n: number) {
  return n < 1024 * 1024 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function EmojiPicker({ onPick, onClose }: { onPick: (e: string) => void; onClose: () => void }) {
  const [custom, setCustom] = useState("");
  return (
    <div className="absolute top-7 right-0 z-30 w-64 rounded-xl border border-ink-700 bg-ink-850 p-2 shadow-xl" onMouseLeave={onClose}>
      <div className="grid grid-cols-8 gap-0.5">
        {QUICK_EMOJI.map((e) => (
          <button key={e} className="rounded p-1 text-lg hover:bg-ink-700" onClick={() => onPick(e)} aria-label={`${e} tepkisi`}>
            {e}
          </button>
        ))}
      </div>
      <form
        className="mt-2 flex gap-1"
        onSubmit={(ev) => {
          ev.preventDefault();
          if (custom.trim()) onPick(custom.trim());
        }}
      >
        <input value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="Başka emoji (Win + .)" className="h-7 flex-1 rounded bg-ink-950 px-2 text-xs outline-none" />
      </form>
    </div>
  );
}

function MessageRow(props: {
  m: MessageDTO;
  grouped: boolean;
  replied?: MessageDTO;
  meId: string;
  canDelete: boolean;
  editing: boolean;
  roleColor?: string;
  onReply: () => void;
  onEdit: () => void;
  onEditDone: () => void;
  onReact: (emoji: string) => void;
  onOpenImage: (a: AttachmentDTO) => void;
  nameOf: (id: string) => string | undefined;
}) {
  const { m } = props;
  const pending = m.id.startsWith("pending-");
  const mine = m.author.id === props.meId;
  const [draft, setDraft] = useState(m.content);
  const [picker, setPicker] = useState(false);
  const time = new Date(m.createdAt).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });

  async function saveEdit() {
    const content = draft.trim();
    if (content && content !== m.content) {
      try {
        await api.editMessage(m.id, content);
      } catch (err) {
        toast((err as Error).message);
      }
    }
    props.onEditDone();
  }

  return (
    <div className={cx("group relative -mx-2 flex gap-3 rounded-lg px-2 hover:bg-ink-750/50", props.grouped ? "py-0.5" : "mt-3 py-1", pending && "opacity-50")} data-testid="message">
      <div className="w-10 shrink-0">
        {!props.grouped ? (
          <Avatar name={m.author.displayName} id={m.author.id} url={m.author.avatarUrl} size={40} />
        ) : (
          <span className="hidden pt-1 text-[10px] text-ink-500 group-hover:block">{time}</span>
        )}
      </div>
      <div className="min-w-0 flex-1">
        {props.replied && (
          <div className="mb-0.5 flex items-center gap-1 truncate text-xs text-ink-400">
            <Icon name="reply" size={12} /> <span className="font-semibold">{props.replied.author.displayName}</span> {props.replied.content.slice(0, 80)}
          </div>
        )}
        {!props.grouped && (
          <div className="flex items-baseline gap-2">
            <span className="font-semibold" style={{ color: props.roleColor }}>
              {m.author.displayName}
            </span>
            <span className="text-[11px] text-ink-500">{time}</span>
          </div>
        )}
        {props.editing ? (
          <textarea
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void saveEdit();
              } else if (e.key === "Escape") props.onEditDone();
            }}
            className="mt-1 w-full resize-none rounded-lg bg-ink-950 p-2 text-ink-100 outline-none"
            rows={2}
          />
        ) : (
          m.content && (
            <p className="break-words whitespace-pre-wrap text-ink-100">
              {renderContent(m.content)}
              {m.editedAt && <span className="ml-1 text-[10px] text-ink-500">(düzenlendi)</span>}
            </p>
          )
        )}
        {m.attachments.length > 0 && (
          <div className="mt-1.5 flex flex-wrap gap-2">
            {m.attachments.map((a) =>
              a.isImage ? (
                <button key={a.id} onClick={() => props.onOpenImage(a)} className="overflow-hidden rounded-lg border border-ink-700" aria-label={`Resim: ${a.filename}`}>
                  <img src={a.url} alt={a.filename} loading="lazy" className="max-h-72 max-w-sm object-contain" />
                </button>
              ) : (
                <a
                  key={a.id}
                  href={a.url || undefined}
                  download={a.filename}
                  className="flex min-w-56 items-center gap-3 rounded-lg border border-ink-700 bg-ink-850 px-3 py-2 hover:border-ink-600"
                >
                  <Icon name="file" size={22} className="text-amber-400" />
                  <span className="min-w-0">
                    <span className="block truncate text-sm text-ink-100">{a.filename}</span>
                    <span className="text-[11px] text-ink-400">{formatSize(a.size)}</span>
                  </span>
                </a>
              ),
            )}
          </div>
        )}
        {m.reactions.length > 0 && (
          <div className="mt-1 flex flex-wrap gap-1">
            {m.reactions.map((r) => {
              const me = r.userIds.includes(props.meId);
              return (
                <button
                  key={r.emoji}
                  onClick={() => props.onReact(r.emoji)}
                  title={r.userIds.map((id) => props.nameOf(id) ?? "?").join(", ")}
                  className={cx("flex h-6 items-center gap-1 rounded-md border px-1.5 text-xs", me ? "border-amber-500/60 bg-amber-500/15 text-amber-300" : "border-ink-700 bg-ink-850 text-ink-300 hover:border-ink-600")}
                >
                  <span>{r.emoji}</span>
                  <span>{r.userIds.length}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
      {!pending && !props.editing && (
        <div className={cx("absolute -top-3 right-2 gap-0.5 rounded-lg border border-ink-700 bg-ink-850 p-0.5 shadow", picker ? "flex" : "hidden group-hover:flex")}>
          <div className="relative">
            <button className="rounded p-1 text-ink-300 hover:bg-ink-700" title="Tepki ekle" onClick={() => setPicker((p) => !p)}>
              <Icon name="smile" size={15} />
            </button>
            {picker && (
              <EmojiPicker
                onPick={(e) => {
                  props.onReact(e);
                  setPicker(false);
                }}
                onClose={() => setPicker(false)}
              />
            )}
          </div>
          <button className="rounded p-1 text-ink-300 hover:bg-ink-700" title="Yanıtla" onClick={props.onReply}>
            <Icon name="reply" size={15} />
          </button>
          {mine && m.content && (
            <button className="rounded p-1 text-ink-300 hover:bg-ink-700" title="Düzenle" onClick={props.onEdit}>
              <Icon name="edit" size={15} />
            </button>
          )}
          {props.canDelete && (
            <button
              className="rounded p-1 text-danger-500 hover:bg-ink-700"
              title="Sil"
              onClick={() => {
                if (confirm("Mesaj silinsin mi?")) api.deleteMessage(m.id).catch((e) => toast((e as Error).message));
              }}
            >
              <Icon name="trash" size={15} />
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function TypingIndicator({ scope, channelId, nameOf }: { scope: string; channelId: string; nameOf: (id: string) => string | undefined }) {
  const typing = useRealtime((s) => s.guilds[scope]?.typing[channelId]);
  const [, force] = useState(0);
  useEffect(() => {
    const t = setInterval(() => force((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, []);
  const now = Date.now();
  const names = Object.entries(typing ?? {})
    .filter(([, at]) => now - at < 6000)
    .map(([id]) => nameOf(id) ?? "Biri");
  return (
    <div className="h-6 px-4 text-xs text-ink-400" aria-live="polite">
      {names.length > 0 && (
        <span className="flex items-center gap-1.5">
          <span className="flex gap-0.5">
            <span className="typing-dot h-1 w-1 rounded-full bg-ink-300" />
            <span className="typing-dot h-1 w-1 rounded-full bg-ink-300" />
            <span className="typing-dot h-1 w-1 rounded-full bg-ink-300" />
          </span>
          <strong className="text-ink-200">{names.slice(0, 3).join(", ")}</strong> yazıyor…
        </span>
      )}
    </div>
  );
}

function Composer(props: { info: ChatInfo; replyTo: MessageDTO | null; onCancelReply: () => void; onSend: (c: string, files: File[]) => void }) {
  const { info } = props;
  const [text, setText] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [dragging, setDragging] = useState(false);
  const lastTyping = useRef(0);
  const ref = useRef<HTMLTextAreaElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (props.replyTo) ref.current?.focus();
  }, [props.replyTo]);

  function addFiles(list: FileList | File[]) {
    const incoming = [...list];
    const tooBig = incoming.find((f) => f.size > LIMITS.ATTACHMENT_MAX_BYTES);
    if (tooBig) toast(`${tooBig.name}: en fazla ${LIMITS.ATTACHMENT_MAX_BYTES / 1024 / 1024} MB`);
    const ok = incoming.filter((f) => f.size <= LIMITS.ATTACHMENT_MAX_BYTES);
    setFiles((cur) => [...cur, ...ok].slice(0, LIMITS.ATTACHMENTS_PER_MESSAGE));
  }

  function submit() {
    const content = text.trim();
    if (!content && files.length === 0) return;
    props.onSend(content.slice(0, LIMITS.MESSAGE_MAX), files);
    setText("");
    setFiles([]);
    lastTyping.current = 0;
  }

  function onKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    } else if (e.key === "Escape" && props.replyTo) props.onCancelReply();
  }

  function onPaste(e: ClipboardEvent) {
    const pasted = [...e.clipboardData.files];
    if (pasted.length) {
      e.preventDefault();
      addFiles(pasted);
    }
  }

  function onDrop(e: DragEvent) {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
  }

  return (
    <div
      className="px-4 pb-5"
      onDragOver={(e) => {
        if (!info.canSend) return;
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={onDrop}
    >
      {props.replyTo && (
        <div className="flex items-center justify-between rounded-t-xl bg-ink-750 px-3 py-1.5 text-xs text-ink-300">
          <span>
            <strong>{props.replyTo.author.displayName}</strong> kişisine yanıt veriliyor
          </span>
          <button onClick={props.onCancelReply} aria-label="Yanıtı iptal et">
            <Icon name="x" size={14} />
          </button>
        </div>
      )}
      {files.length > 0 && (
        <div className={cx("flex flex-wrap gap-2 bg-ink-750 px-3 pt-3", !props.replyTo && "rounded-t-xl")}>
          {files.map((f, i) => (
            <div key={i} className="flex items-center gap-2 rounded-lg bg-ink-850 px-2.5 py-1.5 text-xs text-ink-200">
              <Icon name={f.type.startsWith("image/") ? "image" : "file"} size={14} />
              <span className="max-w-40 truncate">{f.name}</span>
              <span className="text-ink-500">{formatSize(f.size)}</span>
              <button onClick={() => setFiles(files.filter((_, j) => j !== i))} aria-label={`${f.name} kaldır`}>
                <Icon name="x" size={12} />
              </button>
            </div>
          ))}
        </div>
      )}
      <div className={cx("flex items-end gap-2 bg-ink-750 px-2", props.replyTo || files.length ? "rounded-b-xl" : "rounded-xl", dragging && "ring-2 ring-amber-500")}>
        <button
          className="mb-2 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-ink-300 hover:bg-ink-700 hover:text-ink-100 disabled:opacity-40"
          disabled={!info.canSend}
          onClick={() => fileInput.current?.click()}
          aria-label="Dosya ekle"
          title="Dosya ekle (veya sürükle-bırak / yapıştır)"
        >
          <Icon name="plus" size={18} />
        </button>
        <input
          ref={fileInput}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) addFiles(e.target.files);
            e.target.value = "";
          }}
        />
        <textarea
          ref={ref}
          rows={1}
          value={text}
          disabled={!info.canSend}
          maxLength={LIMITS.MESSAGE_MAX}
          aria-label="Mesaj"
          placeholder={!info.canSend ? "Bu kanala mesaj gönderemezsin" : info.isDm ? `${info.title} kişisine mesaj gönder` : `#${info.title} kanalına mesaj gönder`}
          onKeyDown={onKey}
          onPaste={onPaste}
          onChange={(e) => {
            setText(e.target.value);
            if (Date.now() - lastTyping.current > 3000 && e.target.value) {
              lastTyping.current = Date.now();
              realtime.client(info.scope)?.send(info.isDm ? { t: "dm.typing", channelId: info.id } : { t: "typing", channelId: info.id });
            }
          }}
          className="max-h-48 min-h-11 w-full resize-none bg-transparent px-1 py-3 text-ink-100 outline-none placeholder:text-ink-500 disabled:opacity-50"
        />
      </div>
    </div>
  );
}

/** Sunucu içinde mesaj arama paneli */
export function SearchPanel({ detail, onClose, onJump }: { detail: GuildDetail; onClose: () => void; onJump: (channelId: string) => void }) {
  const [q, setQ] = useState("");
  const [submitted, setSubmitted] = useState("");
  const results = useQuery({ queryKey: ["search", detail.guild.id, submitted], queryFn: () => api.search(detail.guild.id, submitted), enabled: submitted.length >= 2 });
  const chName = (id: string) => detail.channels.find((c) => c.id === id)?.name ?? "?";
  return (
    <Modal title={`${detail.guild.name} içinde ara`} onClose={onClose} width={620}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setSubmitted(q.trim());
        }}
      >
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="En az 2 harf — Türkçe karakterler fark etmez"
          aria-label="Arama"
          className="h-10 w-full rounded-lg border border-ink-700 bg-ink-950 px-3 outline-none focus:border-amber-500"
        />
      </form>
      <div className="mt-3 max-h-[55vh] space-y-2 overflow-y-auto">
        {results.isFetching && <p className="text-sm text-ink-400">Aranıyor…</p>}
        {results.data?.length === 0 && <p className="text-sm text-ink-400">Sonuç yok.</p>}
        {results.data?.map((m) => (
          <button key={m.id} onClick={() => onJump(m.channelId)} className="block w-full rounded-lg bg-ink-800 p-3 text-left hover:bg-ink-750" data-testid="search-result">
            <div className="mb-1 flex items-center gap-2 text-xs text-ink-400">
              <span className="font-semibold text-ink-200">{m.author.displayName}</span> #{chName(m.channelId)} · {new Date(m.createdAt).toLocaleString("tr-TR")}
            </div>
            <p className="line-clamp-3 text-sm text-ink-100">{m.content || "(ek)"}</p>
          </button>
        ))}
      </div>
    </Modal>
  );
}
