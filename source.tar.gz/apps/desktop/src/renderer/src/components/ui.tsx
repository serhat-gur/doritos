import { useEffect, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from "react";

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

const PALETTE = ["#f5a524", "#3fd1a5", "#7aa2f7", "#e8782c", "#c792ea", "#ff6b8b", "#56b6c2"];
export function colorFor(id: string) {
  let h = 0;
  for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return PALETTE[h % PALETTE.length]!;
}

export function Avatar({ name, id, url, size = 32, speaking, status }: { name: string; id: string; url?: string | null; size?: number; speaking?: boolean; status?: string }) {
  const dot = status === "online" ? "bg-voice-400" : status === "busy" ? "bg-danger-500" : status === "idle" ? "bg-amber-500" : status ? "bg-ink-500" : null;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      {url ? (
        <img src={url} alt="" className={cx("h-full w-full rounded-full object-cover", speaking && "speaking-ring")} />
      ) : (
        <div
          className={cx("flex h-full w-full items-center justify-center rounded-full font-semibold text-ink-950", speaking && "speaking-ring")}
          style={{ background: colorFor(id), fontSize: size * 0.42 }}
        >
          {name.slice(0, 1).toUpperCase()}
        </div>
      )}
      {dot && <span className={cx("absolute -right-0.5 -bottom-0.5 h-3 w-3 rounded-full border-2 border-ink-850", dot)} />}
    </div>
  );
}

export function Button({ variant = "primary", className, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" | "subtle" }) {
  return (
    <button
      {...rest}
      className={cx(
        "inline-flex h-9 items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        variant === "primary" && "bg-amber-500 text-ink-950 hover:bg-amber-400",
        variant === "ghost" && "text-ink-200 hover:bg-ink-750",
        variant === "subtle" && "bg-ink-750 text-ink-100 hover:bg-ink-700",
        variant === "danger" && "bg-danger-500 text-white hover:brightness-110",
        className,
      )}
    />
  );
}

export function TextInput({ label, className, ...rest }: InputHTMLAttributes<HTMLInputElement> & { label?: string }) {
  return (
    <label className="block">
      {label && <span className="mb-1.5 block text-xs font-semibold tracking-wide text-ink-300 uppercase">{label}</span>}
      <input
        {...rest}
        className={cx(
          "h-10 w-full rounded-lg border border-ink-700 bg-ink-950 px-3 text-ink-100 outline-none placeholder:text-ink-500 focus:border-amber-500",
          className,
        )}
      />
    </label>
  );
}

export function Modal({ title, onClose, children, width = 440 }: { title: string; onClose: () => void; children: ReactNode; width?: number }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-label={title}
        className="max-h-[90vh] overflow-y-auto rounded-2xl border border-ink-700 bg-ink-850 p-6 shadow-2xl"
        style={{ width }}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <h2 className="mb-4 font-display text-lg font-semibold">{title}</h2>
        {children}
      </div>
    </div>
  );
}

/** Basit çizgi ikonları (harici ikon kütüphanesi yok). */
const paths: Record<string, string> = {
  hash: "M5 9h14M5 15h14M10 3 8 21M16 3l-2 18",
  speaker: "M11 5 6 9H3v6h3l5 4V5zM15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13",
  mic: "M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM5 11a7 7 0 0 0 14 0M12 18v3",
  micOff: "M3 3l18 18M9 9v3a3 3 0 0 0 5.1 2.1M15 9.3V6a3 3 0 0 0-5.9-.8M5 11a7 7 0 0 0 11.5 5.4M19 11a7 7 0 0 1-.6 2.8M12 18v3",
  headphones: "M3 14v-2a9 9 0 0 1 18 0v2M3 14h3v6H4a1 1 0 0 1-1-1v-5zm18 0h-3v6h2a1 1 0 0 0 1-1v-5z",
  headphonesOff: "M3 3l18 18M3 14v-2a9 9 0 0 1 2.6-6.4M9 3.5A9 9 0 0 1 21 12v2M3 14h3v6H4a1 1 0 0 1-1-1v-5zm18 0h-3v6h2a1 1 0 0 0 1-1v-5z",
  phoneOff: "M10.7 13.3a10 10 0 0 0 3.2 2l1.8-1.8a1 1 0 0 1 1-.2 11 11 0 0 0 3.4.6 1 1 0 0 1 1 1V19a1 1 0 0 1-1 1A17 17 0 0 1 4 3a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1 11 11 0 0 0 .6 3.4 1 1 0 0 1-.2 1L8.1 9.2M3 3l18 18",
  plus: "M12 5v14M5 12h14",
  settings: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z",
  grid: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
  lock: "M6 11h12v10H6zM8 11V7a4 4 0 0 1 8 0v4",
  trash: "M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14",
  play: "M7 4l13 8-13 8z",
  star: "M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z",
  link: "M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1",
  reply: "M9 14 4 9l5-5M4 9h10a6 6 0 0 1 6 6v5",
  edit: "M4 20h4L19 9l-4-4L4 16v4z",
  signal: "M3 20h2v-3H3zM8 20h2v-7H8zM13 20h2v-11h-2zM18 20h2V4h-2z",
  x: "M6 6l12 12M18 6 6 18",
  search: "M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-5-5",
  users: "M16 20v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM22 20v-1a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8",
  at: "M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM16 12v1.5a2.5 2.5 0 0 0 5 0V12a9 9 0 1 0-3.5 7.1",
  smile: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01",
  file: "M14 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8zM14 3v5h5",
  image: "M4 5h16v14H4zM4 15l4-4 5 5M14 14l2-2 4 4M15.5 9.5h.01",
  monitor: "M3 4h18v12H3zM8 20h8M12 16v4",
  monitorOff: "M3 3l18 18M21 15V4H8M3 6v10h11M8 20h8M12 16v4",
  home: "M3 11l9-8 9 8M5 9.5V20h5v-6h4v6h5V9.5",
  userPlus: "M15 20v-1a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v1M8.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM19 8v6M22 11h-6",
  check: "M5 12l5 5L20 7",
  ban: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM5.6 5.6l12.8 12.8",
  shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z",
  message: "M4 5h16v11H8l-4 4z",
  maximize: "M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5",
  download: "M12 4v12M7 11l5 5 5-5M4 20h16",
  mouse: "M12 3a6 6 0 0 0-6 6v6a6 6 0 0 0 12 0V9a6 6 0 0 0-6-6zM12 7v4",
  logout: "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3",
};
export function Icon({ name, size = 18, className }: { name: keyof typeof paths | string; size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden>
      <path d={paths[name] ?? ""} />
    </svg>
  );
}

export function IconButton({ icon, label, active, danger, className, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { icon: string; label: string; active?: boolean; danger?: boolean }) {
  return (
    <button
      {...rest}
      aria-label={label}
      title={label}
      className={cx(
        "flex h-8 w-8 items-center justify-center rounded-lg transition-colors",
        danger ? "text-danger-500 hover:bg-danger-500/15" : active ? "bg-danger-500/15 text-danger-500" : "text-ink-300 hover:bg-ink-700 hover:text-ink-100",
        className,
      )}
    >
      <Icon name={icon} />
    </button>
  );
}

/** Uygulama genelinde kısa bildirimler: window'a "yanki:toast" olayı gönderilir. */
export function toast(message: string) {
  window.dispatchEvent(new CustomEvent("yanki:toast", { detail: message }));
}

export function Toaster() {
  const [items, setItems] = useState<{ id: number; text: string }[]>([]);
  useEffect(() => {
    let n = 0;
    const on = (e: Event) => {
      const id = ++n;
      setItems((s) => [...s.slice(-2), { id, text: String((e as CustomEvent).detail) }]);
      setTimeout(() => setItems((s) => s.filter((x) => x.id !== id)), 3500);
    };
    window.addEventListener("yanki:toast", on);
    return () => window.removeEventListener("yanki:toast", on);
  }, []);
  return (
    <div className="pointer-events-none fixed bottom-24 left-1/2 z-[60] flex -translate-x-1/2 flex-col items-center gap-2">
      {items.map((t) => (
        <div key={t.id} role="status" className="rounded-lg border border-ink-600 bg-ink-750 px-4 py-2 text-sm text-ink-100 shadow-xl">
          {t.text}
        </div>
      ))}
    </div>
  );
}
