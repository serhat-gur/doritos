import { useEffect, useState, type FormEvent } from "react";
import { api, apiConfig, ApiError } from "../lib/api";
import { bridge } from "../lib/bridge";
import { useSession } from "../stores/app";
import { Button, TextInput } from "./ui";

export function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [apiUrl, setApiUrl] = useState(apiConfig.getBaseUrl());
  const [showServer, setShowServer] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const setUser = useSession((s) => s.setUser);

  useEffect(() => setError(null), [mode]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (apiUrl !== apiConfig.getBaseUrl()) {
        const s = await bridge.settings.set({ apiUrl });
        apiConfig.setBaseUrl(s.apiUrl);
      }
      const res =
        mode === "login"
          ? await api.login(username.trim().toLowerCase(), password)
          : await api.register(username.trim().toLowerCase(), displayName.trim() || username.trim(), password, code || undefined);
      apiConfig.setToken(res.token);
      await bridge.session.set(res.token);
      setUser(res.user);
    } catch (err) {
      if (err instanceof ApiError) {
        const details = Array.isArray(err.details) ? (err.details as { path: string; message: string }[]).map((d) => `${d.path}: ${d.message}`).join(" • ") : "";
        setError(details ? `${err.message} — ${details}` : err.message);
      } else setError("Beklenmeyen hata");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex h-full items-center justify-center bg-[radial-gradient(ellipse_at_top,_#1b1f27,_#0b0d11_60%)]">
      <form onSubmit={submit} className="w-[380px] rounded-2xl border border-ink-700 bg-ink-850/90 p-8 shadow-2xl">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500 text-lg font-bold text-ink-950">D</div>
          <div>
            <h1 className="font-display text-xl font-semibold">Doritos</h1>
            <p className="text-xs text-ink-400">{mode === "login" ? "Tekrar hoş geldin" : "Hesap oluştur"}</p>
          </div>
        </div>

        <div className="space-y-4">
          <TextInput label="Kullanıcı adı" name="username" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} required />
          {mode === "register" && <TextInput label="Görünen ad" name="displayName" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />}
          <TextInput
            label="Şifre"
            type="password"
            name="password"
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {mode === "register" && <TextInput label="Kayıt kodu (gerekiyorsa)" name="code" value={code} onChange={(e) => setCode(e.target.value)} />}
          {showServer && <TextInput label="Sunucu adresi" name="apiUrl" value={apiUrl} onChange={(e) => setApiUrl(e.target.value)} />}
        </div>

        {error && (
          <p role="alert" className="mt-4 rounded-lg bg-danger-500/10 px-3 py-2 text-sm text-danger-500">
            {error}
          </p>
        )}

        <Button type="submit" disabled={busy} className="mt-6 w-full">
          {busy ? "Bekle…" : mode === "login" ? "Giriş yap" : "Kayıt ol"}
        </Button>
        <div className="mt-4 flex items-center justify-between text-xs">
          <button type="button" className="text-amber-400 hover:underline" onClick={() => setMode(mode === "login" ? "register" : "login")}>
            {mode === "login" ? "Hesabın yok mu? Kayıt ol" : "Zaten hesabın var mı? Giriş yap"}
          </button>
          <button type="button" className="text-ink-400 hover:text-ink-200" onClick={() => setShowServer((s) => !s)}>
            Sunucu
          </button>
        </div>
      </form>
    </div>
  );
}
