import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { api } from "../lib/api";
import { realtime } from "../lib/realtime";
import { afkAlarm } from "../media/afk-alarm";
import { voiceSession } from "../media/voice-session";
import { useVoice } from "../stores/app";
import { useSettings } from "../stores/settings";
import { Button } from "./ui";

/**
 * Sunucunun AFK kanalındaysan alarmı durmadan çalar, çıkınca susturur.
 * Ekranda "Uyandım" şeridi: bir önceki odaya geri döndürür.
 */
export function AfkWatcher() {
  const gid = useVoice((s) => s.guildId);
  const cid = useVoice((s) => s.channelId);
  const detail = useQuery({ queryKey: ["guild", gid], queryFn: () => api.guild(gid!), enabled: !!gid });
  const guild = detail.data?.guild;
  const inAfk = !!cid && !!guild?.afkChannelId && guild.afkChannelId === cid;
  const soundId = inAfk ? guild?.afkSoundId ?? null : null;
  const sounds = useQuery({ queryKey: ["sounds", gid], queryFn: () => api.guildSounds(gid!), enabled: !!gid && !!soundId });
  const sound = soundId ? sounds.data?.find((s) => s.id === soundId) ?? null : null;
  const waitingSound = !!soundId && sounds.isLoading;
  const volume = useSettings((s) => s.afkAlarmVolume);
  const output = useSettings((s) => s.outputDeviceId);

  // AFK olmayan son oda: "Uyandım" buraya döndürür
  const lastRoom = useRef<{ gid: string; cid: string } | null>(null);
  useEffect(() => {
    if (gid && cid && !inAfk && guild) lastRoom.current = { gid, cid };
  }, [gid, cid, inAfk, guild]);

  useEffect(() => afkAlarm.setVolume(volume), [volume]);
  useEffect(() => afkAlarm.setOutput(output), [output]);

  const soundKey = sound ? `${sound.sha256}|${sound.volume}` : "builtin";
  useEffect(() => {
    if (!inAfk || waitingSound) return;
    void afkAlarm.start(sound ? { sha256: sound.sha256, url: sound.url, volume: sound.volume } : null);
    return () => afkAlarm.stop();
    // sound nesnesi her sorguda yenilenir; yalnızca içerik değişince yeniden başlat
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inAfk, waitingSound, soundKey]);

  useEffect(() => () => afkAlarm.stop(), []);

  if (!inAfk) return null;
  const back = lastRoom.current && lastRoom.current.gid === gid ? lastRoom.current : null;
  return (
    <div role="alert" className="fixed left-1/2 top-3 z-50 flex -translate-x-1/2 items-center gap-3 rounded-xl bg-red-600 px-4 py-2 text-sm font-medium text-white shadow-xl">
      <span className="animate-pulse">⏰ AFK odasına taşındın, uyan!</span>
      <Button
        onClick={() => {
          const client = gid ? realtime.client(gid) : null;
          if (back && client) void voiceSession.join(client, back.cid);
          else void voiceSession.leave();
        }}
      >
        {back ? "Uyandım, geri dön" : "Uyandım, sesten çık"}
      </Button>
    </div>
  );
}
