import { useQuery, useQueryClient } from "@tanstack/react-query";
import { hasFlag, highestRolePosition, Permission, type DmChannelDTO, type MemberDTO } from "@yanki/shared";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { api, type GuildDetail } from "../lib/api";
import { realtime } from "../lib/realtime";
import { voiceSession } from "../media/voice-session";
import { useRealtime, useSession } from "../stores/app";
import { useSettings } from "../stores/settings";
import { Avatar, cx, Icon, toast } from "./ui";

/**
 * Bir üyeye tıklayınca açılan menü: profil, sosyal işlemler, kişisel ses
 * ayarları ve yetkiye göre moderasyon. Tüm moderasyon işlemleri sunucuda
 * tekrar yetkilendirilir; burada yalnızca yetkisi olmayan düğmeler gizlenir.
 */
export interface MenuAnchor {
  x: number;
  y: number;
}

/** Menü, dar panellerde kırpılmasın diye pencerenin üstünde (portal) ve ekrana sığacak şekilde açılır. */
function placement(a: MenuAnchor) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const below = a.y < vh * 0.55;
  return {
    left: Math.max(8, Math.min(a.x, vw - 272)),
    ...(below ? { top: a.y } : { bottom: vh - a.y }),
    maxHeight: below ? vh - a.y - 8 : a.y - 8,
  };
}

export function MemberMenu({ member, detail, onClose, anchor }: { member: MemberDTO; detail: GuildDetail; onClose: () => void; anchor: MenuAnchor }) {
  const qc = useQueryClient();
  const me = useSession((s) => s.user)!;
  const selectGuild = useSession((s) => s.selectGuild);
  const selectChannel = useSession((s) => s.selectChannel);
  const friends = useQuery({ queryKey: ["friends"], queryFn: api.friends });
  const voice = useRealtime((s) => s.guilds[detail.guild.id]?.voice[member.user.id]);
  const { userVolumes, setUserVolume, userSoundVolumes, setUserSoundVolume } = useSettings();
  const [moveOpen, setMoveOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const isMe = member.user.id === me.id;
  const perms = detail.guild.myPermissions;
  const rel = friends.data?.find((f) => f.user.id === member.user.id)?.state;
  const myMember = detail.members.find((m) => m.user.id === me.id);
  const ctx = {
    isOwner: detail.guild.ownerId === me.id,
    userId: me.id,
    everyoneRoleId: detail.guild.id,
    roles: detail.roles,
    memberRoleIds: myMember?.roleIds ?? [],
  };
  const myTop = highestRolePosition(ctx);
  const targetTop = highestRolePosition({ ...ctx, isOwner: detail.guild.ownerId === member.user.id, userId: member.user.id, memberRoleIds: member.roleIds });
  const outranks = !isMe && member.user.id !== detail.guild.ownerId && myTop > targetTop;
  const voiceChannels = detail.channels.filter((c) => c.type === "voice" && c.id !== voice?.channelId);

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    setTimeout(() => window.addEventListener("mousedown", onDown), 0);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const run = (fn: () => Promise<unknown> | void, ok?: string) => async () => {
    try {
      await fn();
      if (ok) toast(ok);
    } catch (e) {
      toast((e as Error).message);
    }
  };
  const gw = () => realtime.client(detail.guild.id);

  const item = "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm text-ink-200 hover:bg-ink-700";
  const name = member.nickname ?? member.user.displayName;
  return createPortal(
    <div
      ref={ref}
      className="fixed z-50 w-64 overflow-y-auto rounded-xl border border-ink-700 bg-ink-850 p-2 shadow-2xl"
      style={placement(anchor)}
      role="menu"
      aria-label={`${name} menüsü`}
    >
      <div className="mb-2 flex items-center gap-3 rounded-lg bg-ink-800 p-2.5">
        <Avatar name={name} id={member.user.id} url={member.user.avatarUrl} size={40} />
        <div className="min-w-0">
          <p className="truncate font-semibold">{name}</p>
          <p className="truncate text-xs text-ink-400">@{member.user.username}</p>
          {member.user.bio && <p className="mt-1 line-clamp-2 text-xs text-ink-300">{member.user.bio}</p>}
        </div>
      </div>

      {!isMe && (
        <>
          <button
            className={item}
            onClick={run(async () => {
              const dm = await api.openDm([member.user.id]);
              qc.setQueryData<DmChannelDTO[]>(["dms"], (old) => [dm, ...(old ?? []).filter((d) => d.id !== dm.id)]);
              selectGuild("@me");
              selectChannel("@me", dm.id);
              onClose();
            })}
          >
            <Icon name="message" size={16} /> Mesaj gönder
          </button>
          {!rel && (
            <button className={item} onClick={run(() => api.addFriend(member.user.username), "Arkadaşlık isteği gönderildi")}>
              <Icon name="userPlus" size={16} /> Arkadaş ekle
            </button>
          )}
          <div className="my-2 px-2">
            <label className="mb-1 block text-[11px] text-ink-400">Kullanıcı sesi: {Math.round((userVolumes[member.user.id] ?? 1) * 100)}%</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={userVolumes[member.user.id] ?? 1}
              onChange={(e) => {
                setUserVolume(member.user.id, Number(e.target.value));
                voiceSession.applyRemoteVolumes();
              }}
              className="w-full accent-amber-500"
              aria-label="Kullanıcı sesi"
            />
            <label className="mt-1 mb-1 block text-[11px] text-ink-400">Soundboard sesi: {Math.round((userSoundVolumes[member.user.id] ?? 1) * 100)}%</label>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={userSoundVolumes[member.user.id] ?? 1}
              onChange={(e) => setUserSoundVolume(member.user.id, Number(e.target.value))}
              className="w-full accent-amber-500"
              aria-label="Soundboard sesi"
            />
          </div>
        </>
      )}

      {voice && !isMe && (hasFlag(perms, Permission.MUTE_MEMBERS) || hasFlag(perms, Permission.DEAFEN_MEMBERS) || hasFlag(perms, Permission.MOVE_MEMBERS)) && (
        <div className="border-t border-ink-700 pt-1">
          {hasFlag(perms, Permission.MUTE_MEMBERS) && (
            <button className={item} onClick={run(() => void gw()?.send({ t: "voice.moderate", userId: member.user.id, mute: !voice.serverMute }))}>
              <Icon name="micOff" size={16} /> {voice.serverMute ? "Sunucu susturmasını kaldır" : "Sunucuda sustur"}
            </button>
          )}
          {hasFlag(perms, Permission.DEAFEN_MEMBERS) && (
            <button className={item} onClick={run(() => void gw()?.send({ t: "voice.moderate", userId: member.user.id, deafen: !voice.serverDeaf }))}>
              <Icon name="headphonesOff" size={16} /> {voice.serverDeaf ? "Sağırlaştırmayı kaldır" : "Sunucuda sağırlaştır"}
            </button>
          )}
          {hasFlag(perms, Permission.MOVE_MEMBERS) && (
            <>
              <button className={item} onClick={() => setMoveOpen((o) => !o)} title="İpucu: kişiyi sürükleyip başka sesli kanala da bırakabilirsin">
                <Icon name="speaker" size={16} /> Başka kanala taşı {voiceChannels.length === 0 && <span className="text-[11px] text-ink-500">(başka sesli kanal yok)</span>}
              </button>
              {moveOpen &&
                voiceChannels.map((c) => (
                  <button key={c.id} className={cx(item, "pl-8 text-ink-300")} onClick={run(() => void gw()?.send({ t: "voice.move", userId: member.user.id, channelId: c.id }), "Taşındı")}>
                    {c.name}
                  </button>
                ))}
              <button className={item} onClick={run(() => void gw()?.send({ t: "voice.move", userId: member.user.id, channelId: null }), "Sesten çıkarıldı")}>
                <Icon name="phoneOff" size={16} /> Sesten çıkar
              </button>
            </>
          )}
        </div>
      )}

      {hasFlag(perms, Permission.MANAGE_ROLES) && (
        <div className="border-t border-ink-700 pt-1">
          <p className="px-2 pt-1 text-[11px] font-semibold tracking-wider text-ink-400 uppercase">Roller</p>
          {detail.roles
            .filter((r) => r.id !== detail.guild.id)
            .map((r) => {
              const has = member.roleIds.includes(r.id);
              const editable = ctx.isOwner || r.position < myTop;
              return (
                <label key={r.id} className={cx(item, !editable && "opacity-40")}>
                  <input
                    type="checkbox"
                    className="accent-amber-500"
                    checked={has}
                    disabled={!editable}
                    onChange={run(async () => {
                      await api.setMemberRole(detail.guild.id, member.user.id, r.id, !has);
                      await qc.invalidateQueries({ queryKey: ["guild", detail.guild.id] });
                    })}
                  />
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: r.color ?? "var(--color-ink-400)" }} />
                  {r.name}
                </label>
              );
            })}
        </div>
      )}

      {!isMe && (
        <div className="border-t border-ink-700 pt-1">
          {rel !== "blocked" && (
            <button className={cx(item, "text-danger-500")} onClick={run(async () => (confirm(`${name} engellensin mi?`) ? api.block(member.user.id) : undefined), "Engellendi")}>
              <Icon name="ban" size={16} /> Engelle
            </button>
          )}
          {outranks && hasFlag(perms, Permission.KICK_MEMBERS) && (
            <button
              className={cx(item, "text-danger-500")}
              onClick={run(async () => {
                if (!confirm(`${name} sunucudan atılsın mı?`)) return;
                await api.kick(detail.guild.id, member.user.id);
                onClose();
              }, "Atıldı")}
            >
              <Icon name="logout" size={16} /> Sunucudan at
            </button>
          )}
          {outranks && hasFlag(perms, Permission.BAN_MEMBERS) && (
            <button
              className={cx(item, "text-danger-500")}
              onClick={run(async () => {
                const reason = prompt(`${name} yasaklansın mı? Sebep (isteğe bağlı):`);
                if (reason === null) return;
                await api.ban(detail.guild.id, member.user.id, reason || undefined);
                onClose();
              }, "Yasaklandı")}
            >
              <Icon name="shield" size={16} /> Yasakla
            </button>
          )}
        </div>
      )}
    </div>
    ,
    document.body,
  );
}
