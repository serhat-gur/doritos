import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { hasFlag, Permission, type ChannelDTO, type GuildDTO, type MemberDTO } from "@yanki/shared";
import { useEffect, useMemo, useState, type DragEvent, type ReactNode } from "react";
import { api, ApiError, type GuildDetail } from "../lib/api";
import { bridge } from "../lib/bridge";
import { realtime } from "../lib/realtime";
import { startMacros } from "../media/macros";
import { screenShare, useScreen } from "../media/screen-share";
import { voiceSession } from "../media/voice-session";
import { useRealtime, useSession, useVoice } from "../stores/app";
import { useSettings } from "../stores/settings";
import { AfkWatcher } from "./AfkWatcher";
import { Chat, SearchPanel } from "./Chat";
import { GuildSettings } from "./GuildSettings";
import { Home } from "./Home";
import { MemberMenu, type MenuAnchor } from "./MemberMenu";

/** Sürükle-bırak ile kullanıcı taşırken kullanılan veri türü */
const VOICE_DRAG = "application/x-doritos-voice-user";
import { SettingsModal } from "./Settings";
import { Stage } from "./Stage";
import { Avatar, Button, cx, Icon, IconButton, Modal, TextInput, toast } from "./ui";
import { UpdateBanner, UserPanel, VoiceConnectionPanel } from "./VoiceBar";

export function Shell() {
  const guilds = useQuery({ queryKey: ["guilds"], queryFn: api.guilds });
  const { selectedGuildId, selectGuild } = useSession();
  const [modal, setModal] = useState<null | "guild" | "settings">(null);
  const unread = useRealtime((s) => s.unread);
  const friends = useQuery({ queryKey: ["friends"], queryFn: api.friends });
  const pending = (friends.data ?? []).filter((f) => f.state === "incoming").length;
  const dms = useQuery({ queryKey: ["dms"], queryFn: api.dms });
  const dmUnread = (dms.data ?? []).reduce((a, d) => a + (unread[d.id] ?? 0), 0);

  useEffect(() => {
    if (guilds.data) realtime.sync(guilds.data.map((g) => g.id));
  }, [guilds.data]);
  useEffect(() => {
    startMacros();
    return () => realtime.stopAll();
  }, []);
  useEffect(() => {
    // Liste tazelenirken (ör. yeni sunucu oluşturuldu) seçimi sıfırlama
    if (!guilds.data || guilds.isFetching) return;
    const exists = selectedGuildId === "@me" || guilds.data.some((g) => g.id === selectedGuildId);
    if (!selectedGuildId || !exists) selectGuild(guilds.data[0]?.id ?? "@me");
  }, [guilds.data, guilds.isFetching, selectedGuildId, selectGuild]);

  useEffect(() => {
    bridge.setBadge(Object.values(unread).reduce((a, b) => a + b, 0) + pending);
  }, [unread, pending]);

  return (
    <div className="flex h-full flex-col">
      <AfkWatcher />
      <UpdateBanner />
      <div className="flex min-h-0 flex-1">
        <nav className="flex w-[72px] shrink-0 flex-col items-center gap-2 overflow-y-auto bg-ink-950 py-3" aria-label="Sunucular">
          <RailButton title="Ana sayfa" active={selectedGuildId === "@me"} badge={pending + dmUnread} onClick={() => selectGuild("@me")}>
            <Icon name="home" size={22} />
          </RailButton>
          <div className="my-1 h-px w-8 bg-ink-700" />
          {guilds.data?.map((g) => (
            <RailButton key={g.id} title={g.name} active={g.id === selectedGuildId} onClick={() => selectGuild(g.id)}>
              {g.iconUrl ? <img src={g.iconUrl} alt="" className="h-full w-full rounded-[inherit] object-cover" /> : initials(g.name)}
            </RailButton>
          ))}
          <button
            title="Sunucu oluştur veya katıl"
            onClick={() => setModal("guild")}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-ink-800 text-voice-400 transition-all hover:rounded-xl hover:bg-voice-500 hover:text-ink-950"
          >
            <Icon name="plus" />
          </button>
        </nav>

        {selectedGuildId === "@me" ? (
          <Home onOpenSettings={() => setModal("settings")} />
        ) : selectedGuildId ? (
          <GuildView key={selectedGuildId} guildId={selectedGuildId} onOpenSettings={() => setModal("settings")} />
        ) : (
          <div className="flex flex-1 items-center justify-center text-ink-400">{guilds.isLoading ? "Yükleniyor…" : ""}</div>
        )}
      </div>

      {modal === "guild" && <GuildModal onClose={() => setModal(null)} />}
      {modal === "settings" && <SettingsModal onClose={() => setModal(null)} />}
    </div>
  );
}

function RailButton({ title, active, badge, onClick, children }: { title: string; active: boolean; badge?: number; onClick: () => void; children: ReactNode }) {
  return (
    <button
      title={title}
      aria-label={title}
      onClick={onClick}
      className={cx(
        "group relative flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl text-sm font-semibold transition-all",
        active ? "rounded-xl bg-amber-500 text-ink-950" : "bg-ink-800 text-ink-200 hover:rounded-xl hover:bg-ink-700",
      )}
    >
      {children}
      <span className={cx("absolute -left-3 w-1 rounded-r bg-ink-100 transition-all", active ? "h-8" : "h-0 group-hover:h-4")} />
      {!!badge && <span className="absolute -right-1 -bottom-1 min-w-5 rounded-full border-4 border-ink-950 bg-danger-500 px-1 text-center text-[11px] leading-3 text-white">{badge}</span>}
    </button>
  );
}

function initials(name: string) {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");
}

function GuildModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const selectGuild = useSession((s) => s.selectGuild);
  const [name, setName] = useState("");
  const [invite, setInvite] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const create = useMutation({
    mutationFn: () => api.createGuild(name.trim()),
    onSuccess: (g) => {
      qc.setQueryData<GuildDTO[]>(["guilds"], (old) => [...(old ?? []), g]);
      void qc.invalidateQueries({ queryKey: ["guilds"] });
      selectGuild(g.id);
      onClose();
    },
    onError: (e) => setErr((e as Error).message),
  });
  const join = useMutation({
    mutationFn: () => api.acceptInvite(invite.trim().split("/").pop()!),
    onSuccess: (r) => {
      void qc.invalidateQueries({ queryKey: ["guilds"] });
      selectGuild(r.guildId);
      onClose();
    },
    onError: (e) => setErr((e as Error).message),
  });
  return (
    <Modal title="Sunucu" onClose={onClose}>
      <form
        className="space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (name.trim()) create.mutate();
        }}
      >
        <TextInput label="Yeni sunucu adı" value={name} onChange={(e) => setName(e.target.value)} placeholder="Kanka Sunucusu" />
        <Button type="submit" disabled={!name.trim() || create.isPending} className="w-full">
          Oluştur
        </Button>
      </form>
      <div className="my-5 flex items-center gap-3 text-xs text-ink-500">
        <div className="h-px flex-1 bg-ink-700" /> veya <div className="h-px flex-1 bg-ink-700" />
      </div>
      <form
        className="space-y-3"
        onSubmit={(e) => {
          e.preventDefault();
          if (invite.trim()) join.mutate();
        }}
      >
        <TextInput label="Davet kodu" value={invite} onChange={(e) => setInvite(e.target.value)} placeholder="ör. k7m2pq9xra" />
        <Button type="submit" variant="subtle" disabled={!invite.trim() || join.isPending} className="w-full">
          Katıl
        </Button>
      </form>
      {err && <p className="mt-3 text-sm text-danger-500">{err}</p>}
    </Modal>
  );
}

// ------------------------------------------------------------------------------------------------
function GuildView({ guildId, onOpenSettings }: { guildId: string; onOpenSettings: () => void }) {
  const detail = useQuery({ queryKey: ["guild", guildId], queryFn: () => api.guild(guildId) });
  const { selectedChannelId, selectChannel } = useSession();
  const channelId = selectedChannelId[guildId];
  const [modal, setModal] = useState<null | { type: "channel"; parentId: string | null } | { type: "invite" } | { type: "settings" } | { type: "search" }>(null);

  const showMembers = useSettings((s) => s.showMembers);
  const channels = detail.data?.channels ?? [];
  const textChannels = channels.filter((c) => c.type === "text");
  useEffect(() => {
    if (!detail.data) return;
    if (!channelId || !textChannels.some((c) => c.id === channelId)) {
      const first = textChannels[0];
      if (first) selectChannel(guildId, first.id);
    }
  }, [detail.data, channelId, guildId, selectChannel, textChannels]);

  if (detail.isLoading) return <div className="flex flex-1 items-center justify-center text-ink-400">Yükleniyor…</div>;
  if (detail.error || !detail.data) return <div className="flex flex-1 items-center justify-center text-danger-500">Sunucu yüklenemedi</div>;
  const g = detail.data;
  const current = channels.find((c) => c.id === channelId && c.type === "text");
  const p = g.guild.myPermissions;
  const canSettings = hasFlag(p, Permission.MANAGE_SERVER) || hasFlag(p, Permission.MANAGE_ROLES) || hasFlag(p, Permission.BAN_MEMBERS);

  return (
    <>
      <aside className="flex w-60 shrink-0 flex-col bg-ink-850">
        <header className="flex h-12 items-center justify-between gap-1 border-b border-ink-950/60 px-3">
          <h2 className="flex-1 truncate font-display font-semibold">{g.guild.name}</h2>
          {hasFlag(p, Permission.CREATE_INVITE) && <IconButton icon="link" label="Davet oluştur" onClick={() => setModal({ type: "invite" })} />}
          {canSettings && <IconButton icon="settings" label="Sunucu ayarları" onClick={() => setModal({ type: "settings" })} />}
        </header>
        <ChannelList detail={g} channelId={channelId} onSelect={(id) => selectChannel(guildId, id)} onCreate={(parentId) => setModal({ type: "channel", parentId })} />
        <VoiceConnectionPanel guild={g} />
        <UserPanel onOpenSettings={onOpenSettings} />
      </aside>

      <main className="flex min-w-0 flex-1 flex-col bg-ink-800">
        <Stage detail={g} />
        {current ? (
          <Chat
            key={current.id}
            target={{ kind: "guild", channel: current, detail: g }}
            onOpenSearch={() => setModal({ type: "search" })}
            headerExtra={
              <IconButton
                icon="users"
                label={showMembers ? "Üye listesini gizle" : "Üye listesini göster"}
                className={showMembers ? "bg-ink-700 text-ink-100" : ""}
                onClick={() => useSettings.getState().set({ showMembers: !showMembers })}
              />
            }
          />
        ) : (
          <div className="m-auto text-ink-400">Bir yazı kanalı seç</div>
        )}
      </main>

      {showMembers && <MemberList detail={g} />}

      {modal?.type === "channel" && <CreateChannelModal guildId={guildId} parentId={modal.parentId} onClose={() => setModal(null)} />}
      {modal?.type === "invite" && <InviteModal guildId={guildId} onClose={() => setModal(null)} />}
      {modal?.type === "settings" && <GuildSettings detail={g} onClose={() => setModal(null)} />}
      {modal?.type === "search" && (
        <SearchPanel
          detail={g}
          onClose={() => setModal(null)}
          onJump={(cid) => {
            selectChannel(guildId, cid);
            setModal(null);
          }}
        />
      )}
    </>
  );
}

function ChannelList({ detail, channelId, onSelect, onCreate }: { detail: GuildDetail; channelId?: string; onSelect: (id: string) => void; onCreate: (parentId: string | null) => void }) {
  const qc = useQueryClient();
  const canManage = hasFlag(detail.guild.myPermissions, Permission.MANAGE_CHANNELS);
  const [dragId, setDragId] = useState<string | null>(null);
  const unread = useRealtime((s) => s.unread);

  const groups = useMemo(() => {
    const sorted = [...detail.channels].sort((a, b) => a.position - b.position || a.id.localeCompare(b.id));
    const cats = sorted.filter((c) => c.type === "category");
    const orphan = sorted.filter((c) => c.type !== "category" && (!c.parentId || !cats.some((k) => k.id === c.parentId)));
    return [{ cat: null as ChannelDTO | null, items: orphan }, ...cats.map((cat) => ({ cat, items: sorted.filter((c) => c.parentId === cat.id) }))];
  }, [detail.channels]);

  async function drop(e: DragEvent, target: ChannelDTO) {
    e.preventDefault();
    const moving = detail.channels.find((c) => c.id === dragId);
    setDragId(null);
    if (!moving || moving.id === target.id || moving.type === "category") return;
    const parentId = target.parentId;
    const siblings = detail.channels.filter((c) => c.type !== "category" && c.parentId === parentId && c.id !== moving.id).sort((a, b) => a.position - b.position);
    siblings.splice(
      siblings.findIndex((c) => c.id === target.id),
      0,
      moving,
    );
    try {
      await Promise.all(siblings.map((c, i) => (c.position !== i || c.parentId !== parentId || c.id === moving.id ? api.updateChannel(c.id, { position: i, parentId }) : null)));
    } catch (err) {
      toast((err as Error).message);
    }
    void qc.invalidateQueries({ queryKey: ["guild", detail.guild.id] });
  }

  async function remove(c: ChannelDTO) {
    if (!confirm(`"${c.name}" silinsin mi?`)) return;
    try {
      await api.deleteChannel(c.id);
    } catch (err) {
      toast((err as Error).message);
    }
    void qc.invalidateQueries({ queryKey: ["guild", detail.guild.id] });
  }

  async function rename(c: ChannelDTO) {
    const name = prompt("Yeni ad", c.name);
    if (!name || name === c.name) return;
    try {
      await api.updateChannel(c.id, { name });
    } catch (err) {
      toast((err as Error).message);
    }
    void qc.invalidateQueries({ queryKey: ["guild", detail.guild.id] });
  }

  return (
    <div className="flex-1 overflow-y-auto px-2 py-3">
      {groups.map(({ cat, items }) =>
        cat === null && items.length === 0 ? null : (
          <section key={cat?.id ?? "root"} className="mb-4">
            {cat && (
              <div className="group mb-1 flex items-center justify-between px-2">
                <span className="text-[11px] font-semibold tracking-wider text-ink-400 uppercase" onDoubleClick={() => canManage && void rename(cat)}>
                  {cat.name}
                </span>
                {canManage && (
                  <button className="text-ink-400 opacity-0 group-hover:opacity-100 hover:text-ink-100" title="Kanal ekle" onClick={() => onCreate(cat.id)}>
                    <Icon name="plus" size={14} />
                  </button>
                )}
              </div>
            )}
            {items.map((c) => (
              <div key={c.id} draggable={canManage} onDragStart={() => setDragId(c.id)} onDragOver={(e) => dragId && e.preventDefault()} onDrop={(e) => void drop(e, c)}>
                {c.type === "text" ? (
                  <button
                    onClick={() => onSelect(c.id)}
                    onDoubleClick={() => canManage && void rename(c)}
                    className={cx(
                      "group flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left",
                      c.id === channelId ? "bg-ink-700 text-ink-100" : unread[c.id] ? "font-semibold text-ink-100 hover:bg-ink-750" : "text-ink-300 hover:bg-ink-750 hover:text-ink-100",
                    )}
                  >
                    <Icon name={c.isPrivate ? "lock" : "hash"} size={16} className="shrink-0 text-ink-400" />
                    <span className="flex-1 truncate">{c.name}</span>
                    {!!unread[c.id] && c.id !== channelId && <span className="rounded-full bg-amber-500 px-1.5 text-[11px] font-bold text-ink-950">{unread[c.id]}</span>}
                    {canManage && (
                      <span role="button" aria-label="Kanalı sil" className="hidden text-ink-500 group-hover:block hover:text-danger-500" onClick={(e) => (e.stopPropagation(), void remove(c))}>
                        <Icon name="trash" size={14} />
                      </span>
                    )}
                  </button>
                ) : (
                  <VoiceChannelRow channel={c} detail={detail} canManage={canManage} onDelete={() => void remove(c)} onRename={() => void rename(c)} />
                )}
              </div>
            ))}
          </section>
        ),
      )}
      {canManage && (
        <button className="mt-1 flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-ink-400 hover:bg-ink-750 hover:text-ink-100" onClick={() => onCreate(null)}>
          <Icon name="plus" size={16} /> Kanal ekle
        </button>
      )}
    </div>
  );
}

function VoiceChannelRow({ channel, detail, canManage, onDelete, onRename }: { channel: ChannelDTO; detail: GuildDetail; canManage: boolean; onDelete: () => void; onRename: () => void }) {
  const voice = useRealtime((s) => s.guilds[detail.guild.id]?.voice ?? {});
  const myChannel = useVoice((s) => s.channelId);
  const watching = useScreen((s) => s.watching);
  const me = useSession((s) => s.user)!;
  const [menu, setMenu] = useState<{ id: string; at: MenuAnchor } | null>(null);
  const [dropHover, setDropHover] = useState(false);
  const participants = Object.values(voice).filter((p) => p.channelId === channel.id);
  const canConnect = hasFlag(channel.myPermissions, Permission.CONNECT_VOICE);
  const canMove = hasFlag(channel.myPermissions, Permission.MOVE_MEMBERS);

  /** Başka bir sesli kanaldan sürüklenen kullanıcıyı bu kanala taşı. */
  function onDrop(e: DragEvent) {
    const userId = e.dataTransfer.getData(VOICE_DRAG);
    setDropHover(false);
    if (!userId) return;
    e.preventDefault();
    e.stopPropagation();
    if (voice[userId]?.channelId === channel.id) return;
    if (userId === me.id) return join();
    realtime.client(detail.guild.id)?.send({ t: "voice.move", userId, channelId: channel.id });
  }

  function join() {
    const client = realtime.client(detail.guild.id);
    if (!client || !canConnect) return;
    void voiceSession.join(client, channel.id);
  }

  return (
    <div>
      <button
        onClick={join}
        onDoubleClick={() => canManage && onRename()}
        disabled={!canConnect}
        data-voice-channel={channel.name}
        onDragOver={(e) => {
          if (!e.dataTransfer.types.includes(VOICE_DRAG)) return;
          e.preventDefault();
          e.stopPropagation();
          setDropHover(true);
        }}
        onDragLeave={() => setDropHover(false)}
        onDrop={onDrop}
        className={cx(
          "group flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left disabled:opacity-50",
          myChannel === channel.id ? "text-voice-400" : "text-ink-300 hover:bg-ink-750 hover:text-ink-100",
          dropHover && "bg-voice-500/20 ring-1 ring-voice-400",
        )}
      >
        <Icon name="speaker" size={16} className="shrink-0" />
        <span className="flex-1 truncate">{channel.name}</span>
        {detail.guild.afkChannelId === channel.id && (
          <span title="AFK odası: buraya geçende alarm çalar" className="rounded bg-red-600/80 px-1 text-[10px] font-bold text-white">
            AFK
          </span>
        )}
        {canManage && (
          <span role="button" aria-label="Kanalı sil" className="hidden text-ink-500 group-hover:block hover:text-danger-500" onClick={(e) => (e.stopPropagation(), onDelete())}>
            <Icon name="trash" size={14} />
          </span>
        )}
      </button>
      {participants.length > 0 && (
        <ul className="mb-1 ml-7 space-y-0.5">
          {participants.map((p) => {
            const m = detail.members.find((x) => x.user.id === p.userId);
            const name = m?.nickname ?? m?.user.displayName ?? "?";
            return (
              <li
                key={p.userId}
                className="relative"
                draggable={canMove || p.userId === me.id}
                onDragStart={(e) => {
                  // Üstteki kanal satırının sıralama sürüklemesini tetiklemesin
                  e.stopPropagation();
                  e.dataTransfer.setData(VOICE_DRAG, p.userId);
                  e.dataTransfer.effectAllowed = "move";
                }}
                data-voice-user={name}
              >
                <div
                  className="flex cursor-grab items-center gap-2 rounded px-1 py-0.5 text-[13px] text-ink-300 hover:bg-ink-750"
                  onContextMenu={(e) => {
                    e.preventDefault();
                    setMenu({ id: p.userId, at: { x: e.clientX, y: e.clientY } });
                  }}
                >
                  <button
                    className="flex min-w-0 flex-1 items-center gap-2 text-left"
                    onClick={(e) => setMenu(menu?.id === p.userId ? null : { id: p.userId, at: { x: e.clientX, y: e.clientY } })}
                  >
                    <Avatar name={name} id={p.userId} url={m?.user.avatarUrl} size={22} speaking={p.speaking} />
                    <span className="truncate">{name}</span>
                  </button>
                  {p.streaming && (
                    <button
                      className={cx("rounded px-1 text-[10px] font-bold", watching[p.userId] !== undefined ? "bg-ink-600 text-ink-200" : "bg-danger-500 text-white")}
                      title={p.userId === me.id ? "Yayın yapıyorsun" : watching[p.userId] !== undefined ? "İzlemeyi bırak" : "Yayını izle"}
                      onClick={() => {
                        if (p.userId === me.id) return;
                        if (myChannel !== channel.id) return toast("Yayını izlemek için bu kanala katıl");
                        if (watching[p.userId] !== undefined) screenShare.unwatch(p.userId);
                        else screenShare.watch(p.userId);
                      }}
                    >
                      CANLI
                    </button>
                  )}
                  {(p.serverDeaf || p.selfDeaf) && <Icon name="headphonesOff" size={14} className={p.serverDeaf ? "text-danger-500" : "text-ink-400"} />}
                  {!p.selfDeaf && !p.serverDeaf && (p.selfMute || p.serverMute) && <Icon name="micOff" size={14} className={p.serverMute ? "text-danger-500" : "text-ink-400"} />}
                </div>
                {menu?.id === p.userId && m && <MemberMenu member={m} detail={detail} anchor={menu.at} onClose={() => setMenu(null)} />}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function CreateChannelModal({ guildId, parentId, onClose }: { guildId: string; parentId: string | null; onClose: () => void }) {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [type, setType] = useState<"text" | "voice" | "category">("text");
  const [isPrivate, setPrivate] = useState(false);
  const m = useMutation({
    mutationFn: () => api.createChannel(guildId, { name: name.trim(), type, parentId: type === "category" ? null : parentId, isPrivate }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["guild", guildId] });
      onClose();
    },
    onError: (e) => toast(e instanceof ApiError ? e.message : "Kanal oluşturulamadı"),
  });
  return (
    <Modal title="Kanal oluştur" onClose={onClose}>
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          if (name.trim()) m.mutate();
        }}
      >
        <div className="grid grid-cols-3 gap-2">
          {(["text", "voice", "category"] as const).map((t) => (
            <button
              type="button"
              key={t}
              onClick={() => setType(t)}
              className={cx("rounded-lg border px-3 py-2 text-sm", type === t ? "border-amber-500 bg-amber-500/10 text-amber-400" : "border-ink-700 text-ink-300 hover:bg-ink-750")}
            >
              {t === "text" ? "Yazı" : t === "voice" ? "Ses" : "Kategori"}
            </button>
          ))}
        </div>
        <TextInput label="Ad" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
        {type !== "category" && (
          <label className="flex items-center gap-2 text-sm text-ink-300">
            <input type="checkbox" checked={isPrivate} onChange={(e) => setPrivate(e.target.checked)} className="accent-amber-500" />
            Özel kanal (yalnızca izin verilenler görür)
          </label>
        )}
        <div className="flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Vazgeç
          </Button>
          <Button type="submit" disabled={!name.trim() || m.isPending}>
            Oluştur
          </Button>
        </div>
      </form>
    </Modal>
  );
}

function InviteModal({ guildId, onClose }: { guildId: string; onClose: () => void }) {
  const invite = useQuery({ queryKey: ["invite", guildId], queryFn: () => api.createInvite(guildId), staleTime: Infinity });
  return (
    <Modal title="Arkadaşını davet et" onClose={onClose}>
      <p className="mb-3 text-sm text-ink-300">Bu kodu arkadaşına gönder; “Sunucu oluştur veya katıl” ekranından katılabilir.</p>
      <div className="flex gap-2">
        <input readOnly value={invite.data?.code ?? "…"} className="selectable h-10 flex-1 rounded-lg border border-ink-700 bg-ink-950 px-3 font-mono" />
        <Button
          disabled={!invite.data}
          onClick={() => {
            void navigator.clipboard.writeText(invite.data!.code);
            toast("Kopyalandı");
          }}
        >
          Kopyala
        </Button>
      </div>
    </Modal>
  );
}

function MemberList({ detail }: { detail: GuildDetail }) {
  const presence = useRealtime((s) => s.guilds[detail.guild.id]?.presence ?? {});
  const voice = useRealtime((s) => s.guilds[detail.guild.id]?.voice ?? {});
  const [menu, setMenu] = useState<{ id: string; at: MenuAnchor } | null>(null);
  const topRole = (roleIds: string[]) =>
    detail.roles
      .filter((r) => roleIds.includes(r.id))
      .sort((a, b) => b.position - a.position)[0];
  const channelName = (id: string) => detail.channels.find((c) => c.id === id)?.name ?? "ses";
  const sorted = [...detail.members].sort((a, b) => a.user.displayName.localeCompare(b.user.displayName, "tr"));
  const isOnline = (id: string) => (presence[id] && presence[id] !== "offline") || !!voice[id];
  // Seste olanlar en üstte
  const online = sorted.filter((m) => isOnline(m.user.id)).sort((a, b) => Number(!!voice[b.user.id]) - Number(!!voice[a.user.id]));
  const offline = sorted.filter((m) => !isOnline(m.user.id));

  const row = (m: MemberDTO, dim: boolean) => {
    const role = topRole(m.roleIds);
    const name = m.nickname ?? m.user.displayName;
    const v = voice[m.user.id];
    const status = (presence[m.user.id] as string | undefined) ?? (v ? "online" : undefined);
    const open = (e: React.MouseEvent) => {
      e.preventDefault();
      setMenu(menu?.id === m.user.id && e.type === "click" ? null : { id: m.user.id, at: { x: e.clientX, y: e.clientY } });
    };
    return (
      <li key={m.user.id} data-testid="member-row">
        <button className={cx("flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left hover:bg-ink-750", dim && "opacity-45")} onClick={open} onContextMenu={open}>
          <Avatar name={name} id={m.user.id} url={m.user.avatarUrl} size={32} speaking={v?.speaking} status={dim ? undefined : status} />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm" style={{ color: role?.color ?? undefined }}>
              {name}
              {m.user.id === detail.guild.ownerId && <span className="ml-1 text-[10px] text-amber-400">★</span>}
            </span>
            {v ? (
              <span className="flex items-center gap-1 truncate text-[11px] text-voice-400">
                <Icon name="speaker" size={11} /> {channelName(v.channelId)}
                {v.streaming && <span className="rounded bg-danger-500 px-1 text-[9px] font-bold text-white">CANLI</span>}
                {(v.selfMute || v.serverMute) && <Icon name="micOff" size={11} className="text-ink-400" />}
              </span>
            ) : (
              !dim && status && status !== "online" && <span className="block text-[11px] text-ink-400">{status === "busy" ? "Meşgul" : status === "idle" ? "Boşta" : ""}</span>
            )}
          </span>
        </button>
        {menu?.id === m.user.id && <MemberMenu member={m} detail={detail} anchor={menu.at} onClose={() => setMenu(null)} />}
      </li>
    );
  };

  const inVoice = Object.keys(voice).length;
  return (
    <aside className="w-60 shrink-0 overflow-y-auto bg-ink-850 px-2 py-4" aria-label="Üyeler">
      <h3 className="mb-1 px-2 text-[11px] font-semibold tracking-wider text-ink-400 uppercase">
        Çevrimiçi — {online.length}
        {inVoice > 0 && <span className="ml-1 text-voice-400 normal-case">· {inVoice} seste</span>}
      </h3>
      <ul className="mb-4">{online.map((m) => row(m, false))}</ul>
      <h3 className="mb-1 px-2 text-[11px] font-semibold tracking-wider text-ink-400 uppercase">Çevrimdışı — {offline.length}</h3>
      <ul>{offline.map((m) => row(m, true))}</ul>
    </aside>
  );
}
