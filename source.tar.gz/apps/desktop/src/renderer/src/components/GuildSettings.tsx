import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CHANNEL_SCOPED_PERMISSIONS, hasFlag, highestRolePosition, Permission, type PermissionName, type RoleDTO } from "@yanki/shared";
import { useEffect, useRef, useState } from "react";
import { api, type GuildDetail } from "../lib/api";
import { squareImage } from "../lib/image";
import { afkAlarm } from "../media/afk-alarm";
import { useSession } from "../stores/app";
import { Avatar, Button, cx, Modal, TextInput, toast } from "./ui";

export const PERMISSION_LABELS: Record<PermissionName, string> = {
  ADMINISTRATOR: "Yönetici (tüm izinler)",
  MANAGE_SERVER: "Sunucuyu yönet",
  MANAGE_CHANNELS: "Kanalları yönet",
  MANAGE_ROLES: "Rolleri ve izinleri yönet",
  VIEW_CHANNEL: "Kanalı görüntüle",
  SEND_MESSAGES: "Mesaj gönder",
  MANAGE_MESSAGES: "Mesajları yönet (başkasınınkini sil)",
  CONNECT_VOICE: "Sesli kanala bağlan",
  SPEAK: "Konuş",
  MUTE_MEMBERS: "Üyeleri sustur",
  DEAFEN_MEMBERS: "Üyeleri sağırlaştır",
  MOVE_MEMBERS: "Üyeleri taşı / sesten çıkar",
  KICK_MEMBERS: "Üyeleri at",
  BAN_MEMBERS: "Üyeleri yasakla",
  MANAGE_SOUNDBOARD: "Soundboard'u yönet",
  UPLOAD_SOUNDS: "Ses yükle",
  PLAY_SOUNDS: "Ses çal",
  SCREEN_SHARE: "Ekran paylaş",
  CREATE_INVITE: "Davet oluştur",
};
const ALL_NAMES = Object.keys(PERMISSION_LABELS) as PermissionName[];

type Tab = "general" | "roles" | "channels" | "bans";

export function GuildSettings({ detail, onClose }: { detail: GuildDetail; onClose: () => void }) {
  const p = detail.guild.myPermissions;
  const tabs: [Tab, string, boolean][] = [
    ["general", "Genel", hasFlag(p, Permission.MANAGE_SERVER)],
    ["roles", "Roller", hasFlag(p, Permission.MANAGE_ROLES)],
    ["channels", "Kanal izinleri", hasFlag(p, Permission.MANAGE_ROLES)],
    ["bans", "Yasaklar", hasFlag(p, Permission.BAN_MEMBERS)],
  ];
  const allowed = tabs.filter((t) => t[2]);
  const [tab, setTab] = useState<Tab>(allowed[0]?.[0] ?? "general");
  return (
    <Modal title={`${detail.guild.name} — Ayarlar`} onClose={onClose} width={760}>
      <div className="flex gap-5">
        <nav className="w-40 shrink-0 space-y-1">
          {allowed.map(([k, label]) => (
            <button key={k} onClick={() => setTab(k)} className={cx("w-full rounded-lg px-3 py-1.5 text-left text-sm", tab === k ? "bg-ink-700 text-ink-100" : "text-ink-300 hover:bg-ink-750")}>
              {label}
            </button>
          ))}
        </nav>
        <div className="min-h-[420px] min-w-0 flex-1">
          {tab === "general" && <General detail={detail} />}
          {tab === "roles" && <Roles detail={detail} />}
          {tab === "channels" && <ChannelPerms detail={detail} />}
          {tab === "bans" && <Bans detail={detail} />}
        </div>
      </div>
    </Modal>
  );
}

function useRefresh(gid: string) {
  const qc = useQueryClient();
  return () => Promise.all([qc.invalidateQueries({ queryKey: ["guild", gid] }), qc.invalidateQueries({ queryKey: ["guilds"] })]);
}

function General({ detail }: { detail: GuildDetail }) {
  const [name, setName] = useState(detail.guild.name);
  const refresh = useRefresh(detail.guild.id);
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        {detail.guild.iconUrl ? <img src={detail.guild.iconUrl} alt="" className="h-20 w-20 rounded-2xl object-cover" /> : <Avatar name={detail.guild.name} id={detail.guild.id} size={80} />}
        <label className="cursor-pointer rounded-lg bg-ink-750 px-3 py-2 text-sm hover:bg-ink-700">
          Sunucu resmi yükle
          <input
            type="file"
            accept="image/png,image/jpeg,image/gif,image/webp"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                await api.uploadGuildIcon(detail.guild.id, await squareImage(f));
                await refresh();
                toast("Sunucu resmi güncellendi");
              } catch (err) {
                toast((err as Error).message);
              }
            }}
          />
        </label>
      </div>
      <div className="flex items-end gap-2">
        <div className="flex-1">
          <TextInput label="Sunucu adı" value={name} maxLength={64} onChange={(e) => setName(e.target.value)} />
        </div>
        <Button
          disabled={!name.trim() || name === detail.guild.name}
          onClick={async () => {
            try {
              await api.updateGuild(detail.guild.id, { name: name.trim() });
              await refresh();
              toast("Kaydedildi");
            } catch (err) {
              toast((err as Error).message);
            }
          }}
        >
          Kaydet
        </Button>
      </div>
      <AfkSection detail={detail} />
    </div>
  );
}

/** AFK odası: buraya geçen kişide alarm durmadan çalar (o kişi çıkana dek). */
function AfkSection({ detail }: { detail: GuildDetail }) {
  const gid = detail.guild.id;
  const refresh = useRefresh(gid);
  const sounds = useQuery({ queryKey: ["sounds", gid], queryFn: () => api.guildSounds(gid) });
  const voiceChannels = detail.channels.filter((c) => c.type === "voice").sort((a, b) => a.position - b.position);
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState(false);
  const testingRef = useRef(false);
  testingRef.current = testing;
  // Yalnızca önizleme çalıyorsa durdur (gerçek AFK alarmına dokunma)
  useEffect(() => () => void (testingRef.current && afkAlarm.stop()), []);

  async function save(patch: { afkChannelId?: string | null; afkSoundId?: string | null }) {
    setBusy(true);
    try {
      await api.updateGuild(gid, patch);
      await refresh();
      toast("AFK ayarı kaydedildi");
    } catch (err) {
      toast((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const selected = sounds.data?.find((s) => s.id === detail.guild.afkSoundId) ?? null;
  return (
    <section className="space-y-3 border-t border-ink-700 pt-4">
      <div>
        <h3 className="text-sm font-semibold text-ink-100">AFK odası</h3>
        <p className="text-xs text-ink-400">Bu odaya geçen (ya da taşınan) kişide alarm, odadan çıkana kadar durmadan çalar. Başkaları duymaz.</p>
      </div>
      <label className="block text-xs text-ink-300">
        AFK kanalı
        <select
          aria-label="AFK kanalı"
          disabled={busy}
          value={detail.guild.afkChannelId ?? ""}
          onChange={(e) => void save({ afkChannelId: e.target.value || null })}
          className="mt-1 w-full rounded-lg bg-ink-900 px-3 py-2 text-sm text-ink-100"
        >
          <option value="">Kapalı</option>
          {voiceChannels.map((c) => (
            <option key={c.id} value={c.id}>
              🔊 {c.name}
            </option>
          ))}
        </select>
      </label>
      <div className="flex items-end gap-2">
        <label className="block flex-1 text-xs text-ink-300">
          Alarm sesi
          <select
            aria-label="Alarm sesi"
            disabled={busy || !detail.guild.afkChannelId}
            value={detail.guild.afkSoundId ?? ""}
            onChange={(e) => void save({ afkSoundId: e.target.value || null })}
            className="mt-1 w-full rounded-lg bg-ink-900 px-3 py-2 text-sm text-ink-100"
          >
            <option value="">⏰ Yerleşik alarm</option>
            {sounds.data?.map((s) => (
              <option key={s.id} value={s.id}>
                {s.emoji} {s.name}
              </option>
            ))}
          </select>
        </label>
        <Button
          variant="subtle"
          onClick={() => {
            if (testing) {
              afkAlarm.stop();
              setTesting(false);
            } else {
              void afkAlarm.start(selected ? { sha256: selected.sha256, url: selected.url, volume: selected.volume } : null);
              setTesting(true);
            }
          }}
        >
          {testing ? "Durdur" : "Dinle"}
        </Button>
      </div>
      <p className="text-xs text-ink-400">Alarm sesi listesi bu sunucunun soundboard'undan gelir; yeni ses için önce soundboard'a yükle.</p>
    </section>
  );
}

function Roles({ detail }: { detail: GuildDetail }) {
  const me = useSession((s) => s.user)!;
  const refresh = useRefresh(detail.guild.id);
  const roles = [...detail.roles].sort((a, b) => b.position - a.position);
  const [selected, setSelected] = useState<string>(roles.find((r) => r.id !== detail.guild.id)?.id ?? detail.guild.id);
  const role = roles.find((r) => r.id === selected) ?? roles[0]!;
  const myMember = detail.members.find((m) => m.user.id === me.id);
  const isOwner = detail.guild.ownerId === me.id;
  const myTop = highestRolePosition({ isOwner, userId: me.id, everyoneRoleId: detail.guild.id, roles: detail.roles, memberRoleIds: myMember?.roleIds ?? [] });
  const editable = role.id === detail.guild.id || isOwner || role.position < myTop;

  return (
    <div className="flex gap-4">
      <div className="w-44 shrink-0 space-y-1">
        {roles.map((r) => (
          <button key={r.id} onClick={() => setSelected(r.id)} className={cx("flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-sm", r.id === selected ? "bg-ink-700" : "hover:bg-ink-750")}>
            <span className="h-3 w-3 shrink-0 rounded-full" style={{ background: r.color ?? "var(--color-ink-400)" }} />
            <span className="truncate">{r.name}</span>
          </button>
        ))}
        <Button
          variant="subtle"
          className="mt-2 h-8 w-full text-xs"
          onClick={async () => {
            const name = prompt("Rol adı");
            if (!name) return;
            try {
              const r = await api.createRole(detail.guild.id, { name, permissions: 0 });
              await refresh();
              setSelected(r.id);
            } catch (err) {
              toast((err as Error).message);
            }
          }}
        >
          + Rol oluştur
        </Button>
      </div>
      <RoleEditor key={role.id} role={role} detail={detail} editable={editable} myPerms={detail.guild.myPermissions} onSaved={refresh} />
    </div>
  );
}

function RoleEditor({ role, detail, editable, myPerms, onSaved }: { role: RoleDTO; detail: GuildDetail; editable: boolean; myPerms: number; onSaved: () => Promise<unknown> }) {
  const isEveryone = role.id === detail.guild.id;
  const [name, setName] = useState(role.name);
  const [color, setColor] = useState(role.color ?? "#9aa3b1");
  const [perms, setPerms] = useState(role.permissions);
  const dirty = name !== role.name || perms !== role.permissions || (color !== (role.color ?? "#9aa3b1") && !isEveryone);
  async function save() {
    try {
      await api.updateRole(detail.guild.id, role.id, { ...(isEveryone ? {} : { name, color }), permissions: perms });
      await onSaved();
      toast("Rol kaydedildi");
    } catch (err) {
      toast((err as Error).message);
    }
  }
  return (
    <div className="min-w-0 flex-1 space-y-3">
      {!editable && <p className="rounded-lg bg-ink-750 px-3 py-2 text-xs text-ink-300">Bu rol senin en yüksek rolünle eşit veya üstünde; düzenleyemezsin.</p>}
      {!isEveryone && (
        <div className="flex items-end gap-2">
          <div className="flex-1">
            <TextInput label="Ad" value={name} disabled={!editable} onChange={(e) => setName(e.target.value)} />
          </div>
          <label className="block">
            <span className="mb-1.5 block text-xs font-semibold tracking-wide text-ink-300 uppercase">Renk</span>
            <input type="color" value={color} disabled={!editable} onChange={(e) => setColor(e.target.value)} className="h-10 w-14 rounded-lg border border-ink-700 bg-ink-950" />
          </label>
        </div>
      )}
      <div className="max-h-72 space-y-0.5 overflow-y-auto rounded-lg border border-ink-700 p-2">
        {ALL_NAMES.map((n) => {
          const flag = Permission[n];
          const canGrant = hasFlag(myPerms, flag);
          return (
            <label key={n} className={cx("flex items-center justify-between rounded px-2 py-1.5 text-sm hover:bg-ink-750", (!editable || !canGrant) && "opacity-50")}>
              {PERMISSION_LABELS[n]}
              <input
                type="checkbox"
                className="accent-amber-500"
                disabled={!editable || !canGrant}
                checked={hasFlag(perms, flag)}
                onChange={(e) => setPerms(e.target.checked ? perms | flag : perms & ~flag)}
              />
            </label>
          );
        })}
      </div>
      <div className="flex justify-between">
        {!isEveryone && editable ? (
          <Button
            variant="danger"
            onClick={async () => {
              if (!confirm(`"${role.name}" rolü silinsin mi?`)) return;
              try {
                await api.deleteRole(detail.guild.id, role.id);
                await onSaved();
              } catch (err) {
                toast((err as Error).message);
              }
            }}
          >
            Rolü sil
          </Button>
        ) : (
          <span />
        )}
        <Button disabled={!editable || !dirty} onClick={() => void save()}>
          Kaydet
        </Button>
      </div>
    </div>
  );
}

const CHANNEL_PERMS = ALL_NAMES.filter((n) => (CHANNEL_SCOPED_PERMISSIONS & Permission[n]) === Permission[n]);

/** Kanal başına rol izinleri: her izin için Varsayılan / İzin ver / Engelle. */
function ChannelPerms({ detail }: { detail: GuildDetail }) {
  const refresh = useRefresh(detail.guild.id);
  const channels = detail.channels.filter((c) => c.type !== "category");
  const [cid, setCid] = useState(channels[0]?.id ?? "");
  const [rid, setRid] = useState(detail.guild.id);
  const channel = detail.channels.find((c) => c.id === cid);
  const ow = channel?.overwrites?.find((o) => o.targetType === "role" && o.targetId === rid) ?? { allow: 0, deny: 0 };
  const [allow, setAllow] = useState(ow.allow);
  const [deny, setDeny] = useState(ow.deny);
  const [key, setKey] = useState(`${cid}:${rid}`);
  if (key !== `${cid}:${rid}`) {
    setKey(`${cid}:${rid}`);
    setAllow(ow.allow);
    setDeny(ow.deny);
  }
  if (!channel) return <p className="text-sm text-ink-400">Kanal yok.</p>;
  const sel = "h-9 rounded-lg border border-ink-700 bg-ink-950 px-2 text-sm outline-none";
  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <select className={cx(sel, "flex-1")} value={cid} onChange={(e) => setCid(e.target.value)} aria-label="Kanal">
          {channels.map((c) => (
            <option key={c.id} value={c.id}>
              {c.type === "voice" ? "🔊 " : "# "}
              {c.name}
            </option>
          ))}
        </select>
        <select className={cx(sel, "flex-1")} value={rid} onChange={(e) => setRid(e.target.value)} aria-label="Rol">
          {[...detail.roles]
            .sort((a, b) => b.position - a.position)
            .map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
        </select>
      </div>
      <div className="space-y-0.5 rounded-lg border border-ink-700 p-2">
        {CHANNEL_PERMS.map((n) => {
          const f = Permission[n];
          const state = hasFlag(allow, f) ? "allow" : hasFlag(deny, f) ? "deny" : "inherit";
          const set = (s: "allow" | "deny" | "inherit") => {
            setAllow(s === "allow" ? allow | f : allow & ~f);
            setDeny(s === "deny" ? deny | f : deny & ~f);
          };
          return (
            <div key={n} className="flex items-center justify-between rounded px-2 py-1 text-sm hover:bg-ink-750">
              {PERMISSION_LABELS[n]}
              <div className="flex overflow-hidden rounded-md border border-ink-700 text-xs">
                {(
                  [
                    ["deny", "✕", "bg-danger-500 text-white"],
                    ["inherit", "/", "bg-ink-600 text-ink-100"],
                    ["allow", "✓", "bg-voice-500 text-ink-950"],
                  ] as const
                ).map(([k, label, on]) => (
                  <button key={k} onClick={() => set(k)} className={cx("w-8 py-0.5", state === k ? on : "text-ink-400 hover:bg-ink-700")} aria-label={`${PERMISSION_LABELS[n]}: ${k}`}>
                    {label}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex justify-end gap-2">
        <Button
          variant="ghost"
          onClick={async () => {
            await api.deleteOverwrite(cid, "role", rid).catch((e: Error) => toast(e.message));
            await refresh();
            setAllow(0);
            setDeny(0);
          }}
        >
          Sıfırla
        </Button>
        <Button
          onClick={async () => {
            try {
              await api.setOverwrite(cid, "role", rid, allow, deny);
              await refresh();
              toast("Kanal izinleri kaydedildi");
            } catch (err) {
              toast((err as Error).message);
            }
          }}
        >
          Kaydet
        </Button>
      </div>
    </div>
  );
}

function Bans({ detail }: { detail: GuildDetail }) {
  const bans = useQuery({ queryKey: ["bans", detail.guild.id], queryFn: () => api.bans(detail.guild.id) });
  return (
    <div>
      {bans.data?.length === 0 && <p className="text-sm text-ink-400">Yasaklı kimse yok.</p>}
      <ul className="space-y-1">
        {bans.data?.map((b) => (
          <li key={b.user.id} className="flex items-center gap-3 rounded-lg bg-ink-800 px-3 py-2">
            <Avatar name={b.user.displayName} id={b.user.id} url={b.user.avatarUrl} size={30} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{b.user.displayName}</p>
              <p className="truncate text-xs text-ink-400">{b.reason ?? "Sebep belirtilmedi"}</p>
            </div>
            <Button
              variant="subtle"
              className="h-8 text-xs"
              onClick={async () => {
                await api.unban(detail.guild.id, b.user.id).catch((e: Error) => toast(e.message));
                void bans.refetch();
              }}
            >
              Yasağı kaldır
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
