import { useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { Login } from "./components/Login";
import { Shell } from "./components/Shell";
import { Toaster } from "./components/ui";
import { api, apiConfig } from "./lib/api";
import { bridge } from "./lib/bridge";
import { realtime } from "./lib/realtime";
import { voiceSession } from "./media/voice-session";
import { useSession } from "./stores/app";

export function App() {
  const { user, ready, setUser, setReady } = useSession();
  const qc = useQueryClient();

  useEffect(() => {
    const logoutLocal = () => {
      void voiceSession.leave();
      realtime.stopAll();
      apiConfig.setToken(null);
      void bridge.session.clear();
      qc.clear();
      setUser(null);
    };
    apiConfig.onUnauthorized(logoutLocal);
    window.addEventListener("yanki:logout", logoutLocal);

    (async () => {
      const settings = await bridge.settings.get();
      apiConfig.setBaseUrl(settings.apiUrl);
      const token = await bridge.session.get();
      if (token) {
        apiConfig.setToken(token);
        try {
          setUser(await api.me());
        } catch {
          // Ağ hatasıysa token'ı silme; yetkisizse onUnauthorized temizler
        }
      }
      setReady(true);
    })();
    return () => window.removeEventListener("yanki:logout", logoutLocal);
  }, [qc, setReady, setUser]);

  if (!ready) {
    return <div className="flex h-full items-center justify-center text-ink-400">Yükleniyor…</div>;
  }
  return (
    <>
      {user ? <Shell /> : <Login />}
      <Toaster />
    </>
  );
}
