import type { ScreenPreset } from "@yanki/shared";
import { create } from "zustand";
import { persist } from "zustand/middleware";

export type InputMode = "vad" | "ptt";
export type MacroAction = "toggleMute" | "toggleDeafen" | "ptt";

export interface MacroBinding {
  /** Backend'e özgü kod: "mouse:4", "key:57" (Electron) veya "dom-key:KeyV" (tarayıcı) */
  code: string;
  label: string;
}

export interface SettingsState {
  inputDeviceId: string;
  outputDeviceId: string;
  /** Varsayılan: ses algılama. Bas-konuş isteğe bağlıdır. */
  inputMode: InputMode;
  /** Sustur / sağırlaştır / bas-konuş makroları (klavye veya mouse tuşu) */
  macros: Partial<Record<MacroAction, MacroBinding>>;
  /** Makro ile susturma/sağırlaştırmada kısa onay sesi */
  macroSounds: boolean;
  /** 0..1 arası RMS eşiği (VAD) */
  vadThreshold: number;
  noiseSuppression: boolean;
  echoCancellation: boolean;
  /** Kullanıcı başına ses seviyesi (0..1) */
  userVolumes: Record<string, number>;
  /** Kullanıcı başına soundboard ses seviyesi (0..1), 0 = sustur */
  userSoundVolumes: Record<string, number>;
  soundboardVolume: number;
  /** Ses id'si → Electron accelerator (ör. "Alt+1") */
  soundKeybinds: Record<string, string>;
  screenPreset: ScreenPreset;
  /** Sağdaki üye listesi açık mı */
  showMembers: boolean;
  /** Sesli odaya giriş/çıkış sesleri */
  voiceCues: boolean;
  /** AFK odasındaki alarmın kişisel ses seviyesi (0..1) */
  afkAlarmVolume: number;
  screenAudio: boolean;
  set: (patch: Partial<Omit<SettingsState, "set">>) => void;
  setUserVolume: (userId: string, v: number) => void;
  setUserSoundVolume: (userId: string, v: number) => void;
  setKeybind: (soundId: string, acc: string | null) => void;
  setMacro: (action: MacroAction, b: MacroBinding | null) => void;
}

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      inputDeviceId: "default",
      outputDeviceId: "default",
      inputMode: "vad",
      macros: {},
      macroSounds: true,
      vadThreshold: 0.02,
      noiseSuppression: true,
      echoCancellation: true,
      userVolumes: {},
      userSoundVolumes: {},
      soundboardVolume: 0.8,
      soundKeybinds: {},
      screenPreset: "1080p30",
      showMembers: true,
      voiceCues: true,
      afkAlarmVolume: 0.7,
      screenAudio: false,
      set: (patch) => set(patch),
      setUserVolume: (userId, v) => set((s) => ({ userVolumes: { ...s.userVolumes, [userId]: v } })),
      setUserSoundVolume: (userId, v) => set((s) => ({ userSoundVolumes: { ...s.userSoundVolumes, [userId]: v } })),
      setKeybind: (soundId, acc) =>
        set((s) => {
          const next = { ...s.soundKeybinds };
          for (const [k, v] of Object.entries(next)) if (v === acc) delete next[k];
          if (acc) next[soundId] = acc;
          else delete next[soundId];
          return { soundKeybinds: next };
        }),
      setMacro: (action, b) =>
        set((s) => {
          const next = { ...s.macros };
          // Aynı tuş iki işe atanamaz
          if (b) for (const k of Object.keys(next) as MacroAction[]) if (next[k]?.code === b.code) delete next[k];
          if (b) next[action] = b;
          else delete next[action];
          return { macros: next };
        }),
    }),
    {
      name: "yanki.settings",
      version: 2,
      // v1'de bas-konuş için tek bir DOM tuşu vardı; makro sistemine taşındı
      migrate: (state) => {
        const s = state as Record<string, unknown>;
        delete s.pttKey;
        return s as unknown as SettingsState;
      },
    },
  ),
);
