import { create } from "zustand";
import type { PresenceStatus, UserDTO, VoiceParticipant } from "@yanki/shared";
import type { GatewayStatus } from "../lib/gateway";
import type { PeerStats } from "../media/transport";

interface SessionState {
  user: UserDTO | null;
  ready: boolean;
  selectedGuildId: string | null;
  selectedChannelId: Record<string, string>;
  setUser: (u: UserDTO | null) => void;
  setReady: (r: boolean) => void;
  selectGuild: (id: string | null) => void;
  selectChannel: (guildId: string, channelId: string) => void;
}

export const useSession = create<SessionState>((set) => ({
  user: null,
  ready: false,
  selectedGuildId: null,
  selectedChannelId: {},
  setUser: (user) => set({ user }),
  setReady: (ready) => set({ ready }),
  selectGuild: (selectedGuildId) => set({ selectedGuildId }),
  selectChannel: (guildId, channelId) => set((s) => ({ selectedChannelId: { ...s.selectedChannelId, [guildId]: channelId } })),
}));

interface GuildRealtime {
  status: GatewayStatus;
  presence: Record<string, PresenceStatus | "offline">;
  /** userId → katılımcı */
  voice: Record<string, VoiceParticipant>;
  /** channelId → userId → son yazma zamanı */
  typing: Record<string, Record<string, number>>;
}

interface RealtimeState {
  guilds: Record<string, GuildRealtime>;
  unread: Record<string, number>;
  patch: (guildId: string, fn: (g: GuildRealtime) => Partial<GuildRealtime>) => void;
  addUnread: (channelId: string) => void;
  clearUnread: (channelId: string) => void;
}

const emptyGuild = (): GuildRealtime => ({ status: "connecting", presence: {}, voice: {}, typing: {} });

export const useRealtime = create<RealtimeState>((set) => ({
  guilds: {},
  unread: {},
  patch: (guildId, fn) =>
    set((s) => {
      const g = s.guilds[guildId] ?? emptyGuild();
      return { guilds: { ...s.guilds, [guildId]: { ...g, ...fn(g) } } };
    }),
  addUnread: (channelId) => set((s) => ({ unread: { ...s.unread, [channelId]: (s.unread[channelId] ?? 0) + 1 } })),
  clearUnread: (channelId) =>
    set((s) => {
      if (!s.unread[channelId]) return s;
      const next = { ...s.unread };
      delete next[channelId];
      return { unread: next };
    }),
}));

export type VoiceConnState = "idle" | "connecting" | "connected" | "reconnecting" | "error";

interface VoiceState {
  guildId: string | null;
  channelId: string | null;
  state: VoiceConnState;
  error: string | null;
  selfMute: boolean;
  selfDeaf: boolean;
  /** Bir yetkili tarafından sunucuda susturuldu / sağırlaştırıldı */
  serverMute: boolean;
  serverDeaf: boolean;
  speaking: boolean;
  /** Bas-konuş tuşu basılı mı */
  pttActive: boolean;
  inputLevel: number;
  peerStats: Record<string, PeerStats>;
  turnAvailable: boolean;
  set: (p: Partial<Omit<VoiceState, "set">>) => void;
}

export const useVoice = create<VoiceState>((set) => ({
  guildId: null,
  channelId: null,
  state: "idle",
  error: null,
  selfMute: false,
  selfDeaf: false,
  serverMute: false,
  serverDeaf: false,
  speaking: false,
  pttActive: false,
  inputLevel: 0,
  peerStats: {},
  turnAvailable: false,
  set: (p) => set(p),
}));
