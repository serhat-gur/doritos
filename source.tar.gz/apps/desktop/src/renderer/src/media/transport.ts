import type { ServerEvent } from "@yanki/shared";

export type SignalData = Extract<ServerEvent, { t: "rtc.signal" }>["data"];

export interface PeerStats {
  rttMs: number | null;
  packetLossPct: number | null;
  jitterMs: number | null;
  /** Bağlantı TURN üzerinden mi geçiyor? */
  relayed: boolean;
  /** Bu eşten alınan toplam ses baytı (ses gerçekten akıyor mu?) */
  bytesReceived: number;
  state: RTCPeerConnectionState;
}

/**
 * Medya taşıma soyutlaması. VoiceSession (mikrofon, VAD, durum) taşıma
 * katmanından bağımsızdır; P2P mesh ve ileride SFU aynı arayüzü uygular.
 *
 * - MeshTransport: her katılımcı çiftine bir RTCPeerConnection (≤ ~5 kişi).
 * - SfuTransport (henüz yok): Cloudflare Realtime SFU'ya tek bağlantı ile
 *   yerel izi yayınlar, diğerlerinin izlerini çeker. Geçişte VoiceSession'daki
 *   yerel iz ve mikrofon durumu korunur; yalnızca taşıma değiştirilir.
 */
export interface MediaTransport {
  readonly kind: "mesh" | "sfu";
  setLocalTrack(track: MediaStreamTrack | null): void;
  addPeer(userId: string): void;
  removePeer(userId: string): void;
  handleSignal(from: string, data: SignalData): Promise<void>;
  stats(): Promise<Map<string, PeerStats>>;
  close(): void;
}

export interface TransportCallbacks {
  sendSignal(to: string, data: SignalData): void;
  onRemoteStream(userId: string, stream: MediaStream): void;
  onPeerState(userId: string, state: RTCPeerConnectionState): void;
}
