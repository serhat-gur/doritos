import { soundPlayer } from "./sound-player";

/**
 * AFK alarmı: kullanıcı sunucunun AFK kanalındayken kendi cihazında durmadan
 * çalar, kanaldan çıkınca susar. Yalnızca o kişide çalar; mikrofona karışmaz.
 *
 * Ses: sunucunun seçtiği soundboard sesi, yoksa yerleşik çalar saat alarmı.
 * Her tekrar arasında kısa bir boşluk bırakılır (kısa sesler vızıltıya dönmesin).
 * Sağırlaştırılmış olsan bile çalar; amaç uyandırmak.
 */
const GAP_SEC = 0.6;

class AfkAlarm {
  private ctx: AudioContext | null = null;
  private gain: GainNode | null = null;
  private src: AudioBufferSourceNode | null = null;
  private volume = 0.7;
  private token = 0;
  /** Tanılama / test */
  playing: null | "builtin" | string = null;

  private ensure(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext({ latencyHint: "interactive" });
      this.gain = this.ctx.createGain();
      this.gain.gain.value = this.volume;
      this.gain.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  setVolume(v: number): void {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.gain) this.gain.gain.value = this.volume;
  }

  setOutput(deviceId: string): void {
    const ctx = this.ensure() as AudioContext & { setSinkId?: (id: string) => Promise<void> };
    if (ctx.setSinkId) void ctx.setSinkId(deviceId === "default" ? "" : deviceId).catch(() => {});
  }

  /** `sound` null ise yerleşik alarm. Zaten çalıyorsa önce durdurur. */
  async start(sound: { sha256: string; url: string; volume: number } | null): Promise<void> {
    this.stop();
    const my = ++this.token;
    const ctx = this.ensure();
    let buffer: AudioBuffer;
    let level = 1;
    try {
      if (sound) {
        buffer = await soundPlayer.load(sound.sha256, sound.url);
        level = sound.volume;
      } else {
        buffer = builtinAlarm(ctx);
      }
    } catch {
      buffer = builtinAlarm(ctx); // ses indirilemezse yine de uyandır
      sound = null;
    }
    if (my !== this.token) return; // bu arada durduruldu / değişti
    const src = ctx.createBufferSource();
    src.buffer = withGap(ctx, buffer, GAP_SEC);
    src.loop = true;
    const g = ctx.createGain();
    g.gain.value = Math.max(0, Math.min(1, level));
    src.connect(g).connect(this.gain!);
    src.start();
    this.src = src;
    this.playing = sound ? sound.sha256 : "builtin";
  }

  stop(): void {
    this.token++;
    this.playing = null;
    if (this.src) {
      try {
        this.src.stop();
      } catch {
        /* zaten durmuş */
      }
      this.src.disconnect();
      this.src = null;
    }
  }
}

/** Sesin sonuna sessizlik ekler (döngüde tekrarlar arası boşluk). */
function withGap(ctx: AudioContext, b: AudioBuffer, gapSec: number): AudioBuffer {
  const extra = Math.round(gapSec * b.sampleRate);
  const out = ctx.createBuffer(b.numberOfChannels, b.length + extra, b.sampleRate);
  for (let ch = 0; ch < b.numberOfChannels; ch++) out.copyToChannel(b.getChannelData(ch), ch);
  return out;
}

/** Klasik çalar saat: 4 kısa "bip" (yumuşatılmış kare dalga, ~1 kHz). */
function builtinAlarm(ctx: AudioContext): AudioBuffer {
  const rate = ctx.sampleRate;
  const beep = 0.09;
  const step = 0.16;
  const count = 4;
  const len = Math.round((step * count) * rate);
  const buf = ctx.createBuffer(1, len, rate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < count; i++) {
    const s0 = Math.round(i * step * rate);
    const n = Math.round(beep * rate);
    for (let k = 0; k < n; k++) {
      const t = k / rate;
      // Kare dalganın ilk üç harmoniği: keskin ama kulak tırmalamayan
      const w = 2 * Math.PI * 1046.5 * t;
      const v = Math.sin(w) + Math.sin(3 * w) / 3 + Math.sin(5 * w) / 5;
      const env = Math.min(1, k / (0.004 * rate), (n - k) / (0.008 * rate));
      d[s0 + k] = 0.35 * v * env;
    }
  }
  return buf;
}

export const afkAlarm = new AfkAlarm();
