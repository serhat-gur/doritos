import { bridge } from "../lib/bridge";
import { useVoice } from "../stores/app";
import { useSettings, type MacroAction } from "../stores/settings";
import { voiceSession } from "./voice-session";

/**
 * Global makrolar: atanmış klavye veya mouse tuşlarıyla sustur,
 * sağırlaştır ve (isteğe bağlı) bas-konuş. Electron'da yerel kanca sayesinde
 * pencere arka plandayken / oyun açıkken de çalışır.
 */
let started = false;
let feedbackCtx: AudioContext | null = null;

function beep(up: boolean) {
  if (!useSettings.getState().macroSounds) return;
  try {
    feedbackCtx ??= new AudioContext();
    const ctx = feedbackCtx;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.frequency.setValueAtTime(up ? 660 : 440, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(up ? 880 : 330, ctx.currentTime + 0.08);
    g.gain.setValueAtTime(0.08, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.12);
    osc.connect(g).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.13);
  } catch {
    /* ses aygıtı yoksa sessizce geç */
  }
}

function syncBindings() {
  const { macros, inputMode } = useSettings.getState();
  const codes = (Object.entries(macros) as [MacroAction, { code: string }][])
    .filter(([action]) => action !== "ptt" || inputMode === "ptt")
    .map(([, b]) => b.code);
  void bridge.input.setBindings(codes);
}

export function startMacros() {
  if (started) return;
  started = true;
  syncBindings();
  useSettings.subscribe((s, prev) => {
    if (s.macros !== prev.macros || s.inputMode !== prev.inputMode) syncBindings();
  });
  bridge.input.onEvent(({ code, down }) => {
    const { macros, inputMode } = useSettings.getState();
    const v = useVoice.getState();
    if (macros.ptt?.code === code && inputMode === "ptt") {
      voiceSession.setPtt(down);
      return;
    }
    if (!down) return;
    if (macros.toggleMute?.code === code) {
      voiceSession.setMute(!v.selfMute);
      beep(v.selfMute);
    } else if (macros.toggleDeafen?.code === code) {
      voiceSession.setDeaf(!v.selfDeaf);
      beep(v.selfDeaf);
    }
  });
}

export const MACRO_LABELS: Record<MacroAction, string> = {
  toggleMute: "Mikrofonu aç/kapat",
  toggleDeafen: "Sağırlaştır / aç",
  ptt: "Bas-konuş (basılı tut)",
};
