import type { MediaTransport, PeerStats, SignalData, TransportCallbacks } from "./transport";

interface Peer {
  pc: RTCPeerConnection;
  polite: boolean;
  makingOffer: boolean;
  ignoreOffer: boolean;
  sender: RTCRtpSender | null;
  pendingCandidates: RTCIceCandidateInit[];
  lastBytes?: { lost: number; received: number };
}

/**
 * Tam örgü (mesh) P2P taşıma.
 *
 * İlk bağlantıyı yalnızca bir taraf başlatır: kullanıcı id'si küçük olan
 * ("başlatıcı") ses transceiver'ını ekler ve teklif gönderir. Diğer taraf
 * gelen teklifin oluşturduğu transceiver'a kendi mikrofon izini bağlar.
 * Böylece iki taraf aynı anda teklif gönderip (glare) birbirinin m-line'ını
 * geçersiz kılmaz. Sonraki yeniden müzakereler (ICE restart vb.) için MDN'deki
 * "perfect negotiation" deseni korunur; nazik (polite) taraf id'si büyük olandır.
 *
 * Doğrudan bağlantı (host/srflx) önce denenir; NAT engellerse ICE otomatik
 * olarak TURN (relay) adaylarına düşer. Port açmaya gerek yoktur.
 */
export class MeshTransport implements MediaTransport {
  readonly kind = "mesh" as const;
  private peers = new Map<string, Peer>();
  private localTrack: MediaStreamTrack | null = null;

  constructor(
    private selfId: string,
    private iceServers: RTCIceServer[],
    private cb: TransportCallbacks,
  ) {}

  setLocalTrack(track: MediaStreamTrack | null): void {
    this.localTrack = track;
    for (const p of this.peers.values()) {
      if (p.sender) void p.sender.replaceTrack(track);
    }
  }

  addPeer(userId: string): void {
    if (userId === this.selfId || this.peers.has(userId)) return;
    this.createPeer(userId);
  }

  removePeer(userId: string): void {
    const p = this.peers.get(userId);
    if (!p) return;
    p.pc.close();
    this.peers.delete(userId);
  }

  private createPeer(userId: string): Peer {
    const pc = new RTCPeerConnection({ iceServers: this.iceServers, bundlePolicy: "max-bundle" });
    const peer: Peer = {
      pc,
      polite: this.selfId > userId,
      makingOffer: false,
      ignoreOffer: false,
      sender: null,
      pendingCandidates: [],
    };
    this.peers.set(userId, peer);

    // Başlatıcı taraf: ses transceiver'ını ekle (negotiationneeded → teklif).
    // Yerel iz yoksa bile sendrecv: karşı tarafın sesini alabilmek için.
    if (!peer.polite) {
      const tr = pc.addTransceiver("audio", { direction: "sendrecv" });
      peer.sender = tr.sender;
      if (this.localTrack) void tr.sender.replaceTrack(this.localTrack);
    }

    pc.onnegotiationneeded = async () => {
      try {
        peer.makingOffer = true;
        await pc.setLocalDescription();
        const d = pc.localDescription!;
        this.cb.sendSignal(userId, { kind: "description", type: d.type, sdp: d.sdp });
      } catch (err) {
        console.warn("[mesh] teklif oluşturulamadı", err);
      } finally {
        peer.makingOffer = false;
      }
    };
    pc.onicecandidate = ({ candidate }) => {
      if (!candidate) return;
      this.cb.sendSignal(userId, {
        kind: "candidate",
        candidate: candidate.candidate,
        sdpMid: candidate.sdpMid,
        sdpMLineIndex: candidate.sdpMLineIndex,
      });
    };
    pc.ontrack = (e) => {
      const stream = e.streams[0] ?? new MediaStream([e.track]);
      this.cb.onRemoteStream(userId, stream);
    };
    pc.onconnectionstatechange = () => {
      this.cb.onPeerState(userId, pc.connectionState);
      // Ağ değişiminde (Wi-Fi → kablolu vb.) ICE'ı yeniden başlat
      if (pc.connectionState === "failed") pc.restartIce();
    };
    return peer;
  }

  async handleSignal(from: string, data: SignalData): Promise<void> {
    const peer = this.peers.get(from) ?? this.createPeer(from);
    const pc = peer.pc;
    try {
      if (data.kind === "description") {
        const offerCollision = data.type === "offer" && (peer.makingOffer || pc.signalingState !== "stable");
        peer.ignoreOffer = !peer.polite && offerCollision;
        if (peer.ignoreOffer) return;
        await pc.setRemoteDescription({ type: data.type, sdp: data.sdp });
        for (const c of peer.pendingCandidates.splice(0)) await pc.addIceCandidate(c).catch(() => {});
        if (data.type === "offer") {
          // Karşı tarafın açtığı ses transceiver'ına kendi izimizi bağla
          if (!peer.sender) {
            const tr = pc.getTransceivers().find((t) => t.receiver.track.kind === "audio");
            if (tr) {
              tr.direction = "sendrecv";
              peer.sender = tr.sender;
              if (this.localTrack) await tr.sender.replaceTrack(this.localTrack);
            }
          }
          await pc.setLocalDescription();
          const d = pc.localDescription!;
          this.cb.sendSignal(from, { kind: "description", type: d.type, sdp: d.sdp });
        }
      } else if (data.kind === "candidate") {
        const cand: RTCIceCandidateInit = { candidate: data.candidate, sdpMid: data.sdpMid, sdpMLineIndex: data.sdpMLineIndex };
        if (!pc.remoteDescription) {
          peer.pendingCandidates.push(cand);
          return;
        }
        try {
          await pc.addIceCandidate(cand);
        } catch (err) {
          if (!peer.ignoreOffer) throw err;
        }
      }
    } catch (err) {
      console.warn("[mesh] sinyal işlenemedi", err);
    }
  }

  async stats(): Promise<Map<string, PeerStats>> {
    const out = new Map<string, PeerStats>();
    for (const [userId, peer] of this.peers) {
      const report = await peer.pc.getStats();
      let rtt: number | null = null;
      let jitter: number | null = null;
      let lost = 0;
      let received = 0;
      let relayed = false;
      let bytesReceived = 0;
      const byId = new Map<string, RTCStats & Record<string, unknown>>();
      report.forEach((s) => byId.set(s.id, s as RTCStats & Record<string, unknown>));
      report.forEach((s) => {
        const r = s as RTCStats & Record<string, unknown>;
        if (r.type === "candidate-pair" && r.nominated && r.state === "succeeded") {
          if (typeof r.currentRoundTripTime === "number") rtt = Math.round(r.currentRoundTripTime * 1000);
          const local = byId.get(r.localCandidateId as string);
          if (local?.candidateType === "relay") relayed = true;
        }
        if (r.type === "inbound-rtp" && r.kind === "audio") {
          lost += (r.packetsLost as number) ?? 0;
          received += (r.packetsReceived as number) ?? 0;
          bytesReceived += (r.bytesReceived as number) ?? 0;
          if (typeof r.jitter === "number") jitter = Math.round(r.jitter * 1000);
        }
      });
      // Kayıp yüzdesi son ölçümden bu yana olan farka göre hesaplanır
      const prev = peer.lastBytes ?? { lost: 0, received: 0 };
      const dLost = lost - prev.lost;
      const dRecv = received - prev.received;
      peer.lastBytes = { lost, received };
      out.set(userId, {
        rttMs: rtt,
        jitterMs: jitter,
        packetLossPct: dLost + dRecv > 0 ? Math.round((dLost / (dLost + dRecv)) * 1000) / 10 : null,
        relayed,
        bytesReceived,
        state: peer.pc.connectionState,
      });
    }
    return out;
  }

  close(): void {
    for (const p of this.peers.values()) p.pc.close();
    this.peers.clear();
  }
}
