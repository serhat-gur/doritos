import { SCREEN_PRESETS, type ScreenPreset } from "@yanki/shared";
import { create } from "zustand";
import type { GatewayClient } from "../lib/gateway";
import type { SignalData } from "./transport";

/**
 * Ekran paylaşımı (P2P).
 *
 * - Yayıncı, yayını İZLEMEK İSTEYEN her kişiye ayrı bir RTCPeerConnection açar;
 *   izlemeyenlere hiç video gönderilmez (Discord'daki "Yayını izle" gibi).
 * - Sinyal türleri: izleyici → yayıncı "screen-down" (watch/unwatch/answer/aday),
 *   yayıncı → izleyici "screen-up" (offer/aday).
 * - Dinamik bitrate: WebRTC tıkanıklık kontrolü bitrate'i ağa göre kendisi
 *   düşürür; üst sınır seçilen kaliteye ve izleyici sayısına göre ayarlanır
 *   (mesh'te yayıncının yükleme bant genişliği izleyici sayısıyla bölünür).
 * - Sesli görüşme ayrı bağlantıda olduğu için paylaşım sırasında kesilmez.
 */

/** Yayıncının toplam yükleme bütçesi (bps); izleyiciler arasında bölünür. */
const UPLOAD_BUDGET = 12_000_000;
const MIN_PER_VIEWER = 800_000;

interface ScreenState {
  sharing: boolean;
  preset: ScreenPreset | null;
  audio: boolean;
  localStream: MediaStream | null;
  viewers: string[];
  /** İzlenen yayınlar: yayıncı id → akış (null = bağlanıyor) */
  watching: Record<string, MediaStream | null>;
  error: string | null;
  set: (p: Partial<Omit<ScreenState, "set">>) => void;
}

export const useScreen = create<ScreenState>((set) => ({
  sharing: false,
  preset: null,
  audio: false,
  localStream: null,
  viewers: [],
  watching: {},
  error: null,
  set: (p) => set(p),
}));

interface Link {
  pc: RTCPeerConnection;
  pending: RTCIceCandidateInit[];
}

class ScreenShare {
  private gateway: GatewayClient | null = null;
  private iceServers: RTCIceServer[] = [];
  private outgoing = new Map<string, Link>(); // izleyici id → bağlantı
  private incoming = new Map<string, Link>(); // yayıncı id → bağlantı

  attach(gateway: GatewayClient | null, iceServers: RTCIceServer[]) {
    this.gateway = gateway;
    this.iceServers = iceServers;
  }

  // ---------------------------------------------------------------- yayıncı
  async start(preset: ScreenPreset, stream: MediaStream, audio: boolean): Promise<void> {
    if (!this.gateway) throw new Error("Ekran paylaşmak için bir sesli kanalda olmalısın");
    await this.stop();
    const p = SCREEN_PRESETS[preset];
    const video = stream.getVideoTracks()[0];
    if (!video) throw new Error("Görüntü alınamadı");
    // Metin/kod okunaklı kalsın; 60 FPS'te akıcılık öncelikli
    video.contentHint = p.fps >= 60 ? "motion" : "detail";
    await video.applyConstraints({ width: { ideal: p.width }, height: { ideal: p.height }, frameRate: { ideal: p.fps, max: p.fps } }).catch(() => {});
    // Kullanıcı sistemin "Paylaşımı durdur" düğmesine basarsa
    video.addEventListener("ended", () => void this.stop());
    useScreen.getState().set({ sharing: true, preset, audio: audio && stream.getAudioTracks().length > 0, localStream: stream, viewers: [], error: null });
    this.gateway.send({ t: "screen.start", preset, audio: stream.getAudioTracks().length > 0 });
  }

  async stop(): Promise<void> {
    const s = useScreen.getState();
    for (const [viewer, link] of this.outgoing) {
      link.pc.close();
      this.outgoing.delete(viewer);
    }
    s.localStream?.getTracks().forEach((t) => t.stop());
    if (s.sharing) this.gateway?.send({ t: "screen.stop" });
    useScreen.getState().set({ sharing: false, preset: null, localStream: null, viewers: [] });
  }

  private async addViewer(viewerId: string) {
    const { localStream, preset } = useScreen.getState();
    if (!localStream || !preset) return;
    this.outgoing.get(viewerId)?.pc.close();
    const pc = new RTCPeerConnection({ iceServers: this.iceServers });
    const link: Link = { pc, pending: [] };
    this.outgoing.set(viewerId, link);
    for (const track of localStream.getTracks()) pc.addTrack(track, localStream);
    pc.onicecandidate = ({ candidate }) => {
      if (candidate) this.send(viewerId, "screen-up", { kind: "candidate", candidate: candidate.candidate, sdpMid: candidate.sdpMid, sdpMLineIndex: candidate.sdpMLineIndex });
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "failed") pc.restartIce();
    };
    useScreen.getState().set({ viewers: [...this.outgoing.keys()] });
    await this.applyBitrates();
    await pc.setLocalDescription(await pc.createOffer());
    this.send(viewerId, "screen-up", { kind: "description", type: "offer", sdp: pc.localDescription!.sdp });
  }

  private removeViewer(viewerId: string) {
    this.outgoing.get(viewerId)?.pc.close();
    this.outgoing.delete(viewerId);
    useScreen.getState().set({ viewers: [...this.outgoing.keys()] });
    void this.applyBitrates();
  }

  /** İzleyici sayısına göre her göndericinin üst bitrate'ini ayarla. */
  private async applyBitrates() {
    const preset = useScreen.getState().preset;
    if (!preset) return;
    const p = SCREEN_PRESETS[preset];
    const n = Math.max(1, this.outgoing.size);
    const max = Math.max(MIN_PER_VIEWER, Math.min(p.maxBitrate, Math.floor(UPLOAD_BUDGET / n)));
    for (const { pc } of this.outgoing.values()) {
      for (const sender of pc.getSenders()) {
        if (sender.track?.kind !== "video") continue;
        const params = sender.getParameters();
        params.encodings = params.encodings?.length ? params.encodings : [{}];
        params.encodings[0]!.maxBitrate = max;
        params.encodings[0]!.maxFramerate = p.fps;
        params.degradationPreference = p.fps >= 60 ? "maintain-framerate" : "maintain-resolution";
        await sender.setParameters(params).catch(() => {});
      }
    }
  }

  // ---------------------------------------------------------------- izleyici
  watch(sharerId: string) {
    if (!this.gateway || this.incoming.has(sharerId)) return;
    const pc = new RTCPeerConnection({ iceServers: this.iceServers });
    this.incoming.set(sharerId, { pc, pending: [] });
    pc.onicecandidate = ({ candidate }) => {
      if (candidate) this.send(sharerId, "screen-down", { kind: "candidate", candidate: candidate.candidate, sdpMid: candidate.sdpMid, sdpMLineIndex: candidate.sdpMLineIndex });
    };
    pc.ontrack = (e) => {
      const stream = e.streams[0] ?? new MediaStream([e.track]);
      useScreen.getState().set({ watching: { ...useScreen.getState().watching, [sharerId]: stream } });
    };
    useScreen.getState().set({ watching: { ...useScreen.getState().watching, [sharerId]: null } });
    this.send(sharerId, "screen-down", { kind: "watch" });
  }

  unwatch(sharerId: string, notify = true) {
    const link = this.incoming.get(sharerId);
    if (link) link.pc.close();
    this.incoming.delete(sharerId);
    const w = { ...useScreen.getState().watching };
    delete w[sharerId];
    useScreen.getState().set({ watching: w });
    if (notify && link) this.send(sharerId, "screen-down", { kind: "unwatch" });
  }

  /** Ses kanalından çıkınca her şeyi kapat. */
  async reset() {
    await this.stop();
    for (const id of [...this.incoming.keys()]) this.unwatch(id, false);
    this.gateway = null;
  }

  /** Bir yayıncı paylaşımı bitirdi: yalnızca onun yayınını izlemeyi bırak (izleyicilerime dokunma). */
  sharerStopped(userId: string) {
    if (this.incoming.has(userId)) this.unwatch(userId, false);
  }

  /** Kullanıcı kanaldan tamamen ayrıldı: hem izlediğim yayını hem izleyici bağlantısını kapat. */
  peerGone(userId: string) {
    if (this.incoming.has(userId)) this.unwatch(userId, false);
    if (this.outgoing.has(userId)) this.removeViewer(userId);
  }

  // ---------------------------------------------------------------- sinyal
  async handleSignal(from: string, stream: "screen-up" | "screen-down", data: SignalData) {
    try {
      if (stream === "screen-down") {
        // İzleyiciden yayıncıya (bana)
        if (data.kind === "watch") return void (await this.addViewer(from));
        if (data.kind === "unwatch") return this.removeViewer(from);
        await this.apply(this.outgoing.get(from), data);
      } else {
        // Yayıncıdan izleyiciye (bana)
        const link = this.incoming.get(from);
        if (!link) return;
        await this.apply(link, data);
        if (data.kind === "description" && data.type === "offer") {
          await link.pc.setLocalDescription(await link.pc.createAnswer());
          this.send(from, "screen-down", { kind: "description", type: "answer", sdp: link.pc.localDescription!.sdp });
        }
      }
    } catch (err) {
      console.warn("[screen] sinyal işlenemedi", err);
    }
  }

  private async apply(link: Link | undefined, data: SignalData) {
    if (!link) return;
    if (data.kind === "description") {
      await link.pc.setRemoteDescription({ type: data.type, sdp: data.sdp });
      for (const c of link.pending.splice(0)) await link.pc.addIceCandidate(c).catch(() => {});
    } else if (data.kind === "candidate") {
      const c = { candidate: data.candidate, sdpMid: data.sdpMid, sdpMLineIndex: data.sdpMLineIndex };
      if (!link.pc.remoteDescription) link.pending.push(c);
      else await link.pc.addIceCandidate(c).catch(() => {});
    }
  }

  private send(to: string, stream: "screen-up" | "screen-down", data: SignalData) {
    this.gateway?.send({ t: "rtc.signal", to, stream, data });
  }
}

export const screenShare = new ScreenShare();

/** Paylaşım için ekran akışı al (Electron'da seçilen kaynak, tarayıcıda sistem seçicisi). */
export async function captureScreen(preset: ScreenPreset, audio: boolean): Promise<MediaStream> {
  const p = SCREEN_PRESETS[preset];
  return navigator.mediaDevices.getDisplayMedia({
    video: { width: { ideal: p.width }, height: { ideal: p.height }, frameRate: { ideal: p.fps, max: p.fps } },
    audio,
  });
}
