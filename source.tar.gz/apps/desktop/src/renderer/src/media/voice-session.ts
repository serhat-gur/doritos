import type { ServerEvent, VoiceParticipant } from "@yanki/shared";
import { api } from "../lib/api";
import type { GatewayClient } from "../lib/gateway";
import { useRealtime, useSession, useVoice } from "../stores/app";
import { useSettings } from "../stores/settings";
import { playCue } from "./cues";
import { MeshTransport } from "./mesh-transport";
import { screenShare } from "./screen-share";
import { soundPlayer } from "./sound-player";
import type { MediaTransport } from "./transport";

const VAD_HANGOVER_MS = 350;

/**
 * Tek aktif sesli oturum. Mikrofonu, VAD / bas-konuş kapısını, uzak ses
 * elemanlarını ve taşıma katmanını yönetir. Gateway yeniden bağlanırsa
 * kanala otomatik geri katılır; susturma/sağırlaştırma durumu korunur.
 */
class VoiceSession {
  private gateway: GatewayClient | null = null;
  private transport: MediaTransport | null = null;
  private micStream: MediaStream | null = null;
  /** Yalnızca seviye ölçümü için mikrofon izinin kopyası (hiç susturulmaz). */
  private meterTrack: MediaStreamTrack | null = null;
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private vadTimer: ReturnType<typeof setInterval> | null = null;
  private statsTimer: ReturnType<typeof setInterval> | null = null;
  private lastVoiceAt = 0;
  private remoteEls = new Map<string, HTMLAudioElement>();
  private offGateway: (() => void)[] = [];
  private container: HTMLDivElement | null = null;
  /** Sunucuda susturulmuş diğer katılımcılar (alıcı tarafta da sesleri kapatılır) */
  private serverMuted = new Set<string>();
  /** Odamdaki diğer kişiler (giriş/çıkış seslerini doğru çalmak için) */
  private room = new Set<string>();
  /** Bu oturumda "bağlandım" sesi çalındı mı */
  private announced = false;

  get selfId(): string | null {
    return useSession.getState().user?.id ?? null;
  }

  async join(gateway: GatewayClient, channelId: string): Promise<void> {
    if (useVoice.getState().channelId === channelId && this.gateway === gateway) return;
    await this.leave();
    const selfId = this.selfId;
    if (!selfId) return;
    this.gateway = gateway;
    useVoice.getState().set({ guildId: gateway.guildId, channelId, state: "connecting", error: null, peerStats: {} });

    try {
      const [ice] = await Promise.all([api.iceServers(), this.openMic()]);
      useVoice.getState().set({ turnAvailable: ice.turn });
      screenShare.attach(gateway, ice.iceServers as RTCIceServer[]);
      this.transport = new MeshTransport(selfId, ice.iceServers as RTCIceServer[], {
        sendSignal: (to, data) => this.gateway?.send({ t: "rtc.signal", to, stream: "voice", data }),
        onRemoteStream: (userId, stream) => this.attachRemote(userId, stream),
        onPeerState: () => void this.refreshStats(),
      });
      this.transport.setLocalTrack(this.micStream?.getAudioTracks()[0] ?? null);
    } catch (err) {
      useVoice.getState().set({ state: "error", error: micErrorMessage(err) });
      await this.leave();
      return;
    }

    this.offGateway.push(
      gateway.on((ev) => this.onEvent(ev)),
      gateway.onStatus((s) => {
        if (s === "reconnecting") useVoice.getState().set({ state: "reconnecting" });
      }),
    );
    gateway.send({ t: "voice.join", channelId });
    // Odada zaten olanlarla bağlantı kur (yeni gelenler voice.update ile eklenir)
    for (const p of this.participantsIn(gateway.guildId, channelId)) {
      if (p.userId === selfId) continue;
      this.transport.addPeer(p.userId);
      this.room.add(p.userId);
    }
    const { selfMute, selfDeaf } = useVoice.getState();
    if (selfMute || selfDeaf) gateway.send({ t: "voice.state", selfMute, selfDeaf });
    this.applyGate();

    this.statsTimer = setInterval(() => void this.refreshStats(), 3000);
  }

  async leave(): Promise<void> {
    if (this.announced) playCue("self-leave");
    this.announced = false;
    this.room.clear();
    if (this.gateway && useVoice.getState().channelId) this.gateway.send({ t: "voice.leave" });
    for (const off of this.offGateway.splice(0)) off();
    await screenShare.reset();
    this.serverMuted.clear();
    if (this.vadTimer) clearInterval(this.vadTimer);
    if (this.statsTimer) clearInterval(this.statsTimer);
    this.vadTimer = this.statsTimer = null;
    this.transport?.close();
    this.transport = null;
    this.micStream?.getTracks().forEach((t) => t.stop());
    this.micStream = null;
    this.meterTrack?.stop();
    this.meterTrack = null;
    void this.audioCtx?.close();
    this.audioCtx = null;
    this.analyser = null;
    for (const el of this.remoteEls.values()) {
      el.srcObject = null;
      el.remove();
    }
    this.remoteEls.clear();
    this.gateway = null;
    const keepErr = useVoice.getState().state === "error" ? useVoice.getState().error : null;
    useVoice.getState().set({
      guildId: null,
      channelId: null,
      state: keepErr ? "error" : "idle",
      error: keepErr,
      speaking: false,
      inputLevel: 0,
      peerStats: {},
      serverMute: false,
      serverDeaf: false,
      pttActive: false,
    });
  }

  /** Bas-konuş makrosu (global kanca veya pencere içi). */
  setPtt(active: boolean): void {
    useVoice.getState().set({ pttActive: active });
    this.applyGate();
  }

  setMute(selfMute: boolean): void {
    const { selfDeaf } = useVoice.getState();
    // Sağırken susturmayı kaldırmak sağırlığı da kaldırır (Discord davranışı)
    const deaf = selfMute ? selfDeaf : false;
    useVoice.getState().set({ selfMute, selfDeaf: deaf });
    this.gateway?.send({ t: "voice.state", selfMute, selfDeaf: deaf });
    this.applyGate();
    this.applyRemoteVolumes();
  }

  setDeaf(selfDeaf: boolean): void {
    const selfMute = selfDeaf ? true : useVoice.getState().selfMute;
    useVoice.getState().set({ selfDeaf, selfMute });
    this.gateway?.send({ t: "voice.state", selfMute, selfDeaf });
    this.applyGate();
    this.applyRemoteVolumes();
  }

  /** Ayarlar değişince (cihaz, mod) çağrılır. */
  async reconfigure(): Promise<void> {
    if (!this.transport) return;
    try {
      await this.openMic();
      this.transport.setLocalTrack(this.micStream?.getAudioTracks()[0] ?? null);
      this.applyGate();
    } catch (err) {
      useVoice.getState().set({ error: micErrorMessage(err) });
    }
    this.applyRemoteVolumes();
  }

  applyRemoteVolumes(): void {
    const { userVolumes, outputDeviceId } = useSettings.getState();
    const { selfDeaf, serverDeaf } = useVoice.getState();
    for (const [userId, el] of this.remoteEls) {
      el.volume = Math.max(0, Math.min(1, userVolumes[userId] ?? 1));
      el.muted = selfDeaf || serverDeaf || this.serverMuted.has(userId);
      const sink = el as HTMLAudioElement & { setSinkId?: (id: string) => Promise<void> };
      if (sink.setSinkId) void sink.setSinkId(outputDeviceId === "default" ? "" : outputDeviceId).catch(() => {});
    }
  }

  // ---------------------------------------------------------------- iç işleyiş
  private async openMic(): Promise<void> {
    const s = useSettings.getState();
    this.micStream?.getTracks().forEach((t) => t.stop());
    this.micStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: s.inputDeviceId === "default" ? undefined : { exact: s.inputDeviceId },
        echoCancellation: s.echoCancellation,
        noiseSuppression: s.noiseSuppression,
        autoGainControl: true,
        channelCount: 1,
      },
      video: false,
    });
    // VAD için analiz düğümü (yalnızca ölçüm; çıkışa bağlanmaz). İzin bir
    // KOPYASI kullanılır: gönderilen iz kapı tarafından devre dışı
    // bırakıldığında (track.enabled = false) asıl iz sessizlik üretir; analiz
    // aynı izi dinlerse kapı bir daha hiç açılamaz.
    if (!this.audioCtx) this.audioCtx = new AudioContext();
    if (this.audioCtx.state === "suspended") void this.audioCtx.resume();
    this.meterTrack?.stop();
    this.meterTrack = this.micStream.getAudioTracks()[0]?.clone() ?? null;
    if (!this.meterTrack) return;
    const src = this.audioCtx.createMediaStreamSource(new MediaStream([this.meterTrack]));
    this.analyser = this.audioCtx.createAnalyser();
    this.analyser.fftSize = 1024;
    src.connect(this.analyser);
    if (!this.vadTimer) this.vadTimer = setInterval(() => this.tickVad(), 50);
  }

  private tickVad(): void {
    if (!this.analyser) return;
    const buf = new Float32Array(this.analyser.fftSize);
    this.analyser.getFloatTimeDomainData(buf);
    let sum = 0;
    for (const v of buf) sum += v * v;
    const rms = Math.sqrt(sum / buf.length);
    const now = performance.now();
    const { vadThreshold } = useSettings.getState();
    if (rms > vadThreshold) this.lastVoiceAt = now;
    useVoice.getState().set({ inputLevel: Math.min(1, rms * 8) });
    this.applyGate();
  }

  /** Mikrofon izinin açık/kapalı olmasına karar verir (susturma, PTT, VAD). */
  private applyGate(): void {
    const track = this.micStream?.getAudioTracks()[0];
    const v = useVoice.getState();
    const { inputMode } = useSettings.getState();
    let open: boolean;
    if (v.selfMute || v.selfDeaf || v.serverMute) open = false;
    else if (inputMode === "ptt") open = v.pttActive;
    else open = performance.now() - this.lastVoiceAt < VAD_HANGOVER_MS;
    if (track && track.enabled !== open) track.enabled = open;
    if (v.speaking !== open) {
      useVoice.getState().set({ speaking: open });
      this.gateway?.send({ t: "voice.speaking", speaking: open });
    }
  }

  private onEvent(ev: ServerEvent): void {
    const v = useVoice.getState();
    const self = this.selfId;
    if (!this.transport || !v.channelId) return;
    switch (ev.t) {
      case "ready": {
        // Yeniden bağlanma: sunucu tarafında ses durumu kaybolmuştur, tekrar katıl.
        this.gateway?.send({ t: "voice.join", channelId: v.channelId });
        if (v.selfMute || v.selfDeaf) this.gateway?.send({ t: "voice.state", selfMute: v.selfMute, selfDeaf: v.selfDeaf });
        // Hâlâ odada olan eşler için bağlantıları koru, olmayanları kapat
        const present = new Set(ev.voice.filter((p) => p.channelId === v.channelId).map((p) => p.userId));
        this.room = new Set([...present].filter((id) => id !== self));
        for (const userId of this.remoteEls.keys()) if (!present.has(userId)) this.dropPeer(userId);
        for (const p of ev.voice) if (p.channelId === v.channelId) this.transport.addPeer(p.userId);
        break;
      }
      case "voice.update": {
        const p = ev.participant;
        if (p.userId === self) {
          if (p.channelId !== v.channelId) return;
          if (!this.announced) {
            this.announced = true;
            playCue("self-join");
          }
          useVoice.getState().set({ state: "connected", serverMute: p.serverMute, serverDeaf: p.serverDeaf });
          if (p.serverDeaf) soundPlayer.stopAll();
          this.applyGate();
          this.applyRemoteVolumes();
          return;
        }
        if (p.channelId === v.channelId) {
          if (!this.room.has(p.userId)) {
            this.room.add(p.userId);
            if (this.announced) playCue("join");
          }
          this.transport.addPeer(p.userId);
          if (p.serverMute) this.serverMuted.add(p.userId);
          else this.serverMuted.delete(p.userId);
          if (!p.streaming) screenShare.sharerStopped(p.userId);
          this.applyRemoteVolumes();
        } else {
          if (this.room.delete(p.userId)) playCue("leave");
          this.dropPeer(p.userId);
        }
        break;
      }
      case "voice.leave":
        if (ev.userId === self) {
          if (ev.channelId === v.channelId && useVoice.getState().state === "connected") void this.leave();
        } else if (ev.channelId === v.channelId) {
          if (this.room.delete(ev.userId)) playCue("leave");
          this.dropPeer(ev.userId);
        }
        break;
      case "voice.moved": {
        const gw = this.gateway;
        window.dispatchEvent(new CustomEvent("yanki:toast", { detail: ev.channelId ? "Bir yetkili seni başka kanala taşıdı" : "Bir yetkili seni sesli kanaldan çıkardı" }));
        // Sunucu bizi zaten eski kanaldan çıkardı; yerel durumu sıfırla
        useVoice.getState().set({ channelId: null });
        void this.leave().then(() => {
          if (ev.channelId && gw) void this.join(gw, ev.channelId);
        });
        break;
      }
      case "rtc.signal":
        if (ev.stream === "voice") void this.transport.handleSignal(ev.from, ev.data);
        else void screenShare.handleSignal(ev.from, ev.stream, ev.data);
        break;
      case "error":
        if (ev.ref === "voice.join") {
          useVoice.getState().set({ state: "error", error: ev.message });
          void this.leave();
        }
        break;
    }
  }

  private dropPeer(userId: string): void {
    this.transport?.removePeer(userId);
    screenShare.peerGone(userId);
    this.serverMuted.delete(userId);
    const el = this.remoteEls.get(userId);
    if (el) {
      el.srcObject = null;
      el.remove();
      this.remoteEls.delete(userId);
    }
  }

  private attachRemote(userId: string, stream: MediaStream): void {
    if (!this.container) {
      this.container = document.createElement("div");
      this.container.hidden = true;
      document.body.appendChild(this.container);
    }
    let el = this.remoteEls.get(userId);
    if (!el) {
      el = document.createElement("audio");
      el.autoplay = true;
      el.dataset.userId = userId;
      this.container.appendChild(el);
      this.remoteEls.set(userId, el);
    }
    el.srcObject = stream;
    void el.play().catch(() => {});
    this.applyRemoteVolumes();
  }

  private async refreshStats(): Promise<void> {
    if (!this.transport) return;
    const stats = await this.transport.stats();
    useVoice.getState().set({ peerStats: Object.fromEntries(stats) });
  }

  /** Bir kullanıcının ses katılımcısı bilgisi (UI için). */
  participantsIn(guildId: string, channelId: string): VoiceParticipant[] {
    const g = useRealtime.getState().guilds[guildId];
    return g ? Object.values(g.voice).filter((p) => p.channelId === channelId) : [];
  }
}

function micErrorMessage(err: unknown): string {
  const name = (err as { name?: string }).name;
  if (name === "NotAllowedError") return "Mikrofon izni reddedildi";
  if (name === "NotFoundError" || name === "OverconstrainedError") return "Seçili mikrofon bulunamadı";
  if (name === "NotReadableError") return "Mikrofon başka bir uygulama tarafından kullanılıyor";
  return (err as Error)?.message ?? "Sesli kanala bağlanılamadı";
}

export const voiceSession = new VoiceSession();
