import { useVoice } from "../stores/app";
import { useSettings } from "../stores/settings";

/**
 * Sesli oda bildirim sesleri (Discord'daki gibi). Dosya yerine Web Audio ile
 * sentezlenir: indirme/önbellek gerektirmez, her cihazda aynı duyulur.
 *
 * - join / leave: odana biri girdi / çıktı (yükselen / alçalan iki ton)
 * - self-join / self-leave: sen girdin / çıktın (biraz daha dolgun)
 */
export type Cue = "join" | "leave" | "self-join" | "self-leave";

const TONES: Record<Cue, { freqs: [number, number]; gain: number }> = {
  join: { freqs: [587.33, 880], gain: 0.07 }, // Re5 → La5
  leave: { freqs: [880, 587.33], gain: 0.06 },
  "self-join": { freqs: [523.25, 783.99], gain: 0.08 }, // Do5 → Sol5
  "self-leave": { freqs: [783.99, 392], gain: 0.07 },
};

let ctx: AudioContext | null = null;
/** Aynı türden işaretin son çalınma anı (farklı türler birbirini bastırmaz) */
const lastAt = new Map<Cue, number>();
/** Tanılama / test: çalınan son işaretler */
export const cueHistory: { cue: Cue; at: number }[] = [];

export function playCue(cue: Cue): void {
  if (!useSettings.getState().voiceCues) return;
  // Sağırken başkalarının giriş/çıkışı çalınmaz (kendi giriş/çıkışın çalınır)
  if (useVoice.getState().selfDeaf && (cue === "join" || cue === "leave")) return;
  // Aynı anda çok kişi girerse aynı ses üst üste binmesin
  const now = performance.now();
  if (now - (lastAt.get(cue) ?? -Infinity) < 150) return;
  lastAt.set(cue, now);
  cueHistory.push({ cue, at: Date.now() });
  if (cueHistory.length > 30) cueHistory.shift();
  try {
    ctx ??= new AudioContext({ latencyHint: "interactive" });
    if (ctx.state === "suspended") void ctx.resume();
    const sink = useSettings.getState().outputDeviceId;
    const withSink = ctx as AudioContext & { setSinkId?: (id: string) => Promise<void> };
    if (withSink.setSinkId) void withSink.setSinkId(sink === "default" ? "" : sink).catch(() => {});
    const { freqs, gain } = TONES[cue];
    const t0 = ctx.currentTime;
    freqs.forEach((f, i) => {
      const start = t0 + i * 0.09;
      const osc = ctx!.createOscillator();
      const g = ctx!.createGain();
      osc.type = "sine";
      osc.frequency.value = f;
      g.gain.setValueAtTime(0.0001, start);
      g.gain.exponentialRampToValueAtTime(gain, start + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, start + 0.16);
      osc.connect(g).connect(ctx!.destination);
      osc.start(start);
      osc.stop(start + 0.18);
    });
  } catch {
    /* ses aygıtı yoksa sessizce geç */
  }
}
