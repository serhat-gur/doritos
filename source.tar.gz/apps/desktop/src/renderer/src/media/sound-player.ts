import type { ServerClock } from "../lib/clock";

const CACHE_NAME = "yanki-sounds-v1";
/** Cache Storage anahtarı: içerik hash'i (imzalı URL her saat değişir, hash değişmez). */
const cacheKey = (sha256: string) => `https://cache.yanki.invalid/sounds/${sha256}`;

/**
 * Soundboard oynatıcısı.
 *
 * - Sesler istemcide çalınır; mikrofon izine KARIŞTIRILMAZ. Odadaki herkes
 *   SOUND_PLAY olayını alıp aynı sesi kendi cihazında çalar. Böylece
 *   mikrofon kalitesi/yankı engelleme etkilenmez.
 * - Önbellek: bellek (AudioBuffer) → Cache Storage (diskte, sha256 anahtarlı) → ağ.
 * - Zamanlama: sunucu `playAt` (sunucu saati) gönderir; saat farkı düşülerek
 *   AudioContext zaman çizelgesinde aynı ana planlanır (≈ eşzamanlı oynatma).
 */
export class SoundPlayer {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private buffers = new Map<string, Promise<AudioBuffer>>();
  private active = new Set<AudioBufferSourceNode>();
  masterVolume = 0.8;
  /** Tanılama: son çalınan seslerin zamanlama sapması (gecikme ölçümü). */
  readonly history: { sha256: string; scheduledDelayMs: number; at: number }[] = [];
  maxConcurrent = 4;

  private ensure(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.master.gain.value = this.masterVolume;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  setMasterVolume(v: number): void {
    this.masterVolume = v;
    if (this.master) this.master.gain.value = v;
  }

  async setOutputDevice(deviceId: string): Promise<void> {
    const ctx = this.ensure() as AudioContext & { setSinkId?: (id: string) => Promise<void> };
    if (ctx.setSinkId) await ctx.setSinkId(deviceId === "default" ? "" : deviceId).catch(() => {});
  }

  /** Sesi indir ve çöz (ön yükleme için de kullanılır). */
  load(sha256: string, url: string): Promise<AudioBuffer> {
    let p = this.buffers.get(sha256);
    if (!p) {
      p = this.fetchBytes(sha256, url).then((bytes) => this.ensure().decodeAudioData(bytes));
      p.catch(() => this.buffers.delete(sha256));
      this.buffers.set(sha256, p);
    }
    return p;
  }

  private async fetchBytes(sha256: string, url: string): Promise<ArrayBuffer> {
    const key = cacheKey(sha256);
    let cache: Cache | null = null;
    try {
      cache = await caches.open(CACHE_NAME);
      const hit = await cache.match(key);
      if (hit) return await hit.arrayBuffer();
    } catch {
      cache = null; // Cache Storage yoksa (ör. bazı test ortamları) yalnızca bellek önbelleği
    }
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Ses indirilemedi (${res.status})`);
    const bytes = await res.arrayBuffer();
    // Bütünlük: içerik hash'i sunucunun bildirdiğiyle eşleşmeli
    const digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), (b) => b.toString(16).padStart(2, "0")).join("");
    if (digest !== sha256) throw new Error("Ses dosyası bütünlük kontrolünden geçemedi");
    if (cache) await cache.put(key, new Response(bytes.slice(0), { headers: { "Content-Type": res.headers.get("Content-Type") ?? "audio/mpeg" } })).catch(() => {});
    return bytes;
  }

  /**
   * Sunucudan gelen olayı çalar. `playAt` sunucu saati; geç kalındıysa sesin
   * başı atlanır (en fazla 1 sn), daha fazlaysa hemen baştan çalınır.
   */
  async playScheduled(opts: { sha256: string; url: string; volume: number; playAt: number; clock: ServerClock }): Promise<{ scheduledDelayMs: number }> {
    const buffer = await this.load(opts.sha256, opts.url);
    const ctx = this.ensure();
    const delayMs = opts.clock.msUntil(opts.playAt);
    if (delayMs >= 0) {
      this.start(buffer, opts.volume, ctx.currentTime + delayMs / 1000, 0);
    } else {
      const late = -delayMs / 1000;
      this.start(buffer, opts.volume, ctx.currentTime, late < 1 && late < buffer.duration ? late : 0);
    }
    this.history.push({ sha256: opts.sha256, scheduledDelayMs: delayMs, at: Date.now() });
    if (this.history.length > 20) this.history.shift();
    return { scheduledDelayMs: delayMs };
  }

  /** Yalnızca yerelde önizleme. */
  async preview(sha256: string, url: string, volume: number): Promise<void> {
    const buffer = await this.load(sha256, url);
    this.start(buffer, volume, this.ensure().currentTime, 0);
  }

  stopAll(): void {
    for (const s of this.active) {
      try {
        s.stop();
      } catch {
        /* zaten durmuş */
      }
    }
    this.active.clear();
  }

  private start(buffer: AudioBuffer, volume: number, when: number, offset: number): void {
    const ctx = this.ensure();
    // Aynı anda çok fazla ses: en eskisini sustur
    if (this.active.size >= this.maxConcurrent) {
      const oldest = this.active.values().next().value;
      try {
        oldest?.stop();
      } catch {
        /* yoksay */
      }
      if (oldest) this.active.delete(oldest);
    }
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const gain = ctx.createGain();
    gain.gain.value = Math.max(0, Math.min(1, volume));
    src.connect(gain).connect(this.master!);
    src.onended = () => this.active.delete(src);
    this.active.add(src);
    src.start(when, offset);
  }
}

export const soundPlayer = new SoundPlayer();
