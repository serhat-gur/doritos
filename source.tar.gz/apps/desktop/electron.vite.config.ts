import { resolve } from "node:path";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "electron-vite";

export default defineConfig({
  main: {
    build: { outDir: "out/main" },
  },
  preload: {
    build: {
      outDir: "out/preload",
      // Sandbox'lı preload CommonJS olmalı ve dış modül içeremez
      rollupOptions: { output: { format: "cjs", entryFileNames: "[name].cjs" } },
    },
  },
  renderer: {
    root: resolve(import.meta.dirname, "src/renderer"),
    build: {
      outDir: "out/renderer",
      rollupOptions: { input: resolve(import.meta.dirname, "src/renderer/index.html") },
    },
    plugins: [react(), tailwindcss()],
  },
});
