import { describe, expect, it } from "vitest";
import { ServerClock } from "../src/renderer/src/lib/clock";

describe("ServerClock", () => {
  it("örnek yokken ofset 0", () => {
    expect(new ServerClock().offset).toBe(0);
  });

  it("RTT'nin yarısını düşerek ofseti hesaplar", () => {
    const c = new ServerClock();
    // İstemci 1000'de gönderdi, sunucu 1550'de yanıtladı, 1100'de geldi → RTT 100, ofset 500
    c.addSample(1000, 1550, 1100);
    expect(c.offset).toBe(500);
    expect(c.rtt).toBe(100);
  });

  it("en düşük RTT'li örneği tercih eder (gürültüye dayanıklı)", () => {
    const c = new ServerClock();
    c.addSample(0, 800, 1000); // RTT 1000, ofset 300 (gürültülü)
    c.addSample(2000, 2520, 2040); // RTT 40, ofset 500 (güvenilir)
    c.addSample(3000, 3900, 3600); // RTT 600, ofset 600
    expect(c.offset).toBe(500);
  });

  it("geçersiz örnekleri yok sayar", () => {
    const c = new ServerClock();
    c.addSample(1000, 5000, 900); // negatif RTT
    expect(c.rtt).toBeNull();
  });

  it("msUntil sunucu zamanını yerel saate çevirir", () => {
    const c = new ServerClock();
    const now = Date.now();
    c.addSample(now - 10, now + 1000, now); // sunucu ~1005 ms ileride
    const until = c.msUntil(c.now() + 250);
    expect(until).toBeGreaterThan(240);
    expect(until).toBeLessThanOrEqual(250);
  });
});
