import { resolve } from "node:path";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

/**
 * Renderer'ı Electron olmadan tarayıcıda çalıştırmak için (geliştirme ve
 * Playwright uçtan uca testleri). Electron köprüsü yoksa bridge.ts tarayıcı
 * yedeğine düşer.
 */
export default defineConfig({
  root: resolve(import.meta.dirname, "src/renderer"),
  plugins: [react(), tailwindcss()],
  build: { outDir: resolve(import.meta.dirname, "out/web"), emptyOutDir: true },
  server: { port: 5173 },
});
