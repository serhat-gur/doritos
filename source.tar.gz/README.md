# Yankı

Arkadaş grubu için Discord alternatifi: **Windows masaüstü istemcisi (Electron + React)** ve **Cloudflare üzerinde sunucusuz arka uç** (Workers + Durable Objects + D1). Hiçbir kullanıcının bilgisayarı sunucu değildir; sahibi çevrimdışıyken de her şey çalışır. Ses ve ekran paylaşımı P2P (WebRTC) akar; Cloudflare yalnızca koordinasyon, veri ve gerektiğinde TURN sağlar.

**Sıfır ücret hedefi:** Kullanılan her Cloudflare servisi ücretsiz planda limit aşılınca *ücret kesmez, hata verir*. R2 (ödeme yöntemi ister) kullanılmaz; dosyalar ücretsiz Durable Object depolamasında, uygulama içi 3,5 GB tavanla tutulur. Ayrıntı: [maliyet analizi](docs/02-cloudflare-maliyet-analizi.md).

## Gerçekte çalışanlar (test edildi)

| Alan | Özellik | Nasıl doğrulandı |
|---|---|---|
| Hesap | Kayıt, giriş, çıkış, profil (görünen ad, hakkında, durum), **profil resmi** | Entegrasyon + uçtan uca |
| Güvenlik | PBKDF2 şifre, hash'li oturum, rate limit, Zod doğrulama, sunucu tarafı RBAC, içerik tabanlı dosya doğrulama, güvenli indirme başlıkları | Entegrasyon |
| Sunucular | Oluşturma, davet, katılma, **sunucu adı ve resmi** | Entegrasyon + uçtan uca |
| Kanallar | Yazı/ses/kategori, özel kanal, yeniden adlandırma (çift tık), silme, sürükle-bırak sıralama | Entegrasyon (sürükle-bırak: elle) |
| Roller | **Rol yönetim ekranı**: oluştur, renk, izinler, sil; üyeye rol ver/al; **kanal bazlı izinler** (izin ver / varsayılan / engelle); hiyerarşi kuralları | Entegrasyon |
| Moderasyon | **Sunucuda sustur / sağırlaştır** (kalıcı), **başka kanala taşı** (sürükle-bırak veya sağ tık menüsü), **sesten çıkar**, **at**, **yasakla** + yasak listesi | Entegrasyon + uçtan uca |
| Sesli oda | **AFK odası** (oraya geçen/taşınan kişide seçilebilir alarm durmadan çalar, "Uyandım" ile önceki odaya döner), **giriş/çıkış sesleri**, sağda her pencere boyutunda görünen üye paneli (kim seste, hangi kanalda, kim yayında) | Uçtan uca |
| Sohbet | Gerçek zamanlı mesaj, geçmiş, düzenle, **kalıcı sil**, yanıtla, yazıyor, okunmamış, bildirim, **dosya/resim** (seç, sürükle-bırak, yapıştır; 10 MB), **emoji tepkileri**, **mesaj arama** (Türkçe aksan duyarsız) | Entegrasyon + uçtan uca |
| Sosyal | **Arkadaş ekle/kabul/reddet/çıkar**, **engelle**, arkadaş çevrimiçi durumu, **özel mesaj (DM)** ve **grup DM** | Entegrasyon + uçtan uca |
| Ses | P2P WebRTC, sustur/sağırlaştır, ses algılama, **isteğe bağlı bas-konuş**, cihaz seçimi, kişi başı ses, konuşan göstergesi, bağlantı kalitesi, otomatik yeniden bağlanma | Uçtan uca (iki yönde ses akışı) |
| **Makrolar** | **Klavye veya mouse tuşu (Mouse 3/4/5) ile sustur, sağırlaştır, bas-konuş** — Electron'da global (oyundayken de) | Gerçek Electron'da X11 donanım olaylarıyla (Mouse 4 → mikrofon kapandı/açıldı, F9 → sağırlaştı) |
| **Ekran paylaşımı** | Ekran veya pencere seçimi, 720p/1080p, 15/30/60 FPS, izleyici sayısına göre dinamik bitrate, birden fazla yayını yan yana izleme, tam ekran, Windows'ta sistem sesi seçeneği, paylaşırken ses sürer | Uçtan uca (görüntü izleyiciye ulaştı, ses bağlı kaldı) |
| Soundboard | Yükle, düzenle, sil, favori, önizleme, kişisel + sunucu paneli, odadaki herkese eşzamanlı çalma, önbellek, cooldown, global kısayol | Entegrasyon + uçtan uca |
| Masaüstü | Güvenli Electron, tepsi, tek örnek, başlangıçta açılma, **otomatik güncelleme altyapısı** (GitHub Releases) | Paketlenmiş uygulama Linux'ta başlatıldı; güncelleme Windows'ta denenmedi |

Testler: 18 (ortak) + 29 (sunucu, gerçek workerd üzerinde D1/DO/WebSocket) + 5 (masaüstü) birim/entegrasyon, iki Chrome istemcili 22 adımlı uçtan uca test (art arda 3 kez geçti) ve gerçek Electron'da makro testi.

## Henüz uygulanmayanlar / bilinen sınırlar

- **Cloudflare Realtime SFU yok:** ses ve ekran paylaşımı P2P mesh. ~5 kişilik ses ve 3-4 izleyicili yayın için uygun; yayıncının yükleme hızı sınırlayıcıdır. (SFU 1.000 GB'tan sonra ücretli olduğu için bilinçli olarak eklenmedi.)
- **Ekran paylaşımında sistem sesi** yalnızca Windows'ta ve tüm sistem sesini yakalar (arkadaşlarının sesi dahil); uygulama bazlı ses yok.
- **TURN varsayılan kapalı:** bazı mobil/CGNAT bağlantılarında iki kişi doğrudan bağlanamayabilir.
- DM'de sesli arama yok; mesaja doğrudan atlama (aramada yalnızca kanal açılır); animasyonlu GIF profil resmi sabit kareye dönüşür.
- Otomatik güncelleme için `electron-builder.yml` içindeki GitHub kullanıcı adını doldurup sürüm yayınlaman gerekir; kod imzası yok (SmartScreen uyarısı).
- Uygulama **gerçek bir Windows makinesinde henüz denenmedi**; makro kancası ve sistem sesi Windows ikilileriyle gelir ama orada doğrulanmalı.

## Gereksinimler

- Node.js 20+ ve pnpm 10 (`npm i -g pnpm`)
- Cloudflare hesabı — **kart eklemeden** ücretsiz plan
- Windows 10/11 (masaüstü uygulaması ve kurulum dosyası için)

## Yerelde çalıştırma

```bash
pnpm install

# 1) Sunucu (Worker) — yerel D1 ve Durable Object'lerle
cd apps/server
echo "APP_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")" > .dev.vars
pnpm db:migrate:local
pnpm dev                       # http://127.0.0.1:8787

# 2) Masaüstü uygulaması (ayrı terminal)
pnpm --filter @yanki/desktop dev
```

## Cloudflare'e yayınlama (ücretsiz)

```bash
cd apps/server
npx wrangler login
npx wrangler d1 create yanki-db           # çıkan database_id'yi wrangler.jsonc'ye yaz
npx wrangler secret put APP_SECRET         # en az 32 karakter rastgele değer
pnpm db:migrate:remote
pnpm deploy                                # https://yanki-server.<hesabın>.workers.dev
```

R2 bucket oluşturmana **gerek yok**. İsteğe bağlı:
- **Kayıtları kısıtla:** `REGISTRATION_MODE` = `"code"` ve `npx wrangler secret put REGISTRATION_CODE`.
- **TURN:** zor bağlantılarda Realtime → TURN anahtarı, sonra `TURN_KEY_ID` / `TURN_KEY_API_TOKEN` gizli değerleri. Ayda 1.000 GB'a kadar ücretsiz; ses için pratikte aşılmaz ama sıfır risk istiyorsan kapalı bırak.
- **CPU sınırı:** ücretsiz planda giriş Error 1102 verirse bkz. [CPU riski](docs/02-cloudflare-maliyet-analizi.md#cpu-riski).

## Windows kurulum dosyası

```bash
pnpm install
pnpm dist:win      # apps/desktop/release/Yanki-Setup-0.1.0.exe
```

Derleyici (Visual Studio) gerekmez; global makro modülü hazır Windows ikilisiyle gelir. Kurulumdan sonra giriş ekranındaki **Sunucu** bağlantısından Worker adresini gir.

**Otomatik güncelleme:** `apps/desktop/electron-builder.yml` → `publish.owner` alanına GitHub kullanıcı adını yaz, `package.json` sürümünü artır ve `GH_TOKEN=... pnpm --filter @yanki/desktop exec electron-builder --win --publish always` ile yayınla. Kurulu uygulamalar 6 saatte bir denetler, indirince "Yeniden başlat ve güncelle" şeridi çıkar.

## Testler

```bash
pnpm typecheck
pnpm test
```

Uçtan uca (iki gerçek Chrome istemcisi, sahte mikrofon ve ekran):

```bash
pnpm dev:server                                    # terminal 1
pnpm --filter @yanki/desktop build:web
python -m http.server 5173 -d apps/desktop/out/web # terminal 2
pip install playwright && pnpm e2e                 # terminal 3
```

## Dokümanlar

1. [Mimari kararlar](docs/01-mimari-kararlar.md)
2. [Cloudflare ücretsiz plan ve maliyet analizi](docs/02-cloudflare-maliyet-analizi.md)
3. [Monorepo yapısı](docs/03-monorepo-yapisi.md)
4. [D1 şeması](docs/04-d1-veritabani-semasi.md)
5. [Rol ve izin modeli](docs/05-rol-ve-izin-modeli.md)
6. [WebSocket olay sözleşmeleri](docs/06-websocket-olay-sozlesmeleri.md)
7. [WebRTC / ekran paylaşımı stratejisi](docs/07-webrtc-sfu-stratejisi.md)
8. [Soundboard mimarisi](docs/08-soundboard-mimarisi.md)
9. [Electron güvenliği ve makrolar](docs/09-electron-guvenlik.md)
10. [Aşamalar ve kabul kriterleri](docs/10-asamalar-ve-kabul-kriterleri.md)
